// server/runtime.ts
import { existsSync as existsSync3, readFileSync as readFileSync2 } from "node:fs";
import { resolve, join as join2 } from "node:path";

// server/app.ts
import Fastify from "fastify";
import staticPlugin from "@fastify/static";
import { existsSync as existsSync2 } from "node:fs";
import { z as z2 } from "zod";

// shared/model.ts
import { z } from "zod";
var entityNames = ["contacts", "companies", "deals", "tasks"];
var EntityNameSchema = z.enum(entityNames);
var valueSchema = z.union([z.string(), z.number().finite(), z.boolean(), z.null()]);
var FieldSchema = z.object({
  key: z.string().regex(/^[a-zA-Z][a-zA-Z0-9_]{0,99}$/),
  label: z.string().min(1).max(100),
  type: z.enum(["text", "email", "number", "date", "enum", "reference", "boolean"]),
  required: z.boolean(),
  readOnly: z.boolean(),
  options: z.array(z.object({ id: z.string(), label: z.string() }).strict()),
  referenceEntity: EntityNameSchema.nullable()
}).strict();
var RuleSchema = z.object({
  id: z.string().min(1).max(100),
  entity: EntityNameSchema,
  kind: z.enum(["required", "email", "min", "conditional_required", "allowed_transition"]),
  field: z.string(),
  value: z.string().nullable(),
  whenField: z.string().nullable(),
  whenValue: z.string().nullable(),
  origin: z.enum(["configuration", "user"]),
  description: z.string().min(1).max(500),
  evidence: z.string().min(1).max(1e3)
}).strict();
var EntitySchema = z.object({
  id: EntityNameSchema,
  label: z.string().min(1),
  singular: z.string().min(1),
  displayField: z.string(),
  columns: z.array(z.string()).min(1),
  fields: z.array(FieldSchema).min(1)
}).strict();
var RecordSchema = z.object({
  id: z.string().min(1),
  entity: EntityNameSchema,
  values: z.record(valueSchema)
}).strict();
var StageSchema = z.object({
  id: z.string(),
  label: z.string(),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/)
}).strict();
var LinkSchema = z.object({
  fromEntity: EntityNameSchema,
  fromId: z.string(),
  toEntity: EntityNameSchema,
  toId: z.string(),
  label: z.string()
}).strict();
var SnapshotSchema = z.object({
  version: z.literal(1),
  id: z.string(),
  name: z.string().min(1),
  capturedAt: z.string().datetime(),
  source: z.object({
    kind: z.enum(["fixture", "hubspot", "archive"]),
    accountId: z.string(),
    isTestData: z.literal(true),
    description: z.string()
  }).strict(),
  entities: z.array(EntitySchema).length(4),
  records: z.array(RecordSchema).max(4e4),
  links: z.array(LinkSchema).max(2e5),
  stages: z.array(StageSchema).min(1),
  rules: z.array(RuleSchema),
  unsupported: z.array(z.string()),
  manifest: z.object({
    complete: z.boolean(),
    expectedCounts: z.record(z.number().int().nonnegative()),
    expectedLinks: z.number().int().nonnegative()
  }).strict()
}).strict();
var AppSpecSchema = z.object({
  version: z.literal(1),
  title: z.string().min(1).max(100),
  description: z.string().max(500),
  entities: z.array(EntitySchema).length(4),
  stages: z.array(StageSchema).min(1),
  rules: z.array(RuleSchema),
  coverage: z.object({
    supported: z.array(z.string()),
    unsupported: z.array(z.string())
  }).strict()
}).strict();
var GenerationSchema = z.object({
  provider: z.enum(["demo", "ai"]),
  model: z.string().nullable(),
  generatedAt: z.string().datetime(),
  prompt: z.string(),
  approved: z.boolean()
}).strict();
var BundleSchema = z.object({
  format: z.literal("planb-continuity-v1"),
  exportedAt: z.string().datetime(),
  snapshot: SnapshotSchema,
  spec: AppSpecSchema,
  generation: GenerationSchema,
  records: z.array(RecordSchema),
  changes: z.array(z.object({
    id: z.number().int(),
    at: z.string().datetime(),
    entity: EntityNameSchema,
    recordId: z.string(),
    operation: z.enum(["create", "update"]),
    before: RecordSchema.nullable(),
    after: RecordSchema
  }).strict())
}).strict();
function reconcile(snapshot) {
  const errors = [];
  const names = snapshot.entities.map((e) => e.id);
  if (new Set(names).size !== 4 || entityNames.some((e) => !names.includes(e))) {
    errors.push("La captura debe contener las cuatro entidades, sin duplicados.");
  }
  const ids = /* @__PURE__ */ new Set();
  for (const record of snapshot.records) {
    const id = record.entity + ":" + record.id;
    if (ids.has(id)) errors.push("Registro duplicado: " + id);
    ids.add(id);
    const entity = snapshot.entities.find((e) => e.id === record.entity);
    if (!entity) continue;
    const fields = new Map(entity.fields.map((f) => [f.key, f]));
    for (const [key, value] of Object.entries(record.values)) {
      const field = fields.get(key);
      if (!field) errors.push("Campo sin definici\xF3n: " + record.entity + "." + key);
      if (field?.type === "reference" && value && field.referenceEntity && !snapshot.records.some((r) => r.entity === field.referenceEntity && r.id === String(value))) {
        errors.push("Referencia sin destino: " + id + "." + key);
      }
    }
  }
  for (const entity of snapshot.entities) {
    if (new Set(entity.fields.map((f) => f.key)).size !== entity.fields.length) errors.push("Campos duplicados: " + entity.id);
    if (!entity.fields.some((f) => f.key === entity.displayField)) errors.push("Nombre principal no v\xE1lido: " + entity.id);
    if (entity.columns.some((k) => !entity.fields.some((f) => f.key === k))) errors.push("Columna desconocida: " + entity.id);
  }
  const counts = Object.fromEntries(entityNames.map((name) => {
    const actual = snapshot.records.filter((r) => r.entity === name).length;
    const expected = snapshot.manifest.expectedCounts[name];
    if (expected === void 0 || actual !== expected) errors.push("Recuento incompleto: " + name);
    return [name, { expected: expected ?? 0, actual }];
  }));
  for (const link of snapshot.links) {
    if (!ids.has(link.fromEntity + ":" + link.fromId) || !ids.has(link.toEntity + ":" + link.toId)) {
      errors.push("Relaci\xF3n sin registro de origen o destino.");
    }
  }
  if (snapshot.links.length !== snapshot.manifest.expectedLinks) errors.push("Recuento incompleto de relaciones.");
  if (!snapshot.manifest.complete) errors.push("El origen no confirm\xF3 una captura completa.");
  return {
    complete: errors.length === 0,
    counts,
    expectedLinks: snapshot.manifest.expectedLinks,
    actualLinks: snapshot.links.length,
    errors: [...new Set(errors)]
  };
}
function validateSpec(spec, snapshot, userPrompt = "") {
  const errors = [];
  const seen = /* @__PURE__ */ new Set();
  for (const entity of spec.entities) {
    if (seen.has(entity.id)) errors.push("Entidad duplicada: " + entity.id);
    seen.add(entity.id);
    const source = snapshot.entities.find((e) => e.id === entity.id);
    if (!source) {
      errors.push("Entidad ajena al origen.");
      continue;
    }
    const fields = new Map(source.fields.map((f) => [f.key, f]));
    if (entity.fields.length !== source.fields.length) errors.push("Faltan campos importados: " + entity.id);
    if (new Set(entity.fields.map((f) => f.key)).size !== entity.fields.length) errors.push("Campos duplicados.");
    for (const field of entity.fields) {
      const original = fields.get(field.key);
      if (!original || field.type !== original.type || field.readOnly !== original.readOnly || field.required !== original.required || field.referenceEntity !== original.referenceEntity || JSON.stringify(field.options) !== JSON.stringify(original.options)) {
        errors.push("Se alter\xF3 la definici\xF3n del campo: " + entity.id + "." + field.key);
      }
    }
    if (!fields.has(entity.displayField) || entity.columns.some((k) => !fields.has(k))) errors.push("Vista con campos desconocidos.");
  }
  if (seen.size !== 4) errors.push("Faltan entidades.");
  if (JSON.stringify(spec.stages) !== JSON.stringify(snapshot.stages)) errors.push("Se alteraron las etapas del origen.");
  const ruleIds = /* @__PURE__ */ new Set();
  for (const rule of spec.rules) {
    if (ruleIds.has(rule.id)) errors.push("Regla duplicada.");
    ruleIds.add(rule.id);
    const entity = snapshot.entities.find((e) => e.id === rule.entity);
    const field = entity?.fields.find((f) => f.key === rule.field);
    if (!field || field.readOnly) errors.push("Regla sobre un campo no editable.");
    if (rule.whenField && !entity?.fields.some((f) => f.key === rule.whenField)) errors.push("Condici\xF3n sobre un campo desconocido.");
    if (rule.kind === "conditional_required" && (!rule.whenField || rule.whenValue === null)) errors.push("Regla condicional incompleta.");
    if (rule.kind === "conditional_required") {
      const condition = entity?.fields.find((f) => f.key === rule.whenField);
      if (condition?.type === "enum" && !condition.options.some((o) => o.id === rule.whenValue)) errors.push("La condici\xF3n usa una opci\xF3n desconocida.");
    }
    if (rule.kind === "min" && (field?.type !== "number" || rule.value === null || !Number.isFinite(Number(rule.value)))) errors.push("L\xEDmite num\xE9rico no v\xE1lido.");
    if (rule.kind === "email" && field?.type !== "email" && field?.type !== "text") errors.push("Validaci\xF3n de correo no compatible.");
    if (rule.kind === "allowed_transition") {
      const valid = new Set(snapshot.stages.map((s) => s.id));
      if (rule.entity !== "deals" || rule.field !== "dealstage") errors.push("Las transiciones solo se aplican a la etapa de una oportunidad.");
      if (!rule.whenValue || !rule.value || !valid.has(rule.whenValue) || rule.value.split(",").some((v) => !valid.has(v))) errors.push("Transici\xF3n comercial desconocida.");
    }
    if (rule.origin === "configuration" && !snapshot.rules.some((r) => JSON.stringify(r) === JSON.stringify(rule))) {
      errors.push("Regla importada sin evidencia en la captura.");
    }
    if (rule.origin === "user" && (!userPrompt.trim() || !userPrompt.includes(rule.evidence))) {
      errors.push("Regla de usuario sin una cita exacta de su instrucci\xF3n.");
    }
  }
  for (const rule of snapshot.rules) {
    if (!spec.rules.some((r) => JSON.stringify(r) === JSON.stringify(rule))) errors.push("Falta una regla del origen: " + rule.id);
  }
  if (spec.coverage.supported.length === 0) errors.push("La aplicaci\xF3n debe declarar procesos cubiertos.");
  for (const limitation of snapshot.unsupported) {
    if (!spec.coverage.unsupported.includes(limitation)) errors.push("Falta declarar una limitaci\xF3n del origen.");
  }
  return [...new Set(errors)];
}
function validateRecord(spec, record, previous) {
  const errors = {};
  const entity = spec.entities.find((e) => e.id === record.entity);
  if (!entity) return { _form: "Entidad desconocida." };
  for (const key of Object.keys(record.values)) if (!entity.fields.some((f) => f.key === key)) errors[key] = "Campo desconocido.";
  for (const field of entity.fields) {
    const value = record.values[field.key];
    const empty = value === null || value === void 0 || value === "";
    if (field.readOnly && previous && value !== previous.values[field.key]) errors[field.key] = "Este campo es de solo lectura.";
    if (field.required && empty) errors[field.key] = "Completa este campo.";
    if (empty) continue;
    if (field.type === "number" && (typeof value !== "number" || !Number.isFinite(value))) errors[field.key] = "Introduce un n\xFAmero v\xE1lido.";
    if (field.type === "boolean" && typeof value !== "boolean") errors[field.key] = "Introduce un valor verdadero o falso.";
    if (["text", "email", "date", "enum", "reference"].includes(field.type) && typeof value !== "string") errors[field.key] = "Introduce un texto v\xE1lido.";
    if (field.type === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value))) errors[field.key] = "Introduce un correo v\xE1lido.";
    if (field.type === "date") {
      const text = String(value), parsed = Date.parse(text);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(text) || Number.isNaN(parsed) || new Date(parsed).toISOString().slice(0, 10) !== text) errors[field.key] = "Introduce una fecha v\xE1lida.";
    }
    if (field.type === "enum" && !field.options.some((o) => o.id === value)) errors[field.key] = "Selecciona una opci\xF3n v\xE1lida.";
    if (typeof value === "string" && value.length > 1e4) errors[field.key] = "El texto es demasiado largo.";
  }
  for (const rule of spec.rules.filter((r) => r.entity === record.entity)) {
    const value = record.values[rule.field];
    const empty = value === null || value === void 0 || value === "";
    if (rule.kind === "required" && empty) errors[rule.field] = rule.description;
    if (rule.kind === "email" && !empty && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value))) errors[rule.field] = rule.description;
    if (rule.kind === "min" && !empty && Number(value) < Number(rule.value)) errors[rule.field] = rule.description;
    if (rule.kind === "conditional_required" && String(record.values[rule.whenField]) === rule.whenValue && empty) errors[rule.field] = rule.description;
    if (rule.kind === "allowed_transition" && previous && previous.values[rule.field] !== value && String(previous.values[rule.field]) === rule.whenValue && !rule.value.split(",").includes(String(value))) errors[rule.field] = rule.description;
  }
  return errors;
}

// server/store.ts
import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { randomUUID } from "node:crypto";
var AppError = class extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
};
var Store = class {
  constructor(filename) {
    this.filename = filename;
    if (filename !== ":memory:") mkdirSync(dirname(filename), { recursive: true });
    this.db = new DatabaseSync(filename);
    this.db.exec(
      "PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);CREATE TABLE IF NOT EXISTS records(entity TEXT NOT NULL,id TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY(entity,id));CREATE TABLE IF NOT EXISTS changes(id INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT NOT NULL,entity TEXT NOT NULL,record_id TEXT NOT NULL,operation TEXT NOT NULL,before_json TEXT,after_json TEXT NOT NULL);CREATE TABLE IF NOT EXISTS archives(id TEXT PRIMARY KEY,at TEXT NOT NULL,bundle TEXT NOT NULL);CREATE TABLE IF NOT EXISTS usage(id TEXT PRIMARY KEY,month TEXT NOT NULL,reserved_usd REAL NOT NULL,used_usd REAL NOT NULL DEFAULT 0,status TEXT NOT NULL);"
    );
    this.db.prepare("UPDATE usage SET status='interrupted' WHERE status='pending'").run();
  }
  db;
  close() {
    this.db.close();
  }
  get(key, fallback) {
    const row = this.db.prepare("SELECT value FROM meta WHERE key=?").get(key);
    return row ? JSON.parse(row.value) : fallback;
  }
  set(key, value) {
    this.db.prepare("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(key, JSON.stringify(value));
  }
  get snapshot() {
    return this.get("snapshot", null);
  }
  get spec() {
    return this.get("spec", null);
  }
  get generation() {
    return this.get("generation", null);
  }
  get reconciliation() {
    return this.get("reconciliation", null);
  }
  get disconnected() {
    return this.get("disconnected", false);
  }
  get ready() {
    return !!(this.snapshot && this.spec && this.generation?.approved && this.reconciliation?.complete && !this.get("lastError", null));
  }
  get changesCount() {
    return Number(this.db.prepare("SELECT COUNT(*) AS n FROM changes").get().n);
  }
  transaction(fn) {
    this.db.exec("BEGIN IMMEDIATE");
    try {
      const result = fn();
      this.db.exec("COMMIT");
      return result;
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
  }
  importSnapshot(raw, replace = false) {
    const parsed = SnapshotSchema.safeParse(raw);
    if (!parsed.success) throw new AppError(422, "La captura tiene un formato no v\xE1lido.", parsed.error.flatten());
    const snapshot = parsed.data;
    const report = reconcile(snapshot);
    const ruleErrors = validateSpec({
      version: 1,
      title: snapshot.name,
      description: "",
      entities: snapshot.entities,
      stages: snapshot.stages,
      rules: snapshot.rules,
      coverage: { supported: ["Datos del origen"], unsupported: snapshot.unsupported }
    }, snapshot);
    report.errors.push(...ruleErrors);
    report.complete = report.errors.length === 0;
    if (!report.complete) {
      this.set("lastImportError", report);
      throw new AppError(422, "Importaci\xF3n incompleta. Se conserva la \xFAltima captura v\xE1lida.", report);
    }
    if (this.changesCount && !replace) throw new AppError(409, "Hay cambios locales. Exporta una copia antes de cambiar el origen.");
    this.transaction(() => {
      const existing = this.bundleOrNull();
      if (existing) this.db.prepare("INSERT INTO archives(id,at,bundle) VALUES(?,?,?)").run(randomUUID(), (/* @__PURE__ */ new Date()).toISOString(), JSON.stringify(existing));
      this.db.exec("DELETE FROM records; DELETE FROM changes;");
      for (const record of snapshot.records) this.insertRecord(record);
      this.set("snapshot", snapshot);
      this.set("reconciliation", report);
      this.set("spec", null);
      this.set("generation", null);
      this.set("lastError", null);
      this.set("lastImportError", null);
      this.set("disconnected", false);
    });
    return report;
  }
  saveGeneration(raw, generation) {
    const snapshot = this.snapshot;
    if (!snapshot) throw new AppError(409, "Importa primero una captura.");
    const parsed = AppSpecSchema.safeParse(raw);
    const errors = parsed.success ? validateSpec(parsed.data, snapshot, generation.prompt) : ["La especificaci\xF3n no cumple el contrato de la aplicaci\xF3n."];
    if (errors.length || !parsed.success) {
      this.set("lastError", "La generaci\xF3n no super\xF3 la validaci\xF3n.");
      const old = this.generation;
      if (old) this.set("generation", { ...old, approved: false });
      throw new AppError(422, "La aplicaci\xF3n no est\xE1 preparada. Revisa la generaci\xF3n.", errors);
    }
    this.transaction(() => {
      this.set("spec", parsed.data);
      this.set("generation", { ...generation, approved: false });
      this.set("lastError", null);
    });
  }
  failGeneration(message) {
    this.set("lastError", message);
    if (this.generation) this.set("generation", { ...this.generation, approved: false });
  }
  activate() {
    const spec = this.spec, snapshot = this.snapshot, generation = this.generation;
    if (!spec || !snapshot || !generation) throw new AppError(409, "Genera primero una especificaci\xF3n.");
    if (this.get("lastError", null)) throw new AppError(409, "La \xFAltima generaci\xF3n fall\xF3. Vuelve a generarla.");
    const errors = validateSpec(spec, snapshot, generation.prompt);
    for (const record of this.records()) {
      const issues = validateRecord(spec, record);
      for (const [key, message] of Object.entries(issues)) errors.push(record.entity + "/" + record.id + "/" + key + ": " + message);
    }
    if (!this.reconciliation?.complete || errors.length) {
      this.set("lastError", "Hay datos o reglas que necesitan revisi\xF3n.");
      throw new AppError(422, "No se puede activar todav\xEDa.", errors.slice(0, 50));
    }
    this.set("generation", { ...generation, approved: true });
  }
  insertRecord(record) {
    this.db.prepare("INSERT INTO records(entity,id,value) VALUES(?,?,?) ON CONFLICT(entity,id) DO UPDATE SET value=excluded.value").run(record.entity, record.id, JSON.stringify(record));
  }
  records(entity) {
    const rows = entity ? this.db.prepare("SELECT value FROM records WHERE entity=? ORDER BY rowid").all(entity) : this.db.prepare("SELECT value FROM records ORDER BY rowid").all();
    return rows.map((r) => JSON.parse(r.value));
  }
  record(entity, id) {
    const row = this.db.prepare("SELECT value FROM records WHERE entity=? AND id=?").get(entity, id);
    return row ? JSON.parse(row.value) : null;
  }
  saveRecord(entity, values, id) {
    if (!this.ready || !this.spec) throw new AppError(409, "Revisa y activa primero la aplicaci\xF3n.");
    const previous = id ? this.record(entity, id) : null;
    if (id && !previous) throw new AppError(404, "No se encontr\xF3 el registro.");
    const record = RecordSchema.parse({ entity, id: id ?? "local-" + randomUUID(), values: previous ? { ...previous.values, ...values } : values });
    const errors = validateRecord(this.spec, record, previous);
    const definition = this.spec.entities.find((e) => e.id === entity);
    for (const field of definition.fields) {
      const value = record.values[field.key];
      if (field.type === "reference" && value && field.referenceEntity && !this.record(field.referenceEntity, String(value))) {
        errors[field.key] = "El registro relacionado no existe.";
      }
      if (!previous && field.readOnly && value !== void 0 && value !== null && value !== "") errors[field.key] = "Este campo no se puede crear manualmente.";
    }
    if (Object.keys(errors).length) throw new AppError(422, "Revisa los campos se\xF1alados.", errors);
    this.transaction(() => {
      this.insertRecord(record);
      this.db.prepare("INSERT INTO changes(at,entity,record_id,operation,before_json,after_json) VALUES(?,?,?,?,?,?)").run((/* @__PURE__ */ new Date()).toISOString(), entity, record.id, previous ? "update" : "create", previous ? JSON.stringify(previous) : null, JSON.stringify(record));
    });
    return record;
  }
  changes() {
    return this.db.prepare("SELECT * FROM changes ORDER BY id").all().map((r) => ({
      id: r.id,
      at: r.at,
      entity: r.entity,
      recordId: r.record_id,
      operation: r.operation,
      before: r.before_json ? JSON.parse(r.before_json) : null,
      after: JSON.parse(r.after_json)
    }));
  }
  bundleOrNull() {
    const snapshot = this.snapshot, spec = this.spec, generation = this.generation;
    if (!snapshot || !spec || !generation) return null;
    return { format: "planb-continuity-v1", exportedAt: (/* @__PURE__ */ new Date()).toISOString(), snapshot, spec, generation, records: this.records(), changes: this.changes() };
  }
  bundle() {
    if (!this.ready) throw new AppError(409, "Activa una aplicaci\xF3n verificada antes de exportar.");
    return this.bundleOrNull();
  }
  restoreBundle(raw) {
    const parsed = BundleSchema.safeParse(raw);
    if (!parsed.success) throw new AppError(422, "El paquete de continuidad no es v\xE1lido.");
    const bundle = parsed.data;
    const report = reconcile(bundle.snapshot);
    const errors = validateSpec(bundle.spec, bundle.snapshot, bundle.generation.prompt);
    const ids = new Set(bundle.records.map((r) => r.entity + ":" + r.id));
    if (ids.size !== bundle.records.length) errors.push("Registros activos duplicados.");
    for (const baseline of bundle.snapshot.records) {
      if (!ids.has(baseline.entity + ":" + baseline.id)) errors.push("El paquete perdi\xF3 un registro de la captura.");
    }
    for (const record of bundle.records) {
      for (const [field, message] of Object.entries(validateRecord(bundle.spec, record))) errors.push(record.id + "/" + field + ": " + message);
      const entity = bundle.spec.entities.find((e) => e.id === record.entity);
      for (const field of entity?.fields ?? []) if (field.type === "reference" && record.values[field.key] && !ids.has(field.referenceEntity + ":" + String(record.values[field.key]))) errors.push("Referencia inv\xE1lida en el paquete.");
    }
    if (!report.complete || errors.length || !bundle.generation.approved) throw new AppError(422, "El paquete no super\xF3 la comprobaci\xF3n de integridad.", [...report.errors, ...errors]);
    this.transaction(() => {
      this.db.exec("DELETE FROM records; DELETE FROM changes;");
      for (const record of bundle.records) this.insertRecord(record);
      for (const change of bundle.changes) this.db.prepare("INSERT INTO changes(id,at,entity,record_id,operation,before_json,after_json) VALUES(?,?,?,?,?,?,?)").run(change.id, change.at, change.entity, change.recordId, change.operation, change.before ? JSON.stringify(change.before) : null, JSON.stringify(change.after));
      this.set("snapshot", bundle.snapshot);
      this.set("spec", bundle.spec);
      this.set("generation", bundle.generation);
      this.set("reconciliation", report);
      this.set("lastError", null);
      this.set("disconnected", true);
    });
  }
  usage() {
    const month = (/* @__PURE__ */ new Date()).toISOString().slice(0, 7);
    const row = this.db.prepare("SELECT COALESCE(SUM(used_usd),0) AS used,COALESCE(SUM(CASE WHEN status IN ('pending','interrupted') THEN reserved_usd ELSE 0 END),0) AS reserved,COUNT(*) AS requests FROM usage WHERE month=?").get(month);
    return { usedUsd: row.used, reservedUsd: row.reserved, limitUsd: 25, requests: row.requests };
  }
  reserveUsage(worstCaseUsd) {
    if (!Number.isFinite(worstCaseUsd) || worstCaseUsd < 0) throw new AppError(422, "La reserva de presupuesto no es v\xE1lida.");
    const id = randomUUID(), month = (/* @__PURE__ */ new Date()).toISOString().slice(0, 7);
    this.transaction(() => {
      const used = this.usage();
      if (used.usedUsd + used.reservedUsd + worstCaseUsd > used.limitUsd) throw new AppError(429, "Se alcanz\xF3 el l\xEDmite local de 25 USD para pruebas de IA.");
      this.db.prepare("INSERT INTO usage(id,month,reserved_usd,used_usd,status) VALUES(?,?,?,0,'pending')").run(id, month, worstCaseUsd);
    });
    return id;
  }
  settleUsage(id, usd) {
    if (!Number.isFinite(usd) || usd < 0) throw new AppError(422, "El coste comunicado por el proveedor no es v\xE1lido.");
    this.db.prepare("UPDATE usage SET used_usd=?,reserved_usd=0,status='complete' WHERE id=?").run(usd, id);
  }
};

// server/exporter.ts
import archiver from "archiver";
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
async function runtimeZip(bundle, root2) {
  const runtimeFile = existsSync(join(root2, "runtime.mjs")) ? join(root2, "runtime.mjs") : join(root2, "build", "runtime.mjs");
  const frontend = join(root2, "dist");
  if (!existsSync(runtimeFile) || !existsSync(join(frontend, "index.html"))) throw new AppError(503, "El paquete necesita una compilaci\xF3n completa de la aplicaci\xF3n.");
  const archive = archiver("zip", { zlib: { level: 3 } });
  const chunks = [];
  const finished = new Promise((resolve2, reject) => {
    archive.on("data", (data) => chunks.push(Buffer.from(data)));
    archive.on("end", () => resolve2(Buffer.concat(chunks)));
    archive.on("error", reject);
  });
  archive.append(readFileSync(runtimeFile), { name: "runtime.mjs" });
  archive.append(JSON.stringify(bundle, null, 2), { name: "continuity.seed.json" });
  archive.directory(frontend, "dist");
  const moduleRoot = join(root2, "runtime-assets", "node_modules");
  const runtimeModules = existsSync(moduleRoot) ? moduleRoot : join(root2, "node_modules");
  archive.directory(runtimeModules, "node_modules", (entry) => {
    const name = entry.name.replace(/^node_modules\//, "");
    return !name.split("/").some((part) => [".cache", ".bin", "lucide-react", "react", "react-dom", "scheduler"].includes(part)) && !name.endsWith(".log") ? entry : false;
  });
  archive.file(process.execPath, { name: process.platform === "win32" ? "node.exe" : "node" });
  const license = join(root2, "NODE-LICENSE.txt");
  if (existsSync(license)) archive.file(license, { name: "NODE-LICENSE.txt" });
  archive.append('@echo off\r\ncd /d "%~dp0"\r\n"%~dp0node.exe" runtime.mjs\r\npause\r\n', { name: "ABRIR PLAN B.cmd" });
  archive.append("# Plan B \xB7 Aplicaci\xF3n independiente\n\n1. Extrae todo el ZIP en una carpeta.\n2. En Windows, abre ABRIR PLAN B.cmd.\n3. Abre en tu navegador la direcci\xF3n local que aparece en la ventana.\n\nLa aplicaci\xF3n incluye su copia de datos y no necesita HubSpot ni una clave de IA. Los cambios se guardan en data/planb.sqlite. Conserva esa carpeta al mover la aplicaci\xF3n. Cierra la ventana del servidor antes de trasladarla.\n\nEsta versi\xF3n es una demostraci\xF3n para un operador y datos de ensayo. La informaci\xF3n no se devuelve autom\xE1ticamente al CRM. Puedes exportar un JSON completo o un informe de cambios CSV.\n\nLa captura original y el historial de cambios est\xE1n en continuity.seed.json. La base SQLite activa prevalece sobre ese archivo despu\xE9s del primer inicio.\n\nNo se incluyen credenciales ni configuraci\xF3n del generador.\n", { name: "LEEME.md" });
  await archive.finalize();
  return finished;
}

// server/app.ts
async function createBaseApp(options) {
  const store2 = new Store(options.dbPath);
  if (options.runtime) store2.set("disconnected", true);
  const app2 = Fastify({ logger: false, bodyLimit: 20 * 1024 * 1024, requestTimeout: 18e4 });
  app2.addHook("onClose", async () => {
    store2.close();
  });
  app2.addHook("onRequest", async (request, reply) => {
    const host = request.headers.host ?? "";
    if (!/^(127\.0\.0\.1|localhost|\[::1\])(?::\d+)?$/i.test(host)) return reply.code(403).send({ error: "Esta aplicaci\xF3n solo acepta acceso local." });
    const origin = request.headers.origin;
    if (origin) {
      let allowed = false;
      try {
        const value = new URL(origin);
        allowed = value.protocol === "http:" && (value.host === host || ["127.0.0.1:5187", "localhost:5187"].includes(value.host) && !options.runtime);
      } catch {
      }
      if (!allowed) return reply.code(403).send({ error: "Origen no permitido." });
    }
    reply.header("X-Content-Type-Options", "nosniff");
    reply.header("Referrer-Policy", "no-referrer");
    reply.header("Cache-Control", "no-store");
    reply.header("Content-Security-Policy", "default-src 'self'; connect-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; font-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
  });
  app2.setErrorHandler((error, _request, reply) => {
    if (error instanceof AppError) return reply.code(error.status).send({ error: error.message, details: error.details ?? null });
    if (error instanceof z2.ZodError) return reply.code(422).send({ error: "Revisa los datos enviados.", details: error.flatten() });
    const status = error && typeof error === "object" && "statusCode" in error ? Number(error.statusCode) : 500;
    return reply.code(status >= 400 && status < 500 ? status : 500).send({ error: status === 413 ? "El archivo es demasiado grande." : "No se pudo completar la operaci\xF3n. La \xFAltima copia v\xE1lida sigue guardada." });
  });
  app2.get("/api/state", async () => ({
    snapshot: store2.snapshot,
    spec: store2.spec,
    generation: store2.generation,
    reconciliation: store2.reconciliation,
    disconnected: store2.disconnected,
    runtime: !!options.runtime,
    ready: store2.ready,
    changes: store2.changesCount,
    usage: store2.usage(),
    aiConfigured: !options.runtime && (options.aiConfigured?.() ?? false),
    hubspotConfigured: !options.runtime && (options.hubspotConfigured?.() ?? false),
    lastError: store2.get("lastError", null),
    aiSettings: options.runtime ? null : options.aiPublic?.() ?? null
  }));
  app2.get("/api/records", async () => ({ records: store2.records() }));
  app2.get("/api/records/:entity", async (request) => {
    const entity = EntityNameSchema.parse(request.params.entity);
    return { records: store2.records(entity) };
  });
  app2.post("/api/records/:entity", async (request) => {
    const entity = EntityNameSchema.parse(request.params.entity);
    const body = z2.object({ values: z2.record(z2.union([z2.string(), z2.number().finite(), z2.boolean(), z2.null()])) }).strict().parse(request.body);
    return { record: store2.saveRecord(entity, body.values) };
  });
  app2.patch("/api/records/:entity/:id", async (request) => {
    const entity = EntityNameSchema.parse(request.params.entity);
    const body = z2.object({ values: z2.record(z2.union([z2.string(), z2.number().finite(), z2.boolean(), z2.null()])) }).strict().parse(request.body);
    return { record: store2.saveRecord(entity, body.values, request.params.id) };
  });
  app2.post("/api/activate", async (request) => {
    z2.object({ reviewed: z2.literal(true) }).strict().parse(request.body);
    store2.activate();
    return { ready: true };
  });
  app2.post("/api/disconnect", async (request) => {
    const { disconnected } = z2.object({ disconnected: z2.boolean() }).strict().parse(request.body);
    if (options.runtime && !disconnected) throw new AppError(403, "El paquete independiente no contiene conectores externos.");
    if (disconnected && !store2.ready) throw new AppError(409, "Activa una aplicaci\xF3n verificada antes de desconectar.");
    store2.set("disconnected", disconnected);
    return { disconnected };
  });
  app2.get("/api/changes", async () => ({ changes: store2.changes() }));
  app2.post("/api/probe", async () => {
    const spec = store2.spec, snapshot = store2.snapshot, generation = store2.generation;
    const records = store2.records();
    const ruleErrors = spec && snapshot && generation ? validateSpec(spec, snapshot, generation.prompt) : ["Falta una aplicaci\xF3n generada."];
    const dataErrors = spec ? records.flatMap((record) => Object.values(validateRecord(spec, record))) : ["Falta una especificaci\xF3n."];
    const probeValue = (/* @__PURE__ */ new Date()).toISOString();
    store2.transaction(() => store2.set("lastProbe", probeValue));
    const checks = [
      { id: "snapshot", label: "Captura completa y relaciones conciliadas", passed: !!store2.reconciliation?.complete },
      { id: "schema", label: "Especificaci\xF3n y reglas verificadas", passed: !!spec && ruleErrors.length === 0 },
      { id: "data", label: "Registros compatibles con la aplicaci\xF3n", passed: !!spec && dataErrors.length === 0 },
      { id: "persistence", label: "Lectura y escritura en SQLite local", passed: store2.get("lastProbe", "") === probeValue },
      { id: "disconnected", label: "Servicios externos desconectados", passed: store2.disconnected },
      { id: "approved", label: "Reglas revisadas y aplicaci\xF3n activada", passed: store2.ready }
    ];
    return {
      passed: checks.every((c) => c.passed),
      checks,
      at: probeValue,
      note: "Esta comprobaci\xF3n local no sustituye las pruebas automatizadas de reinicio y bloqueo de red incluidas en la entrega."
    };
  });
  app2.get("/api/export/bundle", async (_request, reply) => reply.header("Content-Disposition", 'attachment; filename="plan-b-continuidad.json"').send(store2.bundle()));
  app2.get("/api/export/changes", async (request, reply) => {
    const changes = store2.changes();
    if (request.query.format === "csv") {
      const quote = (value) => '"' + String(value ?? "").replace(/"/g, '""') + '"';
      const rows = [
        ["fecha", "entidad", "id", "operacion", "antes_json", "despues_json"],
        ...changes.map((c) => [c.at, c.entity, c.recordId, c.operation, JSON.stringify(c.before), JSON.stringify(c.after)])
      ];
      return reply.type("text/csv; charset=utf-8").header("Content-Disposition", 'attachment; filename="plan-b-cambios.csv"').send("\uFEFF" + rows.map((row) => row.map(quote).join(",")).join("\r\n"));
    }
    return reply.header("Content-Disposition", 'attachment; filename="plan-b-cambios.json"').send({ exportedAt: (/* @__PURE__ */ new Date()).toISOString(), changes });
  });
  app2.get("/api/export/package", async (_request, reply) => {
    const zip = await runtimeZip(store2.bundle(), options.root);
    return reply.type("application/zip").header("Content-Disposition", 'attachment; filename="Plan-B-independiente.zip"').send(zip);
  });
  if (existsSync2(options.staticDir)) {
    await app2.register(staticPlugin, { root: options.staticDir, prefix: "/", decorateReply: true });
    app2.setNotFoundHandler((request, reply) => {
      if (request.url.startsWith("/api/")) return reply.code(404).send({ error: "Operaci\xF3n no disponible en esta aplicaci\xF3n." });
      return reply.sendFile("index.html");
    });
  }
  return { app: app2, store: store2 };
}

// server/runtime.ts
var root = process.cwd();
var { app, store } = await createBaseApp({
  dbPath: resolve(process.env.PLANB_DATA_DIR || join2(root, "data"), "planb.sqlite"),
  root,
  staticDir: join2(root, "dist"),
  runtime: true
});
if (!store.snapshot) {
  const seed = join2(root, "continuity.seed.json");
  if (!existsSync3(seed)) throw new Error("Falta continuity.seed.json. Extrae el paquete completo antes de iniciar.");
  store.restoreBundle(JSON.parse(readFileSync2(seed, "utf8")));
}
var port = Number(process.env.PLANB_PORT || 4318);
for (; ; ) {
  try {
    await app.listen({ host: "127.0.0.1", port });
    break;
  } catch (error) {
    if (error.code === "EADDRINUSE" && !process.env.PLANB_PORT && port < 4328) {
      port++;
      continue;
    }
    throw error;
  }
}
console.log("\nPlan B \xB7 Aplicaci\xF3n independiente\nAbre http://127.0.0.1:" + port + "\nNo se utilizan servicios externos. Conserva la carpeta data con tus cambios.\n");
for (const signal of ["SIGINT", "SIGTERM"]) process.on(signal, () => {
  void app.close().then(() => process.exit(0));
});
