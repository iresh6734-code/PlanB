import archiver from 'archiver';
import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import type { ContinuityBundle } from '../shared/model.js';
import { AppError } from './store.js';

export async function runtimeZip(bundle: ContinuityBundle, root: string): Promise<Buffer> {
  const runtimeFile = existsSync(join(root, 'runtime.mjs')) ? join(root, 'runtime.mjs') : join(root, 'build', 'runtime.mjs');
  const frontend = join(root, 'dist');
  if (!existsSync(runtimeFile) || !existsSync(join(frontend, 'index.html'))) throw new AppError(503, 'El paquete necesita una compilación completa de la aplicación.');
  const archive = archiver('zip', { zlib: { level: 3 } });
  const chunks: Buffer[] = [];
  const finished = new Promise<Buffer>((resolve, reject) => {
    archive.on('data', data => chunks.push(Buffer.from(data)));
    archive.on('end', () => resolve(Buffer.concat(chunks)));
    archive.on('error', reject);
  });
  archive.append(readFileSync(runtimeFile), { name: 'runtime.mjs' });
  archive.append(JSON.stringify(bundle, null, 2), { name: 'continuity.seed.json' });
  archive.directory(frontend, 'dist');
  const moduleRoot = join(root, 'runtime-assets', 'node_modules');
  const runtimeModules = existsSync(moduleRoot) ? moduleRoot : join(root, 'node_modules');
  archive.directory(runtimeModules, 'node_modules', entry => {
    const name = entry.name.replace(/^node_modules\//, '');
    return !name.split('/').some(part => ['.cache', '.bin', 'lucide-react', 'react', 'react-dom', 'scheduler'].includes(part)) && !name.endsWith('.log') ? entry : false;
  });
  archive.file(process.execPath, { name: process.platform === 'win32' ? 'node.exe' : 'node' });
  const license = join(root, 'NODE-LICENSE.txt');
  if (existsSync(license)) archive.file(license, { name: 'NODE-LICENSE.txt' });
  archive.append('@echo off\r\ncd /d "%~dp0"\r\n"%~dp0node.exe" runtime.mjs\r\npause\r\n', { name: 'ABRIR PLAN B.cmd' });
  archive.append('# Plan B · Aplicación independiente\n\n1. Extrae todo el ZIP en una carpeta.\n2. En Windows, abre ABRIR PLAN B.cmd.\n3. Abre en tu navegador la dirección local que aparece en la ventana.\n\nLa aplicación incluye su copia de datos y no necesita HubSpot ni una clave de IA. Los cambios se guardan en data/planb.sqlite. Conserva esa carpeta al mover la aplicación. Cierra la ventana del servidor antes de trasladarla.\n\nEsta versión es una demostración para un operador y datos de ensayo. La información no se devuelve automáticamente al CRM. Puedes exportar un JSON completo o un informe de cambios CSV.\n\nLa captura original y el historial de cambios están en continuity.seed.json. La base SQLite activa prevalece sobre ese archivo después del primer inicio.\n\nNo se incluyen credenciales ni configuración del generador.\n', { name: 'LEEME.md' });
  await archive.finalize();
  return finished;
}
