import { randomUUID } from 'node:crypto';
import { entityNames, type CrmSnapshot, type Entity, type EntityName, type Field, type FieldValue, type Link, type Rule } from '../shared/model.js';
import { AppError } from './store.js';

interface Property {
  name: string; label: string; type: string; fieldType?: string; hubspotDefined?: boolean;
  calculated?: boolean; hidden?: boolean; archived?: boolean;
  modificationMetadata?: { readOnlyValue?: boolean };
  options?: { value: string; label: string; hidden?: boolean }[];
}
interface HsRecord { id: string; properties: Record<string, string | null>; }
interface Page<T> { results: T[]; total?: number; paging?: { next?: { after: string | number } }; }
interface Pipeline { id: string; label: string; stages: { id: string; label: string }[]; }
interface Association {
  from: { id: string };
  to: { toObjectId: number | string; associationTypes?: { label: string | null; typeId: number }[] }[];
  paging?: { next?: { after: string | number } };
}
const basics: Record<EntityName, { label: string; singular: string; display: string; fields: string[]; columns: string[] }> = {
  contacts: { label: 'Clientes', singular: 'cliente', display: 'firstname', fields: ['firstname', 'lastname', 'email', 'phone'], columns: ['firstname', 'planb_company_id', 'email', 'phone'] },
  companies: { label: 'Empresas', singular: 'empresa', display: 'name', fields: ['name', 'domain', 'phone'], columns: ['name', 'domain', 'phone'] },
  deals: { label: 'Oportunidades', singular: 'oportunidad', display: 'dealname', fields: ['dealname', 'amount', 'dealstage', 'pipeline', 'closedate'], columns: ['dealname', 'planb_company_id', 'amount', 'dealstage'] },
  tasks: { label: 'Tareas', singular: 'tarea', display: 'hs_task_subject', fields: ['hs_task_subject', 'hs_task_status', 'hs_timestamp'], columns: ['hs_task_subject', 'hs_timestamp', 'hs_task_status', 'planb_contact_id'] }
};
const labels: Record<string, string> = {
  firstname: 'Nombre', lastname: 'Apellidos', email: 'Correo', phone: 'Teléfono', name: 'Nombre', domain: 'Sitio web',
  dealname: 'Nombre de la oportunidad', amount: 'Importe', dealstage: 'Etapa', pipeline: 'Proceso comercial', closedate: 'Fecha prevista de cierre',
  hs_task_subject: 'Asunto', hs_task_status: 'Estado', hs_timestamp: 'Fecha límite'
};
export interface HubspotOptions { token: string; accountId: string; name?: string; confirmedTestAccount: boolean; }
export async function importHubspot(options: HubspotOptions, fetcher: typeof fetch = fetch): Promise<CrmSnapshot> {
  if (!options.confirmedTestAccount || !/^\d+$/.test(options.accountId)) throw new AppError(422, 'Indica el ID y confirma que usarás una cuenta de prueba.');
  if (!options.token || options.token.length < 10) throw new AppError(422, 'Configura una Service Key o un token OAuth de lectura.');
  async function request<T>(currentPath: string, legacyPath?: string, body?: unknown): Promise<T> {
    const get = async (path: string) => {
      for (let attempt = 0; attempt < 3; attempt++) {
        let response: Response;
        try {
          response = await fetcher('https://api.hubapi.com' + path, {
            method: body === undefined ? 'GET' : 'POST',
            headers: { Authorization: 'Bearer ' + options.token, 'Content-Type': 'application/json' },
            ...(body === undefined ? {} : { body: JSON.stringify(body) }),
            signal: AbortSignal.timeout(30000), redirect: 'error'
          });
        } catch { throw new AppError(502, 'No se pudo conectar con HubSpot. La captura anterior se conserva.'); }
        if ((response.status === 429 || response.status >= 500) && attempt < 2) {
          const seconds = Math.min(Math.max(Number(response.headers.get('retry-after')) || 1, 1), 5);
          await new Promise(resolve => setTimeout(resolve, seconds * 1000)); continue;
        }
        return response;
      }
      throw new AppError(502, 'HubSpot no completó la lectura.');
    };
    let response = await get(currentPath);
    if (response.status === 404 && legacyPath) response = await get(legacyPath);
    if (response.status === 401) throw new AppError(401, 'HubSpot no aceptó la credencial.');
    if (response.status === 403) throw new AppError(403, 'Faltan permisos de lectura en HubSpot. Revisa los objetos, sus propiedades y external-settings-access.');
    if (!response.ok || response.status === 207) throw new AppError(502, 'HubSpot devolvió una lectura incompleta (' + response.status + ').');
    const data = await response.json() as T & { errors?: unknown[]; status?: string };
    if (data.errors?.length || data.status === 'PENDING' || data.status === 'PROCESSING') throw new AppError(502, 'HubSpot devolvió resultados parciales. No se sustituirá la captura.');
    return data;
  }
  const account = await request<{ portalId: number; accountType: string }>('/account-info/2026-09/details', '/account-info/v3/details');
  if (String(account.portalId) !== options.accountId) throw new AppError(422, 'La credencial no corresponde al ID de cuenta indicado.');
  if (!['DEVELOPER_TEST', 'SANDBOX'].includes(account.accountType)) throw new AppError(403, 'Esta demo solo importa cuentas de prueba o sandbox verificadas, no cuentas de producción.');
  const pipelineResponse = await request<Page<Pipeline>>('/crm/pipelines/2026-09/deals', '/crm/v3/pipelines/deals');
  if (!pipelineResponse.results?.length) throw new AppError(422, 'La cuenta de prueba necesita al menos un proceso comercial.');
  const stageMap = new Map<string, { id: string; label: string; color: string }>();
  const stageColors = ['#6685cc', '#a079d2', '#dc9f43', '#3b9b75', '#be7083'];
  for (const pipeline of pipelineResponse.results) for (const [i, stage] of pipeline.stages.entries()) {
    const existing = stageMap.get(stage.id);
    if (existing && existing.label !== stage.label) throw new AppError(422, 'Hay etapas con el mismo ID y distinto significado. Esta demo necesita revisarlas.');
    stageMap.set(stage.id, { id: stage.id, label: stage.label, color: stageColors[i % stageColors.length] });
  }
  const stages = [...stageMap.values()];
  const unsupported = [
    'Campañas y envío de correos', 'Permisos multiusuario', 'Automatizaciones de terceros',
    'Devolución automática de cambios al CRM', 'Registros archivados y archivos adjuntos',
    'Reglas de negocio no expuestas en las propiedades importadas'
  ];
  const entities: Entity[] = [];
  const records: CrmSnapshot['records'] = [];
  const expectedCounts: Record<string, number> = {};
  for (const entity of entityNames) {
    const meta = await request<Page<Property>>('/crm/properties/2026-09/' + entity, '/crm/v3/properties/' + entity);
    const selected = meta.results.filter(p => !p.archived && (basics[entity].fields.includes(p.name) || p.hubspotDefined === false && !p.hidden));
    if (selected.length > 60) throw new AppError(422, 'La demo admite hasta 60 propiedades por objeto. Selecciona una cuenta de ensayo más pequeña.');
    if (!selected.some(p => p.name === basics[entity].display)) throw new AppError(422, 'Falta un campo principal del objeto ' + entity + '.');
    const fields: Field[] = selected.map(p => {
      let type: Field['type'] = p.type === 'number' ? 'number' : p.type === 'date' ? 'date'
        : p.type === 'bool' ? 'boolean' : p.type === 'enumeration' && p.fieldType !== 'checkbox' ? 'enum' : p.name === 'email' ? 'email' : 'text';
      let choices = (p.options ?? []).filter(o => !o.hidden).map(o => ({ id: o.value, label: o.label }));
      if (p.name === 'dealstage') { type = 'enum'; choices = stages.map(s => ({ id: s.id, label: s.label })); }
      if (p.name === 'pipeline') { type = 'enum'; choices = pipelineResponse.results.map(s => ({ id: s.id, label: s.label })); }
      const readOnly = !!(p.calculated || p.modificationMetadata?.readOnlyValue || p.type === 'datetime' || p.fieldType === 'checkbox');
      if (p.type === 'enumeration' && !choices.length && p.name !== 'dealstage' && p.name !== 'pipeline') type = 'text';
      if (readOnly) unsupported.push('Campo conservado como solo lectura: ' + entity + '.' + p.name);
      return { key: p.name, label: labels[p.name] ?? p.label, type,
        required: false, readOnly, options: choices, referenceEntity: null };
    });
    const propertyNames = selected.map(p => p.name).join(',');
    const list: HsRecord[] = [];
    let after = '', previous = new Set<string>();
    do {
      const query = '?limit=100&archived=false&properties=' + encodeURIComponent(propertyNames) + (after ? '&after=' + encodeURIComponent(after) : '');
      const page = await request<Page<HsRecord>>('/crm/objects/2026-09/' + entity + query, '/crm/v3/objects/' + entity + query);
      if (!Array.isArray(page.results)) throw new AppError(502, 'HubSpot no devolvió la colección completa.');
      list.push(...page.results);
      if (list.length > 10000) throw new AppError(413, 'La demo admite hasta 10.000 registros por objeto.');
      after = page.paging?.next ? String(page.paging.next.after) : '';
      if (after && previous.has(after)) throw new AppError(502, 'HubSpot repitió un cursor de paginación.');
      if (after) previous.add(after);
    } while (after);
    const count = await request<Page<HsRecord>>('/crm/objects/2026-09/' + entity + '/search', '/crm/v3/objects/' + entity + '/search', { limit: 1 });
    if (typeof count.total !== 'number' || count.total !== list.length) throw new AppError(422, 'El recuento de ' + basics[entity].label.toLowerCase() + ' no coincide. Espera a que el CRM termine de actualizarse y reintenta.');
    expectedCounts[entity] = count.total;
    for (const item of list) {
      const values: Record<string, FieldValue> = {};
      for (const definition of fields) {
        const raw = item.properties[definition.key];
        if (raw === null || raw === undefined || raw === '') { values[definition.key] = null; continue; }
        if (definition.type === 'number') {
          const number = Number(raw);
          if (!Number.isFinite(number)) throw new AppError(422, 'Hay un valor numérico no válido en ' + definition.key + '.');
          values[definition.key] = number;
        } else if (definition.type === 'boolean') values[definition.key] = raw === 'true';
        else if (definition.type === 'date' && /^\d{13}$/.test(raw)) values[definition.key] = new Date(Number(raw)).toISOString().slice(0, 10);
        else values[definition.key] = raw;
      }
      records.push({ id: item.id, entity, values });
    }
    entities.push({ id: entity, label: basics[entity].label, singular: basics[entity].singular,
      displayField: basics[entity].display, fields, columns: basics[entity].columns.filter(k => fields.some(f => f.key === k)) });
  }
  const links: Link[] = [];
  const targets: [EntityName, EntityName, string, string][] = [
    ['contacts', 'companies', 'planb_company_id', 'Empresa principal'],
    ['deals', 'companies', 'planb_company_id', 'Empresa principal'],
    ['deals', 'contacts', 'planb_contact_id', 'Cliente principal'],
    ['tasks', 'contacts', 'planb_contact_id', 'Cliente principal'],
    ['tasks', 'deals', 'planb_deal_id', 'Oportunidad']
  ];
  for (const [from, to, key, label] of targets) {
    const definition = entities.find(e => e.id === from)!;
    if (definition.fields.some(f => f.key === key)) throw new AppError(422, 'Un campo del origen ocupa el espacio reservado a las relaciones.');
    definition.fields.push({ key, label, type: 'reference', required: false, readOnly: false, options: [], referenceEntity: to });
    if (basics[from].columns.includes(key)) definition.columns.splice(1, 0, key);
    const sourceRecords = records.filter(r => r.entity === from);
    const available = new Set(records.filter(r => r.entity === to).map(r => r.id));
    for (let offset = 0; offset < sourceRecords.length; offset += 100) {
      let pending: { id: string; after?: string }[] = sourceRecords.slice(offset, offset + 100).map(r => ({ id: r.id }));
      const chosen = new Map<string, string>();
      const cursors = new Set<string>();
      let pageCount = 0;
      while (pending.length) {
        if (++pageCount > 100) throw new AppError(422, 'Hay demasiadas relaciones para esta demo.');
        const page = await request<Page<Association>>('/crm/associations/2026-09/' + from + '/' + to + '/batch/read',
          '/crm/v4/associations/' + from + '/' + to + '/batch/read', { inputs: pending });
        const next: typeof pending = [];
        const returned = new Set<string>();
        for (const item of page.results) {
          returned.add(item.from.id);
          for (const target of item.to) {
            const targetId = String(target.toObjectId);
            if (!available.has(targetId)) throw new AppError(422, 'Una relación apunta a un registro fuera de la captura. Revisa los registros archivados y permisos.');
            links.push({ fromEntity: from, fromId: item.from.id, toEntity: to, toId: targetId, label: key });
            const isPrimary = target.associationTypes?.some(t => /^(primary|principal)$/i.test(t.label ?? ''));
            if (!chosen.has(item.from.id) || isPrimary) chosen.set(item.from.id, targetId);
          }
          if (item.paging?.next) {
            const after = String(item.paging.next.after);
            const cursorKey = item.from.id + ':' + after;
            if (cursors.has(cursorKey)) throw new AppError(502, 'HubSpot repitió una página de relaciones.');
            cursors.add(cursorKey); next.push({ id: item.from.id, after });
          }
        }
        if (pending.some(input => !returned.has(input.id))) throw new AppError(502, 'HubSpot omitió registros al leer las relaciones.');
        pending = next;
      }
      for (const record of sourceRecords.slice(offset, offset + 100)) record.values[key] = chosen.get(record.id) ?? null;
    }
  }
  const email = entities.find(e => e.id === 'contacts')!.fields.find(f => f.key === 'email' && !f.readOnly);
  const rules: Rule[] = email ? [{
    id: 'hubspot-contact-email', entity: 'contacts', kind: 'email', field: 'email', value: null, whenField: null, whenValue: null,
    origin: 'configuration', description: 'El correo debe tener un formato válido.', evidence: 'Propiedad de correo importada de HubSpot: contacts.email.'
  }] : [];
  return {
    version: 1, id: randomUUID(), name: options.name?.trim() || 'HubSpot de ensayo · ' + account.portalId,
    capturedAt: new Date().toISOString(),
    source: { kind: 'hubspot', accountId: String(account.portalId), isTestData: true, description: 'Cuenta ' + account.accountType + '. Objetos activos, propiedades estándar y personalizadas, relaciones verificadas.' },
    entities, records, links, stages, rules, unsupported: [...new Set(unsupported)],
    manifest: { complete: true, expectedCounts, expectedLinks: links.length }
  };
}
