import { existsSync, readFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { createBaseApp } from './app.js';
// Deliberately does not import the generator, provider settings, or CRM connector.
const root = process.cwd();
const { app, store } = await createBaseApp({
  dbPath: resolve(process.env.PLANB_DATA_DIR || join(root, 'data'), 'planb.sqlite'),
  root, staticDir: join(root, 'dist'), runtime: true
});
if (!store.snapshot) {
  const seed = join(root, 'continuity.seed.json');
  if (!existsSync(seed)) throw new Error('Falta continuity.seed.json. Extrae el paquete completo antes de iniciar.');
  store.restoreBundle(JSON.parse(readFileSync(seed, 'utf8')));
}
let port = Number(process.env.PLANB_PORT || 4318);
for (;;) {
  try { await app.listen({ host: '127.0.0.1', port }); break; }
  catch (error) {
    if ((error as { code?: string }).code === 'EADDRINUSE' && !process.env.PLANB_PORT && port < 4328) { port++; continue; }
    throw error;
  }
}
console.log('\nPlan B · Aplicación independiente\nAbre http://127.0.0.1:' + port + '\nNo se utilizan servicios externos. Conserva la carpeta data con tus cambios.\n');
for (const signal of ['SIGINT', 'SIGTERM'] as const) process.on(signal, () => { void app.close().then(() => process.exit(0)); });
