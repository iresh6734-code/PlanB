import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { randomUUID } from 'node:crypto';
import {
  AppSpecSchema, BundleSchema, RecordSchema, SnapshotSchema, reconcile, validateRecord, validateSpec,
  type AppSpec, type Change, type ContinuityBundle, type CrmRecord, type CrmSnapshot,
  type EntityName, type Generation, type Reconciliation
} from '../shared/model.js';

export class AppError extends Error {
  constructor(public status: number, message: string, public details?: unknown) { super(message); }
}
export class Store {
  db: DatabaseSync;
  constructor(public filename: string) {
    if (filename !== ':memory:') mkdirSync(dirname(filename), { recursive: true });
    this.db = new DatabaseSync(filename);
    this.db.exec(
      'PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;' +
      'CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);' +
      'CREATE TABLE IF NOT EXISTS records(entity TEXT NOT NULL,id TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY(entity,id));' +
      'CREATE TABLE IF NOT EXISTS changes(id INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT NOT NULL,entity TEXT NOT NULL,record_id TEXT NOT NULL,operation TEXT NOT NULL,before_json TEXT,after_json TEXT NOT NULL);' +
      'CREATE TABLE IF NOT EXISTS archives(id TEXT PRIMARY KEY,at TEXT NOT NULL,bundle TEXT NOT NULL);' +
      'CREATE TABLE IF NOT EXISTS usage(id TEXT PRIMARY KEY,month TEXT NOT NULL,reserved_usd REAL NOT NULL,used_usd REAL NOT NULL DEFAULT 0,status TEXT NOT NULL);'
    );
    // A killed generation must not silently release its worst-case reservation.
    this.db.prepare("UPDATE usage SET status='interrupted' WHERE status='pending'").run();
  }
  close() { this.db.close(); }
  get<T>(key: string, fallback: T): T {
    const row = this.db.prepare('SELECT value FROM meta WHERE key=?').get(key) as { value: string } | undefined;
    return row ? JSON.parse(row.value) as T : fallback;
  }
  set(key: string, value: unknown) {
    this.db.prepare('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(key, JSON.stringify(value));
  }
  get snapshot() { return this.get<CrmSnapshot | null>('snapshot', null); }
  get spec() { return this.get<AppSpec | null>('spec', null); }
  get generation() { return this.get<Generation | null>('generation', null); }
  get reconciliation() { return this.get<Reconciliation | null>('reconciliation', null); }
  get disconnected() { return this.get('disconnected', false); }
  get ready() {
    return !!(this.snapshot && this.spec && this.generation?.approved &&
      this.reconciliation?.complete && !this.get<string | null>('lastError', null));
  }
  get changesCount() {
    return Number((this.db.prepare('SELECT COUNT(*) AS n FROM changes').get() as { n: number }).n);
  }
  transaction<T>(fn: () => T): T {
    this.db.exec('BEGIN IMMEDIATE');
    try { const result = fn(); this.db.exec('COMMIT'); return result; }
    catch (error) { this.db.exec('ROLLBACK'); throw error; }
  }
  importSnapshot(raw: unknown, replace = false): Reconciliation {
    const parsed = SnapshotSchema.safeParse(raw);
    if (!parsed.success) throw new AppError(422, 'La captura tiene un formato no válido.', parsed.error.flatten());
    const snapshot = parsed.data;
    const report = reconcile(snapshot);
    const ruleErrors = validateSpec({
      version: 1, title: snapshot.name, description: '', entities: snapshot.entities,
      stages: snapshot.stages, rules: snapshot.rules,
      coverage: { supported: ['Datos del origen'], unsupported: snapshot.unsupported }
    }, snapshot);
    report.errors.push(...ruleErrors);
    report.complete = report.errors.length === 0;
    if (!report.complete) {
      this.set('lastImportError', report);
      throw new AppError(422, 'Importación incompleta. Se conserva la última captura válida.', report);
    }
    if (this.changesCount && !replace) throw new AppError(409, 'Hay cambios locales. Exporta una copia antes de cambiar el origen.');
    this.transaction(() => {
      const existing = this.bundleOrNull();
      if (existing) this.db.prepare('INSERT INTO archives(id,at,bundle) VALUES(?,?,?)').run(randomUUID(), new Date().toISOString(), JSON.stringify(existing));
      this.db.exec('DELETE FROM records; DELETE FROM changes;');
      for (const record of snapshot.records) this.insertRecord(record);
      this.set('snapshot', snapshot); this.set('reconciliation', report);
      this.set('spec', null); this.set('generation', null); this.set('lastError', null);
      this.set('lastImportError', null); this.set('disconnected', false);
    });
    return report;
  }
  saveGeneration(raw: unknown, generation: Generation) {
    const snapshot = this.snapshot;
    if (!snapshot) throw new AppError(409, 'Importa primero una captura.');
    const parsed = AppSpecSchema.safeParse(raw);
    const errors = parsed.success ? validateSpec(parsed.data, snapshot, generation.prompt)
      : ['La especificación no cumple el contrato de la aplicación.'];
    if (errors.length || !parsed.success) {
      this.set('lastError', 'La generación no superó la validación.');
      const old = this.generation; if (old) this.set('generation', { ...old, approved: false });
      throw new AppError(422, 'La aplicación no está preparada. Revisa la generación.', errors);
    }
    this.transaction(() => { this.set('spec', parsed.data); this.set('generation', { ...generation, approved: false }); this.set('lastError', null); });
  }
  failGeneration(message: string) {
    this.set('lastError', message);
    if (this.generation) this.set('generation', { ...this.generation, approved: false });
  }
  activate() {
    const spec = this.spec, snapshot = this.snapshot, generation = this.generation;
    if (!spec || !snapshot || !generation) throw new AppError(409, 'Genera primero una especificación.');
    if (this.get('lastError', null)) throw new AppError(409, 'La última generación falló. Vuelve a generarla.');
    const errors = validateSpec(spec, snapshot, generation.prompt);
    for (const record of this.records()) {
      const issues = validateRecord(spec, record);
      for (const [key, message] of Object.entries(issues)) errors.push(record.entity + '/' + record.id + '/' + key + ': ' + message);
    }
    if (!this.reconciliation?.complete || errors.length) {
      this.set('lastError', 'Hay datos o reglas que necesitan revisión.');
      throw new AppError(422, 'No se puede activar todavía.', errors.slice(0, 50));
    }
    this.set('generation', { ...generation, approved: true });
  }
  insertRecord(record: CrmRecord) {
    this.db.prepare('INSERT INTO records(entity,id,value) VALUES(?,?,?) ON CONFLICT(entity,id) DO UPDATE SET value=excluded.value')
      .run(record.entity, record.id, JSON.stringify(record));
  }
  records(entity?: EntityName): CrmRecord[] {
    const rows = entity ? this.db.prepare('SELECT value FROM records WHERE entity=? ORDER BY rowid').all(entity)
      : this.db.prepare('SELECT value FROM records ORDER BY rowid').all();
    return (rows as { value: string }[]).map(r => JSON.parse(r.value) as CrmRecord);
  }
  record(entity: EntityName, id: string): CrmRecord | null {
    const row = this.db.prepare('SELECT value FROM records WHERE entity=? AND id=?').get(entity, id) as { value: string } | undefined;
    return row ? JSON.parse(row.value) as CrmRecord : null;
  }
  saveRecord(entity: EntityName, values: CrmRecord['values'], id?: string): CrmRecord {
    if (!this.ready || !this.spec) throw new AppError(409, 'Revisa y activa primero la aplicación.');
    const previous = id ? this.record(entity, id) : null;
    if (id && !previous) throw new AppError(404, 'No se encontró el registro.');
    const record = RecordSchema.parse({ entity, id: id ?? 'local-' + randomUUID(), values: previous ? { ...previous.values, ...values } : values });
    const errors = validateRecord(this.spec, record, previous);
    const definition = this.spec.entities.find(e => e.id === entity)!;
    for (const field of definition.fields) {
      const value = record.values[field.key];
      if (field.type === 'reference' && value && field.referenceEntity && !this.record(field.referenceEntity, String(value))) {
        errors[field.key] = 'El registro relacionado no existe.';
      }
      if (!previous && field.readOnly && value !== undefined && value !== null && value !== '') errors[field.key] = 'Este campo no se puede crear manualmente.';
    }
    if (Object.keys(errors).length) throw new AppError(422, 'Revisa los campos señalados.', errors);
    this.transaction(() => {
      this.insertRecord(record);
      this.db.prepare('INSERT INTO changes(at,entity,record_id,operation,before_json,after_json) VALUES(?,?,?,?,?,?)')
        .run(new Date().toISOString(), entity, record.id, previous ? 'update' : 'create', previous ? JSON.stringify(previous) : null, JSON.stringify(record));
    });
    return record;
  }
  changes(): Change[] {
    return (this.db.prepare('SELECT * FROM changes ORDER BY id').all() as unknown as {
      id: number; at: string; entity: EntityName; record_id: string;
      operation: Change['operation']; before_json: string | null; after_json: string
    }[]).map(r => ({
      id: r.id, at: r.at, entity: r.entity, recordId: r.record_id, operation: r.operation,
      before: r.before_json ? JSON.parse(r.before_json) : null, after: JSON.parse(r.after_json)
    }));
  }
  bundleOrNull(): ContinuityBundle | null {
    const snapshot = this.snapshot, spec = this.spec, generation = this.generation;
    if (!snapshot || !spec || !generation) return null;
    return { format: 'planb-continuity-v1', exportedAt: new Date().toISOString(), snapshot, spec, generation, records: this.records(), changes: this.changes() };
  }
  bundle(): ContinuityBundle {
    if (!this.ready) throw new AppError(409, 'Activa una aplicación verificada antes de exportar.');
    return this.bundleOrNull()!;
  }
  restoreBundle(raw: unknown) {
    const parsed = BundleSchema.safeParse(raw);
    if (!parsed.success) throw new AppError(422, 'El paquete de continuidad no es válido.');
    const bundle = parsed.data;
    const report = reconcile(bundle.snapshot);
    const errors = validateSpec(bundle.spec, bundle.snapshot, bundle.generation.prompt);
    const ids = new Set(bundle.records.map(r => r.entity + ':' + r.id));
    if (ids.size !== bundle.records.length) errors.push('Registros activos duplicados.');
    for (const baseline of bundle.snapshot.records) {
      if (!ids.has(baseline.entity + ':' + baseline.id)) errors.push('El paquete perdió un registro de la captura.');
    }
    for (const record of bundle.records) {
      for (const [field, message] of Object.entries(validateRecord(bundle.spec, record))) errors.push(record.id + '/' + field + ': ' + message);
      const entity = bundle.spec.entities.find(e => e.id === record.entity);
      for (const field of entity?.fields ?? []) if (field.type === 'reference' && record.values[field.key] &&
        !ids.has(field.referenceEntity + ':' + String(record.values[field.key]))) errors.push('Referencia inválida en el paquete.');
    }
    if (!report.complete || errors.length || !bundle.generation.approved) throw new AppError(422, 'El paquete no superó la comprobación de integridad.', [...report.errors, ...errors]);
    this.transaction(() => {
      this.db.exec('DELETE FROM records; DELETE FROM changes;');
      for (const record of bundle.records) this.insertRecord(record);
      for (const change of bundle.changes) this.db.prepare('INSERT INTO changes(id,at,entity,record_id,operation,before_json,after_json) VALUES(?,?,?,?,?,?,?)')
        .run(change.id, change.at, change.entity, change.recordId, change.operation, change.before ? JSON.stringify(change.before) : null, JSON.stringify(change.after));
      this.set('snapshot', bundle.snapshot); this.set('spec', bundle.spec); this.set('generation', bundle.generation);
      this.set('reconciliation', report); this.set('lastError', null); this.set('disconnected', true);
    });
  }
  usage() {
    const month = new Date().toISOString().slice(0, 7);
    const row = this.db.prepare("SELECT COALESCE(SUM(used_usd),0) AS used,COALESCE(SUM(CASE WHEN status IN ('pending','interrupted') THEN reserved_usd ELSE 0 END),0) AS reserved,COUNT(*) AS requests FROM usage WHERE month=?").get(month) as { used: number; reserved: number; requests: number };
    return { usedUsd: row.used, reservedUsd: row.reserved, limitUsd: 25, requests: row.requests };
  }
  reserveUsage(worstCaseUsd: number): string {
    if (!Number.isFinite(worstCaseUsd) || worstCaseUsd < 0) throw new AppError(422, 'La reserva de presupuesto no es válida.');
    const id = randomUUID(), month = new Date().toISOString().slice(0, 7);
    this.transaction(() => {
      const used = this.usage();
      if (used.usedUsd + used.reservedUsd + worstCaseUsd > used.limitUsd) throw new AppError(429, 'Se alcanzó el límite local de 25 USD para pruebas de IA.');
      this.db.prepare("INSERT INTO usage(id,month,reserved_usd,used_usd,status) VALUES(?,?,?,0,'pending')").run(id, month, worstCaseUsd);
    });
    return id;
  }
  settleUsage(id: string, usd: number) {
    if (!Number.isFinite(usd) || usd < 0) throw new AppError(422, 'El coste comunicado por el proveedor no es válido.');
    this.db.prepare("UPDATE usage SET used_usd=?,reserved_usd=0,status='complete' WHERE id=?").run(usd, id);
  }
}
