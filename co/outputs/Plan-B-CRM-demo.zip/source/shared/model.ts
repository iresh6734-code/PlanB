import { z } from 'zod';

export const entityNames = ['contacts', 'companies', 'deals', 'tasks'] as const;
export const EntityNameSchema = z.enum(entityNames);
export type EntityName = z.infer<typeof EntityNameSchema>;
export type FieldValue = string | number | boolean | null;
const valueSchema = z.union([z.string(), z.number().finite(), z.boolean(), z.null()]);
export const FieldSchema = z.object({
  key: z.string().regex(/^[a-zA-Z][a-zA-Z0-9_]{0,99}$/),
  label: z.string().min(1).max(100),
  type: z.enum(['text', 'email', 'number', 'date', 'enum', 'reference', 'boolean']),
  required: z.boolean(),
  readOnly: z.boolean(),
  options: z.array(z.object({ id: z.string(), label: z.string() }).strict()),
  referenceEntity: EntityNameSchema.nullable()
}).strict();
export type Field = z.infer<typeof FieldSchema>;
export const RuleSchema = z.object({
  id: z.string().min(1).max(100),
  entity: EntityNameSchema,
  kind: z.enum(['required', 'email', 'min', 'conditional_required', 'allowed_transition']),
  field: z.string(),
  value: z.string().nullable(),
  whenField: z.string().nullable(),
  whenValue: z.string().nullable(),
  origin: z.enum(['configuration', 'user']),
  description: z.string().min(1).max(500),
  evidence: z.string().min(1).max(1000)
}).strict();
export type Rule = z.infer<typeof RuleSchema>;
export const EntitySchema = z.object({
  id: EntityNameSchema,
  label: z.string().min(1),
  singular: z.string().min(1),
  displayField: z.string(),
  columns: z.array(z.string()).min(1),
  fields: z.array(FieldSchema).min(1)
}).strict();
export type Entity = z.infer<typeof EntitySchema>;
export const RecordSchema = z.object({
  id: z.string().min(1),
  entity: EntityNameSchema,
  values: z.record(valueSchema)
}).strict();
export type CrmRecord = z.infer<typeof RecordSchema>;
export const StageSchema = z.object({
  id: z.string(),
  label: z.string(),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/)
}).strict();
export const LinkSchema = z.object({
  fromEntity: EntityNameSchema, fromId: z.string(),
  toEntity: EntityNameSchema, toId: z.string(), label: z.string()
}).strict();
export type Link = z.infer<typeof LinkSchema>;
export const SnapshotSchema = z.object({
  version: z.literal(1),
  id: z.string(),
  name: z.string().min(1),
  capturedAt: z.string().datetime(),
  source: z.object({
    kind: z.enum(['fixture', 'hubspot', 'archive']),
    accountId: z.string(),
    isTestData: z.literal(true),
    description: z.string()
  }).strict(),
  entities: z.array(EntitySchema).length(4),
  records: z.array(RecordSchema).max(40000),
  links: z.array(LinkSchema).max(200000),
  stages: z.array(StageSchema).min(1),
  rules: z.array(RuleSchema),
  unsupported: z.array(z.string()),
  manifest: z.object({
    complete: z.boolean(),
    expectedCounts: z.record(z.number().int().nonnegative()),
    expectedLinks: z.number().int().nonnegative()
  }).strict()
}).strict();
export type CrmSnapshot = z.infer<typeof SnapshotSchema>;
export const AppSpecSchema = z.object({
  version: z.literal(1),
  title: z.string().min(1).max(100),
  description: z.string().max(500),
  entities: z.array(EntitySchema).length(4),
  stages: z.array(StageSchema).min(1),
  rules: z.array(RuleSchema),
  coverage: z.object({
    supported: z.array(z.string()),
    unsupported: z.array(z.string())
  }).strict()
}).strict();
export type AppSpec = z.infer<typeof AppSpecSchema>;
export const GenerationSchema = z.object({
  provider: z.enum(['demo', 'ai']),
  model: z.string().nullable(),
  generatedAt: z.string().datetime(),
  prompt: z.string(),
  approved: z.boolean()
}).strict();
export type Generation = z.infer<typeof GenerationSchema>;
export interface Change {
  id: number; at: string; entity: EntityName; recordId: string;
  operation: 'create' | 'update';
  before: CrmRecord | null; after: CrmRecord;
}
export interface Reconciliation {
  complete: boolean;
  counts: Record<string, { expected: number; actual: number }>;
  expectedLinks: number;
  actualLinks: number;
  errors: string[];
}
export interface AppState {
  snapshot: CrmSnapshot | null;
  spec: AppSpec | null;
  generation: Generation | null;
  reconciliation: Reconciliation | null;
  disconnected: boolean;
  runtime: boolean;
  ready: boolean;
  changes: number;
  aiConfigured: boolean;
  hubspotConfigured: boolean;
  usage: { usedUsd: number; reservedUsd: number; limitUsd: number; requests: number };
  lastError: string | null;
  aiSettings: {
    preset: string; baseUrl: string; model: string; hasKey: boolean;
    inputUsdPerMillion: number | null; outputUsdPerMillion: number | null;
    outputMode: 'json_schema' | 'json_object'; maxOutputTokens: number;
  } | null;
}
export const BundleSchema = z.object({
  format: z.literal('planb-continuity-v1'),
  exportedAt: z.string().datetime(),
  snapshot: SnapshotSchema,
  spec: AppSpecSchema,
  generation: GenerationSchema,
  records: z.array(RecordSchema),
  changes: z.array(z.object({
    id: z.number().int(), at: z.string().datetime(), entity: EntityNameSchema,
    recordId: z.string(), operation: z.enum(['create', 'update']),
    before: RecordSchema.nullable(), after: RecordSchema
  }).strict())
}).strict();
export type ContinuityBundle = z.infer<typeof BundleSchema>;

export function reconcile(snapshot: CrmSnapshot): Reconciliation {
  const errors: string[] = [];
  const names = snapshot.entities.map(e => e.id);
  if (new Set(names).size !== 4 || entityNames.some(e => !names.includes(e))) {
    errors.push('La captura debe contener las cuatro entidades, sin duplicados.');
  }
  const ids = new Set<string>();
  for (const record of snapshot.records) {
    const id = record.entity + ':' + record.id;
    if (ids.has(id)) errors.push('Registro duplicado: ' + id);
    ids.add(id);
    const entity = snapshot.entities.find(e => e.id === record.entity);
    if (!entity) continue;
    const fields = new Map(entity.fields.map(f => [f.key, f]));
    for (const [key, value] of Object.entries(record.values)) {
      const field = fields.get(key);
      if (!field) errors.push('Campo sin definición: ' + record.entity + '.' + key);
      if (field?.type === 'reference' && value && field.referenceEntity &&
          !snapshot.records.some(r => r.entity === field.referenceEntity && r.id === String(value))) {
        errors.push('Referencia sin destino: ' + id + '.' + key);
      }
    }
  }
  for (const entity of snapshot.entities) {
    if (new Set(entity.fields.map(f => f.key)).size !== entity.fields.length) errors.push('Campos duplicados: ' + entity.id);
    if (!entity.fields.some(f => f.key === entity.displayField)) errors.push('Nombre principal no válido: ' + entity.id);
    if (entity.columns.some(k => !entity.fields.some(f => f.key === k))) errors.push('Columna desconocida: ' + entity.id);
  }
  const counts = Object.fromEntries(entityNames.map(name => {
    const actual = snapshot.records.filter(r => r.entity === name).length;
    const expected = snapshot.manifest.expectedCounts[name];
    if (expected === undefined || actual !== expected) errors.push('Recuento incompleto: ' + name);
    return [name, { expected: expected ?? 0, actual }];
  }));
  for (const link of snapshot.links) {
    if (!ids.has(link.fromEntity + ':' + link.fromId) || !ids.has(link.toEntity + ':' + link.toId)) {
      errors.push('Relación sin registro de origen o destino.');
    }
  }
  if (snapshot.links.length !== snapshot.manifest.expectedLinks) errors.push('Recuento incompleto de relaciones.');
  if (!snapshot.manifest.complete) errors.push('El origen no confirmó una captura completa.');
  return {
    complete: errors.length === 0, counts,
    expectedLinks: snapshot.manifest.expectedLinks, actualLinks: snapshot.links.length,
    errors: [...new Set(errors)]
  };
}

export function validateSpec(spec: AppSpec, snapshot: CrmSnapshot, userPrompt = ''): string[] {
  const errors: string[] = [];
  const seen = new Set<string>();
  for (const entity of spec.entities) {
    if (seen.has(entity.id)) errors.push('Entidad duplicada: ' + entity.id);
    seen.add(entity.id);
    const source = snapshot.entities.find(e => e.id === entity.id);
    if (!source) { errors.push('Entidad ajena al origen.'); continue; }
    const fields = new Map(source.fields.map(f => [f.key, f]));
    if (entity.fields.length !== source.fields.length) errors.push('Faltan campos importados: ' + entity.id);
    if (new Set(entity.fields.map(f => f.key)).size !== entity.fields.length) errors.push('Campos duplicados.');
    for (const field of entity.fields) {
      const original = fields.get(field.key);
      if (!original || field.type !== original.type || field.readOnly !== original.readOnly ||
          field.required !== original.required || field.referenceEntity !== original.referenceEntity ||
          JSON.stringify(field.options) !== JSON.stringify(original.options)) {
        errors.push('Se alteró la definición del campo: ' + entity.id + '.' + field.key);
      }
    }
    if (!fields.has(entity.displayField) || entity.columns.some(k => !fields.has(k))) errors.push('Vista con campos desconocidos.');
  }
  if (seen.size !== 4) errors.push('Faltan entidades.');
  if (JSON.stringify(spec.stages) !== JSON.stringify(snapshot.stages)) errors.push('Se alteraron las etapas del origen.');
  const ruleIds = new Set<string>();
  for (const rule of spec.rules) {
    if (ruleIds.has(rule.id)) errors.push('Regla duplicada.');
    ruleIds.add(rule.id);
    const entity = snapshot.entities.find(e => e.id === rule.entity);
    const field = entity?.fields.find(f => f.key === rule.field);
    if (!field || field.readOnly) errors.push('Regla sobre un campo no editable.');
    if (rule.whenField && !entity?.fields.some(f => f.key === rule.whenField)) errors.push('Condición sobre un campo desconocido.');
    if (rule.kind === 'conditional_required' && (!rule.whenField || rule.whenValue === null)) errors.push('Regla condicional incompleta.');
    if (rule.kind === 'conditional_required') {
      const condition = entity?.fields.find(f => f.key === rule.whenField);
      if (condition?.type === 'enum' && !condition.options.some(o => o.id === rule.whenValue)) errors.push('La condición usa una opción desconocida.');
    }
    if (rule.kind === 'min' && (field?.type !== 'number' || rule.value === null || !Number.isFinite(Number(rule.value)))) errors.push('Límite numérico no válido.');
    if (rule.kind === 'email' && field?.type !== 'email' && field?.type !== 'text') errors.push('Validación de correo no compatible.');
    if (rule.kind === 'allowed_transition') {
      const valid = new Set(snapshot.stages.map(s => s.id));
      if (rule.entity !== 'deals' || rule.field !== 'dealstage') errors.push('Las transiciones solo se aplican a la etapa de una oportunidad.');
      if (!rule.whenValue || !rule.value || !valid.has(rule.whenValue) || rule.value.split(',').some(v => !valid.has(v))) errors.push('Transición comercial desconocida.');
    }
    if (rule.origin === 'configuration' && !snapshot.rules.some(r => JSON.stringify(r) === JSON.stringify(rule))) {
      errors.push('Regla importada sin evidencia en la captura.');
    }
    if (rule.origin === 'user' && (!userPrompt.trim() || !userPrompt.includes(rule.evidence))) {
      errors.push('Regla de usuario sin una cita exacta de su instrucción.');
    }
  }
  for (const rule of snapshot.rules) {
    if (!spec.rules.some(r => JSON.stringify(r) === JSON.stringify(rule))) errors.push('Falta una regla del origen: ' + rule.id);
  }
  if (spec.coverage.supported.length === 0) errors.push('La aplicación debe declarar procesos cubiertos.');
  for (const limitation of snapshot.unsupported) {
    if (!spec.coverage.unsupported.includes(limitation)) errors.push('Falta declarar una limitación del origen.');
  }
  return [...new Set(errors)];
}

export function validateRecord(spec: AppSpec, record: CrmRecord, previous?: CrmRecord | null): Record<string, string> {
  const errors: Record<string, string> = {};
  const entity = spec.entities.find(e => e.id === record.entity);
  if (!entity) return { _form: 'Entidad desconocida.' };
  for (const key of Object.keys(record.values)) if (!entity.fields.some(f => f.key === key)) errors[key] = 'Campo desconocido.';
  for (const field of entity.fields) {
    const value = record.values[field.key];
    const empty = value === null || value === undefined || value === '';
    if (field.readOnly && previous && value !== previous.values[field.key]) errors[field.key] = 'Este campo es de solo lectura.';
    if (field.required && empty) errors[field.key] = 'Completa este campo.';
    if (empty) continue;
    if (field.type === 'number' && (typeof value !== 'number' || !Number.isFinite(value))) errors[field.key] = 'Introduce un número válido.';
    if (field.type === 'boolean' && typeof value !== 'boolean') errors[field.key] = 'Introduce un valor verdadero o falso.';
    if (['text', 'email', 'date', 'enum', 'reference'].includes(field.type) && typeof value !== 'string') errors[field.key] = 'Introduce un texto válido.';
    if (field.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value))) errors[field.key] = 'Introduce un correo válido.';
    if (field.type === 'date') {
      const text = String(value), parsed = Date.parse(text);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(text) || Number.isNaN(parsed) || new Date(parsed).toISOString().slice(0, 10) !== text) errors[field.key] = 'Introduce una fecha válida.';
    }
    if (field.type === 'enum' && !field.options.some(o => o.id === value)) errors[field.key] = 'Selecciona una opción válida.';
    if (typeof value === 'string' && value.length > 10000) errors[field.key] = 'El texto es demasiado largo.';
  }
  for (const rule of spec.rules.filter(r => r.entity === record.entity)) {
    const value = record.values[rule.field];
    const empty = value === null || value === undefined || value === '';
    if (rule.kind === 'required' && empty) errors[rule.field] = rule.description;
    if (rule.kind === 'email' && !empty && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value))) errors[rule.field] = rule.description;
    if (rule.kind === 'min' && !empty && Number(value) < Number(rule.value)) errors[rule.field] = rule.description;
    if (rule.kind === 'conditional_required' && String(record.values[rule.whenField!]) === rule.whenValue && empty) errors[rule.field] = rule.description;
    if (rule.kind === 'allowed_transition' && previous && previous.values[rule.field] !== value &&
        String(previous.values[rule.field]) === rule.whenValue && !rule.value!.split(',').includes(String(value))) errors[rule.field] = rule.description;
  }
  return errors;
}
