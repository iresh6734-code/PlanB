@echo off
cd /d "%~dp0"
echo Plan B CRM - Demo local. Abre la direccion que aparece a continuacion.
"%~dp0node.exe" server.mjs
pause
