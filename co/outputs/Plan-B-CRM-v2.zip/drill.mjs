// server/drill-worker.ts
import { randomUUID as randomUUID2 } from "node:crypto";
import { mkdirSync as mkdirSync3, mkdtempSync, rmSync } from "node:fs";
import { resolve, join as join2 } from "node:path";

// server/store.ts
import { DatabaseSync } from "node:sqlite";
import { mkdirSync as mkdirSync2 } from "node:fs";
import { dirname as dirname2 } from "node:path";
import { randomUUID } from "node:crypto";

// server/crypto.ts
import { randomBytes, createCipheriv, createDecipheriv, scryptSync } from "node:crypto";
import { existsSync, readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
function dpapi(value, decrypt) {
  const method = decrypt ? "Unprotect" : "Protect";
  const script = "Add-Type -AssemblyName System.Security; $v=[Console]::In.ReadToEnd(); $b=[Convert]::FromBase64String($v); $r=[Security.Cryptography.ProtectedData]::" + method + "($b,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser); [Console]::Out.Write([Convert]::ToBase64String($r))";
  const result = spawnSync("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", script], { input: value, encoding: "utf8", windowsHide: true });
  if (result.status !== 0 || !result.stdout.trim()) throw new Error("No se pudo abrir la protecci\xF3n local de Windows. Conserva la carpeta y usa una exportaci\xF3n con contrase\xF1a para trasladar los datos.");
  return result.stdout.trim();
}
var keyCache = /* @__PURE__ */ new Map();
function localKey(folder2) {
  mkdirSync(folder2, { recursive: true });
  const filename = join(folder2, ".planb-key");
  if (existsSync(filename) && keyCache.has(filename)) return keyCache.get(filename);
  if (existsSync(filename)) {
    const value = JSON.parse(readFileSync(filename, "utf8"));
    if (value.kind === "dpapi" && process.platform === "win32") {
      const key2 = Buffer.from(dpapi(value.data, true), "base64");
      keyCache.set(filename, key2);
      return key2;
    }
    if (value.kind === "test" && process.env.NODE_ENV === "test") {
      const key2 = Buffer.from(value.data, "base64");
      keyCache.set(filename, key2);
      return key2;
    }
    throw new Error("La clave local requiere Windows o el entorno de pruebas original.");
  }
  const key = randomBytes(32);
  if (process.platform !== "win32" && process.env.NODE_ENV !== "test") throw new Error("La protecci\xF3n local comercial requiere Windows.");
  writeFileSync(filename, JSON.stringify(process.platform === "win32" ? { kind: "dpapi", data: dpapi(key.toString("base64"), false) } : { kind: "test", data: key.toString("base64") }), { mode: 384, flag: "wx" });
  keyCache.set(filename, key);
  return key;
}
function seal(text, key) {
  const iv = randomBytes(12), cipher = createCipheriv("aes-256-gcm", key, iv);
  const body = Buffer.concat([cipher.update(text, "utf8"), cipher.final()]);
  return "enc1:" + Buffer.concat([iv, cipher.getAuthTag(), body]).toString("base64");
}
function open(text, key) {
  if (!text.startsWith("enc1:")) return text;
  const data = Buffer.from(text.slice(5), "base64");
  const decipher = createDecipheriv("aes-256-gcm", key, data.subarray(0, 12));
  decipher.setAuthTag(data.subarray(12, 28));
  return Buffer.concat([decipher.update(data.subarray(28)), decipher.final()]).toString("utf8");
}

// shared/model.ts
import { z } from "zod";
var entityNames = ["contacts", "companies", "deals", "tasks"];
var EntityNameSchema = z.enum(entityNames);
var valueSchema = z.union([z.string(), z.number().finite(), z.boolean(), z.null()]);
var FieldSchema = z.object({
  key: z.string().regex(/^[a-zA-Z][a-zA-Z0-9_]{0,99}$/),
  label: z.string().min(1).max(100),
  type: z.enum(["text", "email", "number", "date", "datetime", "multiselect", "enum", "reference", "boolean"]),
  required: z.boolean(),
  readOnly: z.boolean(),
  options: z.array(z.object({ id: z.string(), label: z.string() }).strict()),
  referenceEntity: EntityNameSchema.nullable()
}).strict();
var RuleSchema = z.object({
  id: z.string().min(1).max(100),
  entity: EntityNameSchema,
  kind: z.enum(["required", "email", "min", "conditional_required", "allowed_transition"]),
  field: z.string(),
  value: z.string().nullable(),
  whenField: z.string().nullable(),
  whenValue: z.string().nullable(),
  origin: z.enum(["configuration", "user"]),
  description: z.string().min(1).max(500),
  evidence: z.string().min(1).max(1e3)
}).strict();
var EntitySchema = z.object({
  id: EntityNameSchema,
  label: z.string().min(1),
  singular: z.string().min(1),
  displayField: z.string(),
  columns: z.array(z.string()).min(1),
  fields: z.array(FieldSchema).min(1)
}).strict();
var RecordSchema = z.object({
  id: z.string().min(1),
  entity: EntityNameSchema,
  values: z.record(valueSchema)
}).strict();
var StageSchema = z.object({
  id: z.string(),
  label: z.string(),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/),
  pipelineId: z.string().optional()
}).strict();
var LinkSchema = z.object({
  fromEntity: EntityNameSchema,
  fromId: z.string(),
  toEntity: EntityNameSchema,
  toId: z.string(),
  label: z.string()
}).strict();
var SnapshotSchema = z.object({
  version: z.union([z.literal(1), z.literal(2)]),
  captureStartedAt: z.string().datetime().optional(),
  pipelines: z.array(z.object({ id: z.string(), label: z.string() }).strict()).optional(),
  id: z.string(),
  name: z.string().min(1),
  capturedAt: z.string().datetime(),
  source: z.object({
    kind: z.enum(["fixture", "hubspot", "archive"]),
    accountId: z.string(),
    isTestData: z.literal(true),
    description: z.string()
  }).strict(),
  entities: z.array(EntitySchema).length(4),
  records: z.array(RecordSchema).max(4e4),
  links: z.array(LinkSchema).max(2e5),
  stages: z.array(StageSchema).min(1),
  rules: z.array(RuleSchema),
  unsupported: z.array(z.string()),
  manifest: z.object({
    complete: z.boolean(),
    expectedCounts: z.record(z.number().int().nonnegative()),
    expectedLinks: z.number().int().nonnegative()
  }).strict()
}).strict();
var AppSpecSchema = z.object({
  version: z.union([z.literal(1), z.literal(2)]),
  roles: z.object({ stage: z.string(), amount: z.string(), pipeline: z.string().nullable(), dueDate: z.string(), taskStatus: z.string() }).strict().optional(),
  title: z.string().min(1).max(100),
  description: z.string().max(500),
  entities: z.array(EntitySchema).length(4),
  stages: z.array(StageSchema).min(1),
  rules: z.array(RuleSchema),
  coverage: z.object({
    supported: z.array(z.string()),
    unsupported: z.array(z.string())
  }).strict()
}).strict();
var GenerationSchema = z.object({
  provider: z.enum(["demo", "ai"]),
  model: z.string().nullable(),
  generatedAt: z.string().datetime(),
  prompt: z.string(),
  approved: z.boolean()
}).strict();
var RecoveryPlanSchema = z.object({
  id: z.string(),
  accountId: z.string(),
  createdAt: z.string().datetime(),
  revision: z.string(),
  status: z.enum(["review", "approved", "applying", "complete", "partial"]),
  source: z.enum(["hubspot", "simulation"]),
  warning: z.string(),
  approvedAt: z.string().nullable(),
  operations: z.array(z.object({
    id: z.string(),
    entity: EntityNameSchema,
    localId: z.string(),
    remoteId: z.string().nullable(),
    kind: z.enum(["create", "update"]),
    label: z.string(),
    fields: z.array(z.object({ field: z.string(), label: z.string(), base: valueSchema, local: valueSchema, remote: valueSchema, conflict: z.boolean(), decision: z.enum(["local", "remote"]).nullable() }).strict()),
    references: z.array(z.object({ field: z.string(), entity: EntityNameSchema, id: z.string().nullable() }).strict()),
    remoteVersion: z.string().nullable(),
    status: z.enum(["pending", "sending", "applied", "failed", "uncertain", "skipped"]),
    error: z.string().nullable()
  }).strict())
}).strict();
var BundleSchema = z.object({
  format: z.enum(["planb-continuity-v1", "planb-continuity-v2"]),
  sessionId: z.string().optional(),
  returnState: z.object({ accountId: z.string(), watermark: z.number().int().min(0), mapping: z.record(z.string().min(1)), plan: RecoveryPlanSchema.nullable() }).strict().optional(),
  exportedAt: z.string().datetime(),
  snapshot: SnapshotSchema,
  spec: AppSpecSchema,
  generation: GenerationSchema,
  records: z.array(RecordSchema),
  changes: z.array(z.object({
    id: z.number().int(),
    at: z.string().datetime(),
    entity: EntityNameSchema,
    recordId: z.string(),
    operation: z.enum(["create", "update"]),
    before: RecordSchema.nullable(),
    after: RecordSchema
  }).strict())
}).strict();
function reconcile(snapshot) {
  const errors = [];
  const names = snapshot.entities.map((e) => e.id);
  if (new Set(names).size !== 4 || entityNames.some((e) => !names.includes(e))) {
    errors.push("La captura debe contener las cuatro entidades, sin duplicados.");
  }
  const ids = /* @__PURE__ */ new Set();
  const availableIds = new Set(snapshot.records.map((r) => r.entity + ":" + r.id));
  for (const record of snapshot.records) {
    const id = record.entity + ":" + record.id;
    if (ids.has(id)) errors.push("Registro duplicado: " + id);
    ids.add(id);
    const entity = snapshot.entities.find((e) => e.id === record.entity);
    if (!entity) continue;
    const fields = new Map(entity.fields.map((f) => [f.key, f]));
    for (const [key, value] of Object.entries(record.values)) {
      const field = fields.get(key);
      if (!field) errors.push("Campo sin definici\xF3n: " + record.entity + "." + key);
      if (field?.type === "reference" && value && field.referenceEntity && !availableIds.has(field.referenceEntity + ":" + String(value))) {
        errors.push("Referencia sin destino: " + id + "." + key);
      }
    }
  }
  for (const entity of snapshot.entities) {
    if (new Set(entity.fields.map((f) => f.key)).size !== entity.fields.length) errors.push("Campos duplicados: " + entity.id);
    if (!entity.fields.some((f) => f.key === entity.displayField)) errors.push("Nombre principal no v\xE1lido: " + entity.id);
    if (entity.columns.some((k) => !entity.fields.some((f) => f.key === k))) errors.push("Columna desconocida: " + entity.id);
  }
  const counts = Object.fromEntries(entityNames.map((name) => {
    const actual = snapshot.records.filter((r) => r.entity === name).length;
    const expected = snapshot.manifest.expectedCounts[name];
    if (expected === void 0 || actual !== expected) errors.push("Recuento incompleto: " + name);
    return [name, { expected: expected ?? 0, actual }];
  }));
  for (const link of snapshot.links) {
    if (!ids.has(link.fromEntity + ":" + link.fromId) || !ids.has(link.toEntity + ":" + link.toId)) {
      errors.push("Relaci\xF3n sin registro de origen o destino.");
    }
  }
  if (snapshot.links.length !== snapshot.manifest.expectedLinks) errors.push("Recuento incompleto de relaciones.");
  if (!snapshot.manifest.complete) errors.push("El origen no confirm\xF3 una captura completa.");
  return {
    complete: errors.length === 0,
    counts,
    expectedLinks: snapshot.manifest.expectedLinks,
    actualLinks: snapshot.links.length,
    errors: [...new Set(errors)]
  };
}
function validateSpec(spec, snapshot, userPrompt = "") {
  const errors = [];
  const seen = /* @__PURE__ */ new Set();
  for (const entity of spec.entities) {
    if (seen.has(entity.id)) errors.push("Entidad duplicada: " + entity.id);
    seen.add(entity.id);
    const source = snapshot.entities.find((e) => e.id === entity.id);
    if (!source) {
      errors.push("Entidad ajena al origen.");
      continue;
    }
    const fields = new Map(source.fields.map((f) => [f.key, f]));
    if (entity.fields.length !== source.fields.length) errors.push("Faltan campos importados: " + entity.id);
    if (new Set(entity.fields.map((f) => f.key)).size !== entity.fields.length) errors.push("Campos duplicados.");
    for (const field of entity.fields) {
      const original = fields.get(field.key);
      if (!original || field.type !== original.type || field.readOnly !== original.readOnly || field.required !== original.required || field.referenceEntity !== original.referenceEntity || JSON.stringify(field.options) !== JSON.stringify(original.options)) {
        errors.push("Se alter\xF3 la definici\xF3n del campo: " + entity.id + "." + field.key);
      }
    }
    if (!fields.has(entity.displayField) || entity.columns.some((k) => !fields.has(k))) errors.push("Vista con campos desconocidos.");
  }
  if (seen.size !== 4) errors.push("Faltan entidades.");
  if (JSON.stringify(spec.stages) !== JSON.stringify(snapshot.stages)) errors.push("Se alteraron las etapas del origen.");
  const ruleIds = /* @__PURE__ */ new Set();
  for (const rule of spec.rules) {
    if (ruleIds.has(rule.id)) errors.push("Regla duplicada.");
    ruleIds.add(rule.id);
    const entity = snapshot.entities.find((e) => e.id === rule.entity);
    const field = entity?.fields.find((f) => f.key === rule.field);
    if (!field || field.readOnly) errors.push("Regla sobre un campo no editable.");
    if (rule.whenField && !entity?.fields.some((f) => f.key === rule.whenField)) errors.push("Condici\xF3n sobre un campo desconocido.");
    if (rule.kind === "conditional_required" && (!rule.whenField || rule.whenValue === null)) errors.push("Regla condicional incompleta.");
    if (rule.kind === "conditional_required") {
      const condition = entity?.fields.find((f) => f.key === rule.whenField);
      if (condition?.type === "enum" && !condition.options.some((o) => o.id === rule.whenValue)) errors.push("La condici\xF3n usa una opci\xF3n desconocida.");
    }
    if (rule.kind === "min" && (field?.type !== "number" || rule.value === null || !Number.isFinite(Number(rule.value)))) errors.push("L\xEDmite num\xE9rico no v\xE1lido.");
    if (rule.kind === "email" && field?.type !== "email" && field?.type !== "text") errors.push("Validaci\xF3n de correo no compatible.");
    if (rule.kind === "allowed_transition") {
      const valid = new Set(snapshot.stages.map((s) => s.id));
      if (rule.entity !== "deals" || rule.field !== "dealstage") errors.push("Las transiciones solo se aplican a la etapa de una oportunidad.");
      if (!rule.whenValue || !rule.value || !valid.has(rule.whenValue) || rule.value.split(",").some((v) => !valid.has(v))) errors.push("Transici\xF3n comercial desconocida.");
    }
    if (rule.origin === "configuration" && !snapshot.rules.some((r) => JSON.stringify(r) === JSON.stringify(rule))) {
      errors.push("Regla importada sin evidencia en la captura.");
    }
    if (rule.origin === "user" && (!userPrompt.trim() || !userPrompt.includes(rule.evidence))) {
      errors.push("Regla de usuario sin una cita exacta de su instrucci\xF3n.");
    }
  }
  for (const rule of snapshot.rules) {
    if (!spec.rules.some((r) => JSON.stringify(r) === JSON.stringify(rule))) errors.push("Falta una regla del origen: " + rule.id);
  }
  if (spec.coverage.supported.length === 0) errors.push("La aplicaci\xF3n debe declarar procesos cubiertos.");
  for (const limitation of snapshot.unsupported) {
    if (!spec.coverage.unsupported.includes(limitation)) errors.push("Falta declarar una limitaci\xF3n del origen.");
  }
  return [...new Set(errors)];
}
function validateRecord(spec, record, previous) {
  const errors = {};
  const entity = spec.entities.find((e) => e.id === record.entity);
  if (!entity) return { _form: "Entidad desconocida." };
  for (const key of Object.keys(record.values)) if (!entity.fields.some((f) => f.key === key)) errors[key] = "Campo desconocido.";
  for (const field of entity.fields) {
    const value = record.values[field.key];
    const empty = value === null || value === void 0 || value === "";
    if (field.readOnly && previous && value !== previous.values[field.key]) errors[field.key] = "Este campo es de solo lectura.";
    if (field.required && empty) errors[field.key] = "Completa este campo.";
    if (empty) continue;
    if (field.type === "number" && (typeof value !== "number" || !Number.isFinite(value))) errors[field.key] = "Introduce un n\xFAmero v\xE1lido.";
    if (field.type === "boolean" && typeof value !== "boolean") errors[field.key] = "Introduce un valor verdadero o falso.";
    if (["text", "email", "date", "datetime", "multiselect", "enum", "reference"].includes(field.type) && typeof value !== "string") errors[field.key] = "Introduce un texto v\xE1lido.";
    if (field.type === "datetime" && (!/^\d{4}-\d{2}-\d{2}T/.test(String(value)) || Number.isNaN(Date.parse(String(value))))) errors[field.key] = "Introduce fecha y hora v\xE1lidas.";
    if (field.type === "multiselect" && String(value).split(";").some((v) => !field.options.some((o) => o.id === v))) errors[field.key] = "Hay opciones desconocidas.";
    if (field.type === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value))) errors[field.key] = "Introduce un correo v\xE1lido.";
    if (field.type === "date") {
      const text = String(value), parsed = Date.parse(text);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(text) || Number.isNaN(parsed) || new Date(parsed).toISOString().slice(0, 10) !== text) errors[field.key] = "Introduce una fecha v\xE1lida.";
    }
    if (field.type === "enum" && !field.options.some((o) => o.id === value)) errors[field.key] = "Selecciona una opci\xF3n v\xE1lida.";
    if (typeof value === "string" && value.length > 1e4) errors[field.key] = "El texto es demasiado largo.";
  }
  for (const rule of spec.rules.filter((r) => r.entity === record.entity)) {
    const value = record.values[rule.field];
    const empty = value === null || value === void 0 || value === "";
    if (rule.kind === "required" && empty) errors[rule.field] = rule.description;
    if (rule.kind === "email" && !empty && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value))) errors[rule.field] = rule.description;
    if (rule.kind === "min" && !empty && Number(value) < Number(rule.value)) errors[rule.field] = rule.description;
    if (rule.kind === "conditional_required" && String(record.values[rule.whenField]) === rule.whenValue && empty) errors[rule.field] = rule.description;
    if (rule.kind === "allowed_transition" && previous && previous.values[rule.field] !== value && String(previous.values[rule.field]) === rule.whenValue && !rule.value.split(",").includes(String(value))) errors[rule.field] = rule.description;
  }
  const pipeline = record.values.pipeline;
  if (record.entity === "deals" && pipeline) {
    const stage = spec.stages.find((s) => s.id === record.values.dealstage);
    if (stage?.pipelineId && stage.pipelineId !== pipeline) errors.dealstage = "La etapa no pertenece a este proceso comercial.";
  }
  return errors;
}

// server/store.ts
var AppError = class extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
};
var Store = class {
  constructor(filename) {
    this.filename = filename;
    if (filename !== ":memory:") mkdirSync2(dirname2(filename), { recursive: true });
    this.key = filename === ":memory:" ? null : localKey(dirname2(filename));
    this.db = new DatabaseSync(filename);
    this.db.exec(
      "PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000; PRAGMA secure_delete=ON;CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);CREATE TABLE IF NOT EXISTS records(entity TEXT NOT NULL,id TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY(entity,id));CREATE TABLE IF NOT EXISTS changes(id INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT NOT NULL,entity TEXT NOT NULL,record_id TEXT NOT NULL,operation TEXT NOT NULL,before_json TEXT,after_json TEXT NOT NULL);CREATE TABLE IF NOT EXISTS archives(id TEXT PRIMARY KEY,at TEXT NOT NULL,bundle TEXT NOT NULL);CREATE TABLE IF NOT EXISTS usage(id TEXT PRIMARY KEY,month TEXT NOT NULL,reserved_usd REAL NOT NULL,used_usd REAL NOT NULL DEFAULT 0,status TEXT NOT NULL);CREATE TABLE IF NOT EXISTS captures(id TEXT PRIMARY KEY,at TEXT NOT NULL,bytes INTEGER NOT NULL,payload TEXT NOT NULL);"
    );
    this.migrateEncryption();
    this.db.prepare("UPDATE usage SET status='interrupted' WHERE status='pending'").run();
  }
  db;
  key;
  close() {
    this.db.close();
  }
  encode(value) {
    const text = JSON.stringify(value);
    return this.key ? seal(text, this.key) : text;
  }
  decode(value) {
    return JSON.parse(this.key ? open(value, this.key) : value);
  }
  migrateEncryption() {
    if (!this.key) return;
    let changed = false;
    this.transaction(() => {
      for (const [table, columns] of Object.entries({ meta: ["value"], records: ["value"], changes: ["before_json", "after_json"], archives: ["bundle"], captures: ["payload"] })) {
        const rows = this.db.prepare("SELECT rowid AS rid," + columns.join(",") + " FROM " + table).all();
        for (const row of rows) for (const column of columns) {
          const value = row[column];
          if (typeof value === "string" && !value.startsWith("enc1:")) {
            JSON.parse(value);
            this.db.prepare("UPDATE " + table + " SET " + column + "=? WHERE rowid=?").run(seal(value, this.key), row.rid);
            changed = true;
          }
        }
      }
    });
    if (changed) this.db.exec("VACUUM");
  }
  get(key, fallback) {
    const row = this.db.prepare("SELECT value FROM meta WHERE key=?").get(key);
    return row ? this.decode(row.value) : fallback;
  }
  set(key, value) {
    this.db.prepare("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(key, this.encode(value));
  }
  get snapshot() {
    return this.get("snapshot", null);
  }
  get spec() {
    return this.get("spec", null);
  }
  get generation() {
    return this.get("generation", null);
  }
  get reconciliation() {
    return this.get("reconciliation", null);
  }
  get disconnected() {
    return this.get("disconnected", false);
  }
  get ready() {
    return !!(this.snapshot && this.spec && this.generation?.approved && this.reconciliation?.complete);
  }
  get changesCount() {
    return Number(this.db.prepare("SELECT COUNT(*) AS n FROM changes").get().n);
  }
  get pendingChangesCount() {
    const watermark = this.get("returnWatermark:hubspot", 0);
    return Number(this.db.prepare("SELECT COUNT(*) AS n FROM changes WHERE id>?").get(watermark).n);
  }
  transaction(fn) {
    this.db.exec("BEGIN IMMEDIATE");
    try {
      const result = fn();
      this.db.exec("COMMIT");
      return result;
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
  }
  importSnapshot(raw, replace = false) {
    if (this.get("returnBusy", false)) throw new AppError(409, "Hay una devoluci\xF3n en curso.");
    if (this.get("continuitySession", null)) throw new AppError(409, "Cierra la sesi\xF3n de continuidad antes de importar otra captura.");
    const parsed = SnapshotSchema.safeParse(raw);
    if (!parsed.success) throw new AppError(422, "La captura tiene un formato no v\xE1lido.", parsed.error.flatten());
    const snapshot = parsed.data;
    const report2 = reconcile(snapshot);
    const ruleErrors = validateSpec({
      version: 1,
      title: snapshot.name,
      description: "",
      entities: snapshot.entities,
      stages: snapshot.stages,
      rules: snapshot.rules,
      coverage: { supported: ["Datos del origen"], unsupported: snapshot.unsupported }
    }, snapshot);
    report2.errors.push(...ruleErrors);
    report2.complete = report2.errors.length === 0;
    if (!report2.complete) {
      this.set("lastImportError", report2);
      throw new AppError(422, "Importaci\xF3n incompleta. Se conserva la \xFAltima captura v\xE1lida.", report2);
    }
    if (this.changesCount && !replace) throw new AppError(409, "Hay cambios locales. Exporta una copia antes de cambiar el origen.");
    this.addCapture(snapshot);
    if (this.ready) {
      this.set("candidate", { snapshot, reconciliation: report2, spec: null, generation: null, error: null, replaceRecords: true, replaceApproved: replace, baselineChanges: this.changesCount });
      return report2;
    }
    this.transaction(() => {
      const existing = this.bundleOrNull();
      if (existing) this.db.prepare("INSERT INTO archives(id,at,bundle) VALUES(?,?,?)").run(randomUUID(), (/* @__PURE__ */ new Date()).toISOString(), this.encode(existing));
      this.db.exec("DELETE FROM records; DELETE FROM changes;");
      for (const record of snapshot.records) this.insertRecord(record);
      this.set("snapshot", snapshot);
      this.set("reconciliation", report2);
      this.set("spec", null);
      this.set("generation", null);
      this.set("lastError", null);
      this.set("lastImportError", null);
      this.set("disconnected", false);
      this.set("candidate", null);
      this.resetReturnState();
    });
    return report2;
  }
  saveGeneration(raw, generation) {
    if (this.get("returnBusy", false)) throw new AppError(409, "Hay una devoluci\xF3n en curso.");
    if (this.get("continuitySession", null)) throw new AppError(409, "La generaci\xF3n queda pausada durante una sesi\xF3n de continuidad.");
    const candidate = this.candidate;
    const snapshot = candidate?.snapshot ?? this.snapshot;
    if (!snapshot) throw new AppError(409, "Importa primero una captura.");
    const parsed = AppSpecSchema.safeParse(raw);
    const errors = parsed.success ? validateSpec(parsed.data, snapshot, generation.prompt) : ["La especificaci\xF3n no cumple el contrato de la aplicaci\xF3n."];
    if (errors.length || !parsed.success) {
      this.failGeneration("La generaci\xF3n no super\xF3 la validaci\xF3n.");
      throw new AppError(422, "La aplicaci\xF3n no est\xE1 preparada. Revisa la generaci\xF3n.", errors);
    }
    if (this.ready) this.set("candidate", { ...candidate ?? { snapshot, reconciliation: this.reconciliation, replaceRecords: false, replaceApproved: false, baselineChanges: this.changesCount }, spec: parsed.data, generation: { ...generation, approved: false }, error: null });
    else this.transaction(() => {
      this.set("spec", parsed.data);
      this.set("generation", { ...generation, approved: false });
      this.set("lastError", null);
    });
  }
  get candidate() {
    return this.get("candidate", null);
  }
  failGeneration(message) {
    if (this.get("continuitySession", null)) return;
    if (this.ready) {
      const candidate = this.candidate ?? { snapshot: this.snapshot, reconciliation: this.reconciliation, spec: null, generation: null, replaceRecords: false, replaceApproved: false, baselineChanges: this.changesCount };
      this.set("candidate", { ...candidate, error: message });
    } else this.set("lastError", message);
  }
  activate() {
    if (this.get("continuitySession", null)) throw new AppError(409, "Cierra la sesi\xF3n de continuidad antes de activar otra versi\xF3n.");
    const candidate = this.candidate;
    const spec = candidate?.spec ?? (!candidate ? this.spec : null), snapshot = candidate?.snapshot ?? this.snapshot, generation = candidate?.generation ?? (!candidate ? this.generation : null);
    if (!spec || !snapshot || !generation) throw new AppError(409, "Genera primero una especificaci\xF3n.");
    if (candidate?.error || !this.ready && this.get("lastError", null)) throw new AppError(409, "La \xFAltima generaci\xF3n fall\xF3. Vuelve a generarla.");
    if (candidate?.replaceRecords && this.changesCount && (!candidate.replaceApproved || candidate.baselineChanges !== this.changesCount)) throw new AppError(409, "Hay cambios locales nuevos. Exporta y revisa otra vez la sustituci\xF3n.");
    const errors = validateSpec(spec, snapshot, generation.prompt);
    for (const record of candidate?.replaceRecords ? snapshot.records : this.records()) {
      const issues = validateRecord(spec, record);
      for (const [key, message] of Object.entries(issues)) errors.push(record.entity + "/" + record.id + "/" + key + ": " + message);
    }
    if (!this.reconciliation?.complete || errors.length) {
      this.failGeneration("Hay datos o reglas que necesitan revisi\xF3n.");
      throw new AppError(422, "No se puede activar todav\xEDa.", errors.slice(0, 50));
    }
    this.transaction(() => {
      if (candidate) {
        const old = this.bundleOrNull();
        if (old) this.db.prepare("INSERT INTO archives(id,at,bundle) VALUES(?,?,?)").run(randomUUID(), (/* @__PURE__ */ new Date()).toISOString(), this.encode(old));
        if (candidate.replaceRecords) {
          this.db.exec("DELETE FROM records; DELETE FROM changes;");
          for (const record of snapshot.records) this.insertRecord(record);
          this.resetReturnState();
        }
        this.set("snapshot", snapshot);
        this.set("spec", spec);
        this.set("reconciliation", candidate.reconciliation);
      }
      this.set("generation", { ...generation, approved: true });
      this.set("candidate", null);
      this.set("lastError", null);
    });
  }
  insertRecord(record) {
    this.db.prepare("INSERT INTO records(entity,id,value) VALUES(?,?,?) ON CONFLICT(entity,id) DO UPDATE SET value=excluded.value").run(record.entity, record.id, this.encode(record));
  }
  records(entity) {
    const rows = entity ? this.db.prepare("SELECT value FROM records WHERE entity=? ORDER BY rowid").all(entity) : this.db.prepare("SELECT value FROM records ORDER BY rowid").all();
    return rows.map((r) => this.decode(r.value));
  }
  record(entity, id) {
    const row = this.db.prepare("SELECT value FROM records WHERE entity=? AND id=?").get(entity, id);
    return row ? this.decode(row.value) : null;
  }
  saveRecord(entity, values, id) {
    if (this.get("returnBusy", false)) throw new AppError(409, "Espera a que termine la devoluci\xF3n revisada.");
    const plan = this.get("recoveryPlan", null);
    if (plan && plan.status !== "complete" && plan.operations.some((o) => ["applied", "sending", "uncertain"].includes(o.status))) throw new AppError(409, "Resuelve la devoluci\xF3n parcial antes de seguir editando. Tus cambios actuales se conservan.");
    if (!this.ready || !this.spec) throw new AppError(409, "Revisa y activa primero la aplicaci\xF3n.");
    const previous = id ? this.record(entity, id) : null;
    if (id && !previous) throw new AppError(404, "No se encontr\xF3 el registro.");
    const record = RecordSchema.parse({ entity, id: id ?? "local-" + randomUUID(), values: previous ? { ...previous.values, ...values } : values });
    const errors = validateRecord(this.spec, record, previous);
    const definition = this.spec.entities.find((e) => e.id === entity);
    for (const field of definition.fields) {
      const value = record.values[field.key];
      if (field.type === "reference" && value && field.referenceEntity && !this.record(field.referenceEntity, String(value))) {
        errors[field.key] = "El registro relacionado no existe.";
      }
      if (!previous && field.readOnly && value !== void 0 && value !== null && value !== "") errors[field.key] = "Este campo no se puede crear manualmente.";
    }
    if (Object.keys(errors).length) throw new AppError(422, "Revisa los campos se\xF1alados.", errors);
    this.transaction(() => {
      this.insertRecord(record);
      this.db.prepare("INSERT INTO changes(at,entity,record_id,operation,before_json,after_json) VALUES(?,?,?,?,?,?)").run((/* @__PURE__ */ new Date()).toISOString(), entity, record.id, previous ? "update" : "create", previous ? this.encode(previous) : null, this.encode(record));
      this.set("returnComplete", false);
    });
    return record;
  }
  changes() {
    return this.db.prepare("SELECT * FROM changes ORDER BY id").all().map((r) => ({
      id: r.id,
      at: r.at,
      entity: r.entity,
      recordId: r.record_id,
      operation: r.operation,
      before: r.before_json ? this.decode(r.before_json) : null,
      after: this.decode(r.after_json)
    }));
  }
  bundleOrNull() {
    const snapshot = this.snapshot, spec = this.spec, generation = this.generation;
    if (!snapshot || !spec || !generation) return null;
    const plan = this.get("recoveryPlan", null);
    return {
      format: "planb-continuity-v2",
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      sessionId: this.get("sessionId", ""),
      returnState: { accountId: snapshot.source.accountId, watermark: this.get("returnWatermark:hubspot", 0), mapping: this.get("remoteMapping:hubspot", {}), plan: plan?.source === "hubspot" ? plan : null },
      snapshot,
      spec,
      generation,
      records: this.records(),
      changes: this.changes()
    };
  }
  bundle() {
    if (!this.ready) throw new AppError(409, "Activa una aplicaci\xF3n verificada antes de exportar.");
    return this.bundleOrNull();
  }
  restoreBundle(raw) {
    const parsed = BundleSchema.safeParse(raw);
    if (!parsed.success) throw new AppError(422, "El paquete de continuidad no es v\xE1lido.");
    const bundle = parsed.data;
    const report2 = reconcile(bundle.snapshot);
    const errors = validateSpec(bundle.spec, bundle.snapshot, bundle.generation.prompt);
    const ids = new Set(bundle.records.map((r) => r.entity + ":" + r.id));
    const replay = new Map(bundle.snapshot.records.map((r) => [r.entity + ":" + r.id, r]));
    let previousChangeId = 0;
    for (const change of bundle.changes) {
      const key = change.entity + ":" + change.recordId, prior = replay.get(key) ?? null;
      if (change.id <= previousChangeId || change.after.entity !== change.entity || change.after.id !== change.recordId || JSON.stringify(prior) !== JSON.stringify(change.before) || change.operation !== (prior ? "update" : "create")) errors.push("El historial no corresponde a la captura original.");
      previousChangeId = change.id;
      replay.set(key, change.after);
    }
    for (const record of bundle.records) if (JSON.stringify(replay.get(record.entity + ":" + record.id)) !== JSON.stringify(record)) errors.push("Hay registros activos sin una operaci\xF3n coherente.");
    if (replay.size !== bundle.records.length) errors.push("El paquete perdi\xF3 registros del historial.");
    const returned = bundle.returnState;
    if (returned) {
      if (returned.accountId !== bundle.snapshot.source.accountId || returned.watermark > previousChangeId) errors.push("Estado de devoluci\xF3n incompatible con el historial.");
      const created = new Set(bundle.changes.filter((c) => c.operation === "create").map((c) => c.entity + ":" + c.recordId));
      if (Object.keys(returned.mapping).some((key) => !created.has(key))) errors.push("Correspondencia de IDs sin alta local.");
      if (returned.plan) {
        if (returned.plan.source !== "hubspot" || returned.plan.accountId !== returned.accountId) errors.push("Plan de devoluci\xF3n de otro destino.");
        for (const op of returned.plan.operations) {
          const definition = bundle.spec.entities.find((e) => e.id === op.entity);
          if (!ids.has(op.entity + ":" + op.localId) || op.fields.some((f) => !definition?.fields.some((d) => d.key === f.field && !d.readOnly && d.type !== "reference")) || op.references.some((r) => !ids.has(r.entity + ":" + r.id) || !definition?.fields.some((f) => f.key === r.field && f.referenceEntity === r.entity))) errors.push("Operaci\xF3n de devoluci\xF3n incompatible con la copia.");
        }
      }
    }
    if (ids.size !== bundle.records.length) errors.push("Registros activos duplicados.");
    for (const baseline of bundle.snapshot.records) {
      if (!ids.has(baseline.entity + ":" + baseline.id)) errors.push("El paquete perdi\xF3 un registro de la captura.");
    }
    for (const record of bundle.records) {
      for (const [field, message] of Object.entries(validateRecord(bundle.spec, record))) errors.push(record.id + "/" + field + ": " + message);
      const entity = bundle.spec.entities.find((e) => e.id === record.entity);
      for (const field of entity?.fields ?? []) if (field.type === "reference" && record.values[field.key] && !ids.has(field.referenceEntity + ":" + String(record.values[field.key]))) errors.push("Referencia inv\xE1lida en el paquete.");
    }
    if (!report2.complete || errors.length || !bundle.generation.approved) throw new AppError(422, "El paquete no super\xF3 la comprobaci\xF3n de integridad.", [...report2.errors, ...errors]);
    this.transaction(() => {
      this.db.exec("DELETE FROM records; DELETE FROM changes;");
      for (const record of bundle.records) this.insertRecord(record);
      for (const change of bundle.changes) this.db.prepare("INSERT INTO changes(id,at,entity,record_id,operation,before_json,after_json) VALUES(?,?,?,?,?,?,?)").run(change.id, change.at, change.entity, change.recordId, change.operation, change.before ? this.encode(change.before) : null, this.encode(change.after));
      this.set("snapshot", bundle.snapshot);
      this.set("spec", bundle.spec);
      this.set("generation", bundle.generation);
      this.set("reconciliation", report2);
      this.set("lastError", null);
      this.set("disconnected", true);
      this.set("candidate", null);
      this.set("sessionId", bundle.sessionId ?? randomUUID());
      this.resetReturnState();
      if (returned) {
        this.set("returnWatermark:hubspot", returned.watermark);
        this.set("remoteMapping:hubspot", returned.mapping);
        const plan = returned.plan;
        if (plan) {
          if (plan.status === "applying") {
            for (const op of plan.operations) if (op.status === "sending") {
              op.status = "uncertain";
              op.error = "La copia se export\xF3 durante un env\xEDo. Verifica el resultado remoto antes de repetir.";
            }
            plan.status = "partial";
          }
          if (plan.status === "approved") {
            plan.status = "review";
            plan.approvedAt = null;
          }
          this.set("recoveryPlan", plan);
        }
      }
    });
    this.addCapture(bundle.snapshot);
  }
  addCapture(snapshot) {
    const report2 = reconcile(snapshot);
    if (!report2.complete) throw new AppError(422, "La captura no est\xE1 conciliada.", report2.errors);
    const id = snapshot.id + ":" + snapshot.capturedAt, payload = this.encode(snapshot);
    if (this.db.prepare("SELECT id FROM captures WHERE id=?").get(id)) return id;
    this.pruneCaptures();
    const used = this.storageBytes();
    if (used + Buffer.byteLength(payload) > 2 * 1024 ** 3) throw new AppError(507, "Se alcanz\xF3 el l\xEDmite local de 2 GB. Conserva los cambios pendientes y revisa el historial.");
    this.db.prepare("INSERT OR IGNORE INTO captures(id,at,bytes,payload) VALUES(?,?,?,?)").run(id, snapshot.capturedAt, Buffer.byteLength(payload), payload);
    this.pruneCaptures();
    return id;
  }
  storageBytes() {
    let total = 0;
    for (const [table, columns] of Object.entries({ meta: ["value"], records: ["value"], changes: ["before_json", "after_json"], archives: ["bundle"], captures: ["payload"] })) {
      const expression = columns.map((c) => "COALESCE(length(CAST(" + c + " AS BLOB)),0)").join("+");
      total += Number(this.db.prepare("SELECT COALESCE(SUM(" + expression + "),0) AS n FROM " + table).get().n);
    }
    return total;
  }
  resetReturnState() {
    for (const key of ["recoveryPlan", "continuitySession", "simulatedRemote"]) this.set(key, null);
    for (const kind of ["simulation", "hubspot"]) {
      this.set("returnWatermark:" + kind, 0);
      this.set("remoteMapping:" + kind, {});
    }
    this.set("returnComplete", false);
    this.set("sessionCapture", "");
  }
  captures() {
    return this.db.prepare("SELECT id,at,bytes FROM captures ORDER BY at DESC,rowid DESC").all();
  }
  capture(id) {
    const row = this.db.prepare("SELECT payload FROM captures WHERE id=?").get(id);
    if (!row) throw new AppError(404, "No se encontr\xF3 la captura.");
    return this.decode(row.payload);
  }
  pruneCaptures(now = Date.now()) {
    const all = this.captures(), protectedId = this.snapshot ? this.snapshot.id + ":" + this.snapshot.capturedAt : "";
    const days = /* @__PURE__ */ new Set();
    let hours = 0;
    for (const item of all) {
      const recent = now - Date.parse(item.at) < 24 * 36e5 && hours++ < 24;
      const day = item.at.slice(0, 10);
      const daily = !days.has(day) && days.size < 30;
      if (daily) days.add(day);
      if (!recent && !daily && item.id !== protectedId && item.id !== this.get("sessionCapture", "")) this.db.prepare("DELETE FROM captures WHERE id=?").run(item.id);
    }
  }
  page(entity, query = "", offset = 0, limit = 50, pipeline = "") {
    const normalize = (v) => v.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
    const all = this.records(), names = new Map(all.map((r) => [r.entity + ":" + r.id, Object.values(r.values).join(" ")]));
    const fields = this.spec?.entities.find((e) => e.id === entity)?.fields ?? [];
    const needle = normalize(query);
    const matching = all.filter((r) => r.entity === entity && (!pipeline || r.values.pipeline === pipeline) && (!needle || normalize(Object.values(r.values).join(" ") + " " + fields.filter((f) => f.type === "reference").map((f) => names.get(f.referenceEntity + ":" + r.values[f.key]) ?? "").join(" ")).includes(needle)));
    const records = matching.slice(offset, offset + limit), related = /* @__PURE__ */ new Map();
    for (const record of records) for (const field of fields) if (field.type === "reference" && record.values[field.key]) {
      const item = all.find((r) => r.entity === field.referenceEntity && r.id === record.values[field.key]);
      if (item) related.set(item.entity + ":" + item.id, item);
    }
    return { records, related: [...related.values()], total: matching.length, offset, limit };
  }
  usage() {
    const month = (/* @__PURE__ */ new Date()).toISOString().slice(0, 7);
    const row = this.db.prepare("SELECT COALESCE(SUM(used_usd),0) AS used,COALESCE(SUM(CASE WHEN status IN ('pending','interrupted') THEN reserved_usd ELSE 0 END),0) AS reserved,COUNT(*) AS requests FROM usage WHERE month=?").get(month);
    return { usedUsd: row.used, reservedUsd: row.reserved, limitUsd: 25, requests: row.requests };
  }
  reserveUsage(worstCaseUsd) {
    if (!Number.isFinite(worstCaseUsd) || worstCaseUsd < 0) throw new AppError(422, "La reserva de presupuesto no es v\xE1lida.");
    const id = randomUUID(), month = (/* @__PURE__ */ new Date()).toISOString().slice(0, 7);
    this.transaction(() => {
      const used = this.usage();
      if (used.usedUsd + used.reservedUsd + worstCaseUsd > used.limitUsd) throw new AppError(429, "Se alcanz\xF3 el l\xEDmite local de 25 USD para pruebas de IA.");
      this.db.prepare("INSERT INTO usage(id,month,reserved_usd,used_usd,status) VALUES(?,?,?,0,'pending')").run(id, month, worstCaseUsd);
    });
    return id;
  }
  settleUsage(id, usd) {
    if (!Number.isFinite(usd) || usd < 0) throw new AppError(422, "El coste comunicado por el proveedor no es v\xE1lido.");
    this.db.prepare("UPDATE usage SET used_usd=?,reserved_usd=0,status='complete' WHERE id=?").run(usd, id);
  }
};

// server/drill-worker.ts
var chunks = [];
for await (const chunk of process.stdin) chunks.push(Buffer.from(chunk));
var input = JSON.parse(Buffer.concat(chunks).toString("utf8"));
var started = Date.now();
var checks = [];
var scratch = resolve(input.scratch);
mkdirSync3(scratch, { recursive: true });
var folder = mkdtempSync(join2(scratch, "drill-"));
var store = null;
function check(label, fn) {
  try {
    fn();
    checks.push({ label, passed: true, detail: "Comprobado en una copia aislada." });
  } catch (error) {
    checks.push({ label, passed: false, detail: error instanceof Error ? error.message : "No superado." });
  }
}
try {
  let blocked = false;
  try {
    await fetch("https://example.com");
  } catch (error) {
    blocked = String(error).includes("EXTERNAL_");
  }
  check("Red externa bloqueada", () => {
    if (!blocked) throw new Error("El arn\xE9s no confirm\xF3 el bloqueo de red.");
  });
  if (!blocked) throw new Error("No se ejecutar\xE1 un simulacro sin aislamiento.");
  store = new Store(join2(folder, "drill.sqlite"));
  store.restoreBundle(input.bundle);
  let contactId = "", taskId = "", phoneKey = "", newPhone = "Prueba de continuidad";
  check("Buscar y editar un cliente", () => {
    const found = store.page("contacts", "", 0, 1).records[0];
    if (!found) throw new Error("No hay clientes para probar.");
    contactId = found.id;
    const field = store.spec.entities.find((e) => e.id === "contacts").fields.find((f) => !f.readOnly && f.type === "text" && /phone|tel/i.test(f.key + f.label));
    if (!field) throw new Error("No hay un tel\xE9fono editable cubierto.");
    phoneKey = field.key;
    newPhone = "600 123 456";
    store.saveRecord("contacts", { [phoneKey]: newPhone }, found.id);
  });
  check("Avanzar una oportunidad", () => {
    const found = store.records("deals")[0];
    if (!found) throw new Error("No hay oportunidades para probar.");
    const stages = store.spec.stages.filter((s) => !s.pipelineId || s.pipelineId === found.values.pipeline);
    const stage = stages.find((s) => s.id !== found.values.dealstage);
    if (!stage) throw new Error("No hay una segunda etapa.");
    store.saveRecord("deals", { dealstage: stage.id }, found.id);
  });
  check("Crear y completar una tarea", () => {
    const entity = store.spec.entities.find((e) => e.id === "tasks"), template = store.records("tasks")[0];
    const values = Object.fromEntries(entity.fields.filter((f) => !f.readOnly).map((f) => [f.key, template?.values[f.key] ?? null]));
    const title = entity.displayField, due = store.spec.roles?.dueDate ?? "due_date", status = store.spec.roles?.taskStatus ?? "status";
    values[title] = "Simulacro \xB7 tarea temporal";
    values[due] = entity.fields.find((f) => f.key === due)?.type === "datetime" ? "2026-11-12T10:00:00.000Z" : "2026-11-12";
    const statusField = entity.fields.find((f) => f.key === status);
    const done = statusField?.options.find((o) => /complet|termin|done/i.test(o.id + " " + o.label));
    if (!done) throw new Error("No hay un estado de tarea completada compatible.");
    const task = store.saveRecord("tasks", values);
    taskId = task.id;
    store.saveRecord("tasks", { [status]: done.id }, task.id);
  });
  store.close();
  store = new Store(join2(folder, "drill.sqlite"));
  check("Persistencia despu\xE9s de reiniciar", () => {
    if (!contactId || !taskId || store.record("contacts", contactId)?.values[phoneKey] !== newPhone || !store.record("tasks", taskId)) throw new Error("No se conservaron todas las operaciones.");
  });
} catch (error) {
  checks.push({ label: "Preparaci\xF3n del simulacro", passed: false, detail: error instanceof Error ? error.message : "Error del entorno." });
} finally {
  store?.close();
  const absolute = resolve(folder);
  if (!absolute.startsWith(scratch + requireSeparator())) throw new Error("Ruta de limpieza no v\xE1lida.");
  rmSync(absolute, { recursive: true, force: true, maxRetries: 3, retryDelay: 100 });
}
function requireSeparator() {
  return process.platform === "win32" ? "\\" : "/";
}
var report = {
  id: randomUUID2(),
  captureId: input.captureId,
  startedAt: new Date(started).toISOString(),
  completedAt: (/* @__PURE__ */ new Date()).toISOString(),
  passed: checks.length === 5 && checks.every((c) => c.passed),
  isolated: true,
  checks,
  durationMs: Date.now() - started,
  dataSource: input.bundle.snapshot.source.kind === "fixture" ? "Conjunto ficticio incluido" : "Cuenta HubSpot de prueba",
  limitations: ["Simulacro t\xE9cnico, no certificaci\xF3n ni SLA.", "No acredita devoluci\xF3n real a HubSpot.", "No modifica los datos operativos."]
};
process.stdout.write(JSON.stringify(report));
