// server/runtime.ts
import { existsSync as existsSync6, readFileSync as readFileSync4 } from "node:fs";
import { resolve, join as join5 } from "node:path";

// server/app.ts
import Fastify from "fastify";
import staticPlugin from "@fastify/static";
import { existsSync as existsSync4 } from "node:fs";
import { z as z4 } from "zod";

// shared/model.ts
import { z } from "zod";
var entityNames = ["contacts", "companies", "deals", "tasks"];
var EntityNameSchema = z.enum(entityNames);
var valueSchema = z.union([z.string(), z.number().finite(), z.boolean(), z.null()]);
var FieldSchema = z.object({
  key: z.string().regex(/^[a-zA-Z][a-zA-Z0-9_]{0,99}$/),
  label: z.string().min(1).max(100),
  type: z.enum(["text", "email", "number", "date", "datetime", "multiselect", "enum", "reference", "boolean"]),
  required: z.boolean(),
  readOnly: z.boolean(),
  options: z.array(z.object({ id: z.string(), label: z.string() }).strict()),
  referenceEntity: EntityNameSchema.nullable()
}).strict();
var RuleSchema = z.object({
  id: z.string().min(1).max(100),
  entity: EntityNameSchema,
  kind: z.enum(["required", "email", "min", "conditional_required", "allowed_transition"]),
  field: z.string(),
  value: z.string().nullable(),
  whenField: z.string().nullable(),
  whenValue: z.string().nullable(),
  origin: z.enum(["configuration", "user"]),
  description: z.string().min(1).max(500),
  evidence: z.string().min(1).max(1e3)
}).strict();
var EntitySchema = z.object({
  id: EntityNameSchema,
  label: z.string().min(1),
  singular: z.string().min(1),
  displayField: z.string(),
  columns: z.array(z.string()).min(1),
  fields: z.array(FieldSchema).min(1)
}).strict();
var RecordSchema = z.object({
  id: z.string().min(1),
  entity: EntityNameSchema,
  values: z.record(valueSchema)
}).strict();
var StageSchema = z.object({
  id: z.string(),
  label: z.string(),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/),
  pipelineId: z.string().optional()
}).strict();
var LinkSchema = z.object({
  fromEntity: EntityNameSchema,
  fromId: z.string(),
  toEntity: EntityNameSchema,
  toId: z.string(),
  label: z.string()
}).strict();
var SnapshotSchema = z.object({
  version: z.union([z.literal(1), z.literal(2)]),
  captureStartedAt: z.string().datetime().optional(),
  pipelines: z.array(z.object({ id: z.string(), label: z.string() }).strict()).optional(),
  id: z.string(),
  name: z.string().min(1),
  capturedAt: z.string().datetime(),
  source: z.object({
    kind: z.enum(["fixture", "hubspot", "archive"]),
    accountId: z.string(),
    isTestData: z.literal(true),
    description: z.string()
  }).strict(),
  entities: z.array(EntitySchema).length(4),
  records: z.array(RecordSchema).max(4e4),
  links: z.array(LinkSchema).max(2e5),
  stages: z.array(StageSchema).min(1),
  rules: z.array(RuleSchema),
  unsupported: z.array(z.string()),
  manifest: z.object({
    complete: z.boolean(),
    expectedCounts: z.record(z.number().int().nonnegative()),
    expectedLinks: z.number().int().nonnegative()
  }).strict()
}).strict();
var AppSpecSchema = z.object({
  version: z.union([z.literal(1), z.literal(2)]),
  roles: z.object({ stage: z.string(), amount: z.string(), pipeline: z.string().nullable(), dueDate: z.string(), taskStatus: z.string() }).strict().optional(),
  title: z.string().min(1).max(100),
  description: z.string().max(500),
  entities: z.array(EntitySchema).length(4),
  stages: z.array(StageSchema).min(1),
  rules: z.array(RuleSchema),
  coverage: z.object({
    supported: z.array(z.string()),
    unsupported: z.array(z.string())
  }).strict()
}).strict();
var GenerationSchema = z.object({
  provider: z.enum(["demo", "ai"]),
  model: z.string().nullable(),
  generatedAt: z.string().datetime(),
  prompt: z.string(),
  approved: z.boolean()
}).strict();
var RecoveryPlanSchema = z.object({
  id: z.string(),
  accountId: z.string(),
  createdAt: z.string().datetime(),
  revision: z.string(),
  status: z.enum(["review", "approved", "applying", "complete", "partial"]),
  source: z.enum(["hubspot", "simulation"]),
  warning: z.string(),
  approvedAt: z.string().nullable(),
  operations: z.array(z.object({
    id: z.string(),
    entity: EntityNameSchema,
    localId: z.string(),
    remoteId: z.string().nullable(),
    kind: z.enum(["create", "update"]),
    label: z.string(),
    fields: z.array(z.object({ field: z.string(), label: z.string(), base: valueSchema, local: valueSchema, remote: valueSchema, conflict: z.boolean(), decision: z.enum(["local", "remote"]).nullable() }).strict()),
    references: z.array(z.object({ field: z.string(), entity: EntityNameSchema, id: z.string().nullable() }).strict()),
    remoteVersion: z.string().nullable(),
    status: z.enum(["pending", "sending", "applied", "failed", "uncertain", "skipped"]),
    error: z.string().nullable()
  }).strict())
}).strict();
var BundleSchema = z.object({
  format: z.enum(["planb-continuity-v1", "planb-continuity-v2"]),
  sessionId: z.string().optional(),
  returnState: z.object({ accountId: z.string(), watermark: z.number().int().min(0), mapping: z.record(z.string().min(1)), plan: RecoveryPlanSchema.nullable() }).strict().optional(),
  exportedAt: z.string().datetime(),
  snapshot: SnapshotSchema,
  spec: AppSpecSchema,
  generation: GenerationSchema,
  records: z.array(RecordSchema),
  changes: z.array(z.object({
    id: z.number().int(),
    at: z.string().datetime(),
    entity: EntityNameSchema,
    recordId: z.string(),
    operation: z.enum(["create", "update"]),
    before: RecordSchema.nullable(),
    after: RecordSchema
  }).strict())
}).strict();
function reconcile(snapshot) {
  const errors = [];
  const names = snapshot.entities.map((e) => e.id);
  if (new Set(names).size !== 4 || entityNames.some((e) => !names.includes(e))) {
    errors.push("La captura debe contener las cuatro entidades, sin duplicados.");
  }
  const ids = /* @__PURE__ */ new Set();
  const availableIds = new Set(snapshot.records.map((r) => r.entity + ":" + r.id));
  for (const record of snapshot.records) {
    const id = record.entity + ":" + record.id;
    if (ids.has(id)) errors.push("Registro duplicado: " + id);
    ids.add(id);
    const entity = snapshot.entities.find((e) => e.id === record.entity);
    if (!entity) continue;
    const fields = new Map(entity.fields.map((f) => [f.key, f]));
    for (const [key, value] of Object.entries(record.values)) {
      const field = fields.get(key);
      if (!field) errors.push("Campo sin definici\xF3n: " + record.entity + "." + key);
      if (field?.type === "reference" && value && field.referenceEntity && !availableIds.has(field.referenceEntity + ":" + String(value))) {
        errors.push("Referencia sin destino: " + id + "." + key);
      }
    }
  }
  for (const entity of snapshot.entities) {
    if (new Set(entity.fields.map((f) => f.key)).size !== entity.fields.length) errors.push("Campos duplicados: " + entity.id);
    if (!entity.fields.some((f) => f.key === entity.displayField)) errors.push("Nombre principal no v\xE1lido: " + entity.id);
    if (entity.columns.some((k) => !entity.fields.some((f) => f.key === k))) errors.push("Columna desconocida: " + entity.id);
  }
  const counts = Object.fromEntries(entityNames.map((name) => {
    const actual = snapshot.records.filter((r) => r.entity === name).length;
    const expected = snapshot.manifest.expectedCounts[name];
    if (expected === void 0 || actual !== expected) errors.push("Recuento incompleto: " + name);
    return [name, { expected: expected ?? 0, actual }];
  }));
  for (const link of snapshot.links) {
    if (!ids.has(link.fromEntity + ":" + link.fromId) || !ids.has(link.toEntity + ":" + link.toId)) {
      errors.push("Relaci\xF3n sin registro de origen o destino.");
    }
  }
  if (snapshot.links.length !== snapshot.manifest.expectedLinks) errors.push("Recuento incompleto de relaciones.");
  if (!snapshot.manifest.complete) errors.push("El origen no confirm\xF3 una captura completa.");
  return {
    complete: errors.length === 0,
    counts,
    expectedLinks: snapshot.manifest.expectedLinks,
    actualLinks: snapshot.links.length,
    errors: [...new Set(errors)]
  };
}
function validateSpec(spec, snapshot, userPrompt = "") {
  const errors = [];
  const seen = /* @__PURE__ */ new Set();
  for (const entity of spec.entities) {
    if (seen.has(entity.id)) errors.push("Entidad duplicada: " + entity.id);
    seen.add(entity.id);
    const source = snapshot.entities.find((e) => e.id === entity.id);
    if (!source) {
      errors.push("Entidad ajena al origen.");
      continue;
    }
    const fields = new Map(source.fields.map((f) => [f.key, f]));
    if (entity.fields.length !== source.fields.length) errors.push("Faltan campos importados: " + entity.id);
    if (new Set(entity.fields.map((f) => f.key)).size !== entity.fields.length) errors.push("Campos duplicados.");
    for (const field of entity.fields) {
      const original = fields.get(field.key);
      if (!original || field.type !== original.type || field.readOnly !== original.readOnly || field.required !== original.required || field.referenceEntity !== original.referenceEntity || JSON.stringify(field.options) !== JSON.stringify(original.options)) {
        errors.push("Se alter\xF3 la definici\xF3n del campo: " + entity.id + "." + field.key);
      }
    }
    if (!fields.has(entity.displayField) || entity.columns.some((k) => !fields.has(k))) errors.push("Vista con campos desconocidos.");
  }
  if (seen.size !== 4) errors.push("Faltan entidades.");
  if (JSON.stringify(spec.stages) !== JSON.stringify(snapshot.stages)) errors.push("Se alteraron las etapas del origen.");
  const ruleIds = /* @__PURE__ */ new Set();
  for (const rule of spec.rules) {
    if (ruleIds.has(rule.id)) errors.push("Regla duplicada.");
    ruleIds.add(rule.id);
    const entity = snapshot.entities.find((e) => e.id === rule.entity);
    const field = entity?.fields.find((f) => f.key === rule.field);
    if (!field || field.readOnly) errors.push("Regla sobre un campo no editable.");
    if (rule.whenField && !entity?.fields.some((f) => f.key === rule.whenField)) errors.push("Condici\xF3n sobre un campo desconocido.");
    if (rule.kind === "conditional_required" && (!rule.whenField || rule.whenValue === null)) errors.push("Regla condicional incompleta.");
    if (rule.kind === "conditional_required") {
      const condition = entity?.fields.find((f) => f.key === rule.whenField);
      if (condition?.type === "enum" && !condition.options.some((o) => o.id === rule.whenValue)) errors.push("La condici\xF3n usa una opci\xF3n desconocida.");
    }
    if (rule.kind === "min" && (field?.type !== "number" || rule.value === null || !Number.isFinite(Number(rule.value)))) errors.push("L\xEDmite num\xE9rico no v\xE1lido.");
    if (rule.kind === "email" && field?.type !== "email" && field?.type !== "text") errors.push("Validaci\xF3n de correo no compatible.");
    if (rule.kind === "allowed_transition") {
      const valid = new Set(snapshot.stages.map((s) => s.id));
      if (rule.entity !== "deals" || rule.field !== "dealstage") errors.push("Las transiciones solo se aplican a la etapa de una oportunidad.");
      if (!rule.whenValue || !rule.value || !valid.has(rule.whenValue) || rule.value.split(",").some((v) => !valid.has(v))) errors.push("Transici\xF3n comercial desconocida.");
    }
    if (rule.origin === "configuration" && !snapshot.rules.some((r) => JSON.stringify(r) === JSON.stringify(rule))) {
      errors.push("Regla importada sin evidencia en la captura.");
    }
    if (rule.origin === "user" && (!userPrompt.trim() || !userPrompt.includes(rule.evidence))) {
      errors.push("Regla de usuario sin una cita exacta de su instrucci\xF3n.");
    }
  }
  for (const rule of snapshot.rules) {
    if (!spec.rules.some((r) => JSON.stringify(r) === JSON.stringify(rule))) errors.push("Falta una regla del origen: " + rule.id);
  }
  if (spec.coverage.supported.length === 0) errors.push("La aplicaci\xF3n debe declarar procesos cubiertos.");
  for (const limitation of snapshot.unsupported) {
    if (!spec.coverage.unsupported.includes(limitation)) errors.push("Falta declarar una limitaci\xF3n del origen.");
  }
  return [...new Set(errors)];
}
function validateRecord(spec, record, previous) {
  const errors = {};
  const entity = spec.entities.find((e) => e.id === record.entity);
  if (!entity) return { _form: "Entidad desconocida." };
  for (const key of Object.keys(record.values)) if (!entity.fields.some((f) => f.key === key)) errors[key] = "Campo desconocido.";
  for (const field of entity.fields) {
    const value = record.values[field.key];
    const empty = value === null || value === void 0 || value === "";
    if (field.readOnly && previous && value !== previous.values[field.key]) errors[field.key] = "Este campo es de solo lectura.";
    if (field.required && empty) errors[field.key] = "Completa este campo.";
    if (empty) continue;
    if (field.type === "number" && (typeof value !== "number" || !Number.isFinite(value))) errors[field.key] = "Introduce un n\xFAmero v\xE1lido.";
    if (field.type === "boolean" && typeof value !== "boolean") errors[field.key] = "Introduce un valor verdadero o falso.";
    if (["text", "email", "date", "datetime", "multiselect", "enum", "reference"].includes(field.type) && typeof value !== "string") errors[field.key] = "Introduce un texto v\xE1lido.";
    if (field.type === "datetime" && (!/^\d{4}-\d{2}-\d{2}T/.test(String(value)) || Number.isNaN(Date.parse(String(value))))) errors[field.key] = "Introduce fecha y hora v\xE1lidas.";
    if (field.type === "multiselect" && String(value).split(";").some((v) => !field.options.some((o) => o.id === v))) errors[field.key] = "Hay opciones desconocidas.";
    if (field.type === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value))) errors[field.key] = "Introduce un correo v\xE1lido.";
    if (field.type === "date") {
      const text = String(value), parsed = Date.parse(text);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(text) || Number.isNaN(parsed) || new Date(parsed).toISOString().slice(0, 10) !== text) errors[field.key] = "Introduce una fecha v\xE1lida.";
    }
    if (field.type === "enum" && !field.options.some((o) => o.id === value)) errors[field.key] = "Selecciona una opci\xF3n v\xE1lida.";
    if (typeof value === "string" && value.length > 1e4) errors[field.key] = "El texto es demasiado largo.";
  }
  for (const rule of spec.rules.filter((r) => r.entity === record.entity)) {
    const value = record.values[rule.field];
    const empty = value === null || value === void 0 || value === "";
    if (rule.kind === "required" && empty) errors[rule.field] = rule.description;
    if (rule.kind === "email" && !empty && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value))) errors[rule.field] = rule.description;
    if (rule.kind === "min" && !empty && Number(value) < Number(rule.value)) errors[rule.field] = rule.description;
    if (rule.kind === "conditional_required" && String(record.values[rule.whenField]) === rule.whenValue && empty) errors[rule.field] = rule.description;
    if (rule.kind === "allowed_transition" && previous && previous.values[rule.field] !== value && String(previous.values[rule.field]) === rule.whenValue && !rule.value.split(",").includes(String(value))) errors[rule.field] = rule.description;
  }
  const pipeline = record.values.pipeline;
  if (record.entity === "deals" && pipeline) {
    const stage = spec.stages.find((s) => s.id === record.values.dealstage);
    if (stage?.pipelineId && stage.pipelineId !== pipeline) errors.dealstage = "La etapa no pertenece a este proceso comercial.";
  }
  return errors;
}

// server/store.ts
import { DatabaseSync } from "node:sqlite";
import { mkdirSync as mkdirSync2 } from "node:fs";
import { dirname as dirname2 } from "node:path";
import { randomUUID } from "node:crypto";

// server/crypto.ts
import { randomBytes, createCipheriv, createDecipheriv, scryptSync } from "node:crypto";
import { existsSync, readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
function dpapi(value, decrypt) {
  const method = decrypt ? "Unprotect" : "Protect";
  const script = "Add-Type -AssemblyName System.Security; $v=[Console]::In.ReadToEnd(); $b=[Convert]::FromBase64String($v); $r=[Security.Cryptography.ProtectedData]::" + method + "($b,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser); [Console]::Out.Write([Convert]::ToBase64String($r))";
  const result = spawnSync("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", script], { input: value, encoding: "utf8", windowsHide: true });
  if (result.status !== 0 || !result.stdout.trim()) throw new Error("No se pudo abrir la protecci\xF3n local de Windows. Conserva la carpeta y usa una exportaci\xF3n con contrase\xF1a para trasladar los datos.");
  return result.stdout.trim();
}
var keyCache = /* @__PURE__ */ new Map();
function localKey(folder) {
  mkdirSync(folder, { recursive: true });
  const filename = join(folder, ".planb-key");
  if (existsSync(filename) && keyCache.has(filename)) return keyCache.get(filename);
  if (existsSync(filename)) {
    const value = JSON.parse(readFileSync(filename, "utf8"));
    if (value.kind === "dpapi" && process.platform === "win32") {
      const key2 = Buffer.from(dpapi(value.data, true), "base64");
      keyCache.set(filename, key2);
      return key2;
    }
    if (value.kind === "test" && process.env.NODE_ENV === "test") {
      const key2 = Buffer.from(value.data, "base64");
      keyCache.set(filename, key2);
      return key2;
    }
    throw new Error("La clave local requiere Windows o el entorno de pruebas original.");
  }
  const key = randomBytes(32);
  if (process.platform !== "win32" && process.env.NODE_ENV !== "test") throw new Error("La protecci\xF3n local comercial requiere Windows.");
  writeFileSync(filename, JSON.stringify(process.platform === "win32" ? { kind: "dpapi", data: dpapi(key.toString("base64"), false) } : { kind: "test", data: key.toString("base64") }), { mode: 384, flag: "wx" });
  keyCache.set(filename, key);
  return key;
}
function seal(text, key) {
  const iv = randomBytes(12), cipher = createCipheriv("aes-256-gcm", key, iv);
  const body = Buffer.concat([cipher.update(text, "utf8"), cipher.final()]);
  return "enc1:" + Buffer.concat([iv, cipher.getAuthTag(), body]).toString("base64");
}
function open(text, key) {
  if (!text.startsWith("enc1:")) return text;
  const data = Buffer.from(text.slice(5), "base64");
  const decipher = createDecipheriv("aes-256-gcm", key, data.subarray(0, 12));
  decipher.setAuthTag(data.subarray(12, 28));
  return Buffer.concat([decipher.update(data.subarray(28)), decipher.final()]).toString("utf8");
}
function encodePortable(value, password) {
  if (password.length < 12 || password.length > 200) throw new Error("Usa una contrase\xF1a de recuperaci\xF3n de entre 12 y 200 caracteres.");
  const salt = randomBytes(16), key = scryptSync(password, salt, 32);
  return JSON.stringify({ format: "planb-encrypted-v2", kdf: "scrypt", salt: salt.toString("base64"), data: seal(JSON.stringify(value), key) });
}
function decodePortable(raw, password) {
  const value = JSON.parse(raw);
  if (value.format !== "planb-encrypted-v2" || value.kdf !== "scrypt" || typeof value.salt !== "string" || typeof value.data !== "string") throw new Error("El archivo cifrado no es compatible.");
  if (Buffer.from(value.salt, "base64").length !== 16 || !value.data.startsWith("enc1:") || value.data.length > 2e8) throw new Error("Archivo cifrado no v\xE1lido.");
  try {
    return JSON.parse(open(value.data, scryptSync(password, Buffer.from(value.salt, "base64"), 32)));
  } catch {
    throw new Error("La contrase\xF1a es incorrecta o el archivo est\xE1 da\xF1ado.");
  }
}

// server/store.ts
var AppError = class extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
};
var Store = class {
  constructor(filename) {
    this.filename = filename;
    if (filename !== ":memory:") mkdirSync2(dirname2(filename), { recursive: true });
    this.key = filename === ":memory:" ? null : localKey(dirname2(filename));
    this.db = new DatabaseSync(filename);
    this.db.exec(
      "PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000; PRAGMA secure_delete=ON;CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);CREATE TABLE IF NOT EXISTS records(entity TEXT NOT NULL,id TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY(entity,id));CREATE TABLE IF NOT EXISTS changes(id INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT NOT NULL,entity TEXT NOT NULL,record_id TEXT NOT NULL,operation TEXT NOT NULL,before_json TEXT,after_json TEXT NOT NULL);CREATE TABLE IF NOT EXISTS archives(id TEXT PRIMARY KEY,at TEXT NOT NULL,bundle TEXT NOT NULL);CREATE TABLE IF NOT EXISTS usage(id TEXT PRIMARY KEY,month TEXT NOT NULL,reserved_usd REAL NOT NULL,used_usd REAL NOT NULL DEFAULT 0,status TEXT NOT NULL);CREATE TABLE IF NOT EXISTS captures(id TEXT PRIMARY KEY,at TEXT NOT NULL,bytes INTEGER NOT NULL,payload TEXT NOT NULL);"
    );
    this.migrateEncryption();
    this.db.prepare("UPDATE usage SET status='interrupted' WHERE status='pending'").run();
  }
  db;
  key;
  close() {
    this.db.close();
  }
  encode(value) {
    const text = JSON.stringify(value);
    return this.key ? seal(text, this.key) : text;
  }
  decode(value) {
    return JSON.parse(this.key ? open(value, this.key) : value);
  }
  migrateEncryption() {
    if (!this.key) return;
    let changed = false;
    this.transaction(() => {
      for (const [table, columns] of Object.entries({ meta: ["value"], records: ["value"], changes: ["before_json", "after_json"], archives: ["bundle"], captures: ["payload"] })) {
        const rows = this.db.prepare("SELECT rowid AS rid," + columns.join(",") + " FROM " + table).all();
        for (const row of rows) for (const column of columns) {
          const value = row[column];
          if (typeof value === "string" && !value.startsWith("enc1:")) {
            JSON.parse(value);
            this.db.prepare("UPDATE " + table + " SET " + column + "=? WHERE rowid=?").run(seal(value, this.key), row.rid);
            changed = true;
          }
        }
      }
    });
    if (changed) this.db.exec("VACUUM");
  }
  get(key, fallback) {
    const row = this.db.prepare("SELECT value FROM meta WHERE key=?").get(key);
    return row ? this.decode(row.value) : fallback;
  }
  set(key, value) {
    this.db.prepare("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(key, this.encode(value));
  }
  get snapshot() {
    return this.get("snapshot", null);
  }
  get spec() {
    return this.get("spec", null);
  }
  get generation() {
    return this.get("generation", null);
  }
  get reconciliation() {
    return this.get("reconciliation", null);
  }
  get disconnected() {
    return this.get("disconnected", false);
  }
  get ready() {
    return !!(this.snapshot && this.spec && this.generation?.approved && this.reconciliation?.complete);
  }
  get changesCount() {
    return Number(this.db.prepare("SELECT COUNT(*) AS n FROM changes").get().n);
  }
  get pendingChangesCount() {
    const watermark = this.get("returnWatermark:hubspot", 0);
    return Number(this.db.prepare("SELECT COUNT(*) AS n FROM changes WHERE id>?").get(watermark).n);
  }
  transaction(fn) {
    this.db.exec("BEGIN IMMEDIATE");
    try {
      const result = fn();
      this.db.exec("COMMIT");
      return result;
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
  }
  importSnapshot(raw, replace = false) {
    if (this.get("returnBusy", false)) throw new AppError(409, "Hay una devoluci\xF3n en curso.");
    if (this.get("continuitySession", null)) throw new AppError(409, "Cierra la sesi\xF3n de continuidad antes de importar otra captura.");
    const parsed = SnapshotSchema.safeParse(raw);
    if (!parsed.success) throw new AppError(422, "La captura tiene un formato no v\xE1lido.", parsed.error.flatten());
    const snapshot = parsed.data;
    const report = reconcile(snapshot);
    const ruleErrors = validateSpec({
      version: 1,
      title: snapshot.name,
      description: "",
      entities: snapshot.entities,
      stages: snapshot.stages,
      rules: snapshot.rules,
      coverage: { supported: ["Datos del origen"], unsupported: snapshot.unsupported }
    }, snapshot);
    report.errors.push(...ruleErrors);
    report.complete = report.errors.length === 0;
    if (!report.complete) {
      this.set("lastImportError", report);
      throw new AppError(422, "Importaci\xF3n incompleta. Se conserva la \xFAltima captura v\xE1lida.", report);
    }
    if (this.changesCount && !replace) throw new AppError(409, "Hay cambios locales. Exporta una copia antes de cambiar el origen.");
    this.addCapture(snapshot);
    if (this.ready) {
      this.set("candidate", { snapshot, reconciliation: report, spec: null, generation: null, error: null, replaceRecords: true, replaceApproved: replace, baselineChanges: this.changesCount });
      return report;
    }
    this.transaction(() => {
      const existing = this.bundleOrNull();
      if (existing) this.db.prepare("INSERT INTO archives(id,at,bundle) VALUES(?,?,?)").run(randomUUID(), (/* @__PURE__ */ new Date()).toISOString(), this.encode(existing));
      this.db.exec("DELETE FROM records; DELETE FROM changes;");
      for (const record of snapshot.records) this.insertRecord(record);
      this.set("snapshot", snapshot);
      this.set("reconciliation", report);
      this.set("spec", null);
      this.set("generation", null);
      this.set("lastError", null);
      this.set("lastImportError", null);
      this.set("disconnected", false);
      this.set("candidate", null);
      this.resetReturnState();
    });
    return report;
  }
  saveGeneration(raw, generation) {
    if (this.get("returnBusy", false)) throw new AppError(409, "Hay una devoluci\xF3n en curso.");
    if (this.get("continuitySession", null)) throw new AppError(409, "La generaci\xF3n queda pausada durante una sesi\xF3n de continuidad.");
    const candidate = this.candidate;
    const snapshot = candidate?.snapshot ?? this.snapshot;
    if (!snapshot) throw new AppError(409, "Importa primero una captura.");
    const parsed = AppSpecSchema.safeParse(raw);
    const errors = parsed.success ? validateSpec(parsed.data, snapshot, generation.prompt) : ["La especificaci\xF3n no cumple el contrato de la aplicaci\xF3n."];
    if (errors.length || !parsed.success) {
      this.failGeneration("La generaci\xF3n no super\xF3 la validaci\xF3n.");
      throw new AppError(422, "La aplicaci\xF3n no est\xE1 preparada. Revisa la generaci\xF3n.", errors);
    }
    if (this.ready) this.set("candidate", { ...candidate ?? { snapshot, reconciliation: this.reconciliation, replaceRecords: false, replaceApproved: false, baselineChanges: this.changesCount }, spec: parsed.data, generation: { ...generation, approved: false }, error: null });
    else this.transaction(() => {
      this.set("spec", parsed.data);
      this.set("generation", { ...generation, approved: false });
      this.set("lastError", null);
    });
  }
  get candidate() {
    return this.get("candidate", null);
  }
  failGeneration(message) {
    if (this.get("continuitySession", null)) return;
    if (this.ready) {
      const candidate = this.candidate ?? { snapshot: this.snapshot, reconciliation: this.reconciliation, spec: null, generation: null, replaceRecords: false, replaceApproved: false, baselineChanges: this.changesCount };
      this.set("candidate", { ...candidate, error: message });
    } else this.set("lastError", message);
  }
  activate() {
    if (this.get("continuitySession", null)) throw new AppError(409, "Cierra la sesi\xF3n de continuidad antes de activar otra versi\xF3n.");
    const candidate = this.candidate;
    const spec = candidate?.spec ?? (!candidate ? this.spec : null), snapshot = candidate?.snapshot ?? this.snapshot, generation = candidate?.generation ?? (!candidate ? this.generation : null);
    if (!spec || !snapshot || !generation) throw new AppError(409, "Genera primero una especificaci\xF3n.");
    if (candidate?.error || !this.ready && this.get("lastError", null)) throw new AppError(409, "La \xFAltima generaci\xF3n fall\xF3. Vuelve a generarla.");
    if (candidate?.replaceRecords && this.changesCount && (!candidate.replaceApproved || candidate.baselineChanges !== this.changesCount)) throw new AppError(409, "Hay cambios locales nuevos. Exporta y revisa otra vez la sustituci\xF3n.");
    const errors = validateSpec(spec, snapshot, generation.prompt);
    for (const record of candidate?.replaceRecords ? snapshot.records : this.records()) {
      const issues = validateRecord(spec, record);
      for (const [key, message] of Object.entries(issues)) errors.push(record.entity + "/" + record.id + "/" + key + ": " + message);
    }
    if (!this.reconciliation?.complete || errors.length) {
      this.failGeneration("Hay datos o reglas que necesitan revisi\xF3n.");
      throw new AppError(422, "No se puede activar todav\xEDa.", errors.slice(0, 50));
    }
    this.transaction(() => {
      if (candidate) {
        const old = this.bundleOrNull();
        if (old) this.db.prepare("INSERT INTO archives(id,at,bundle) VALUES(?,?,?)").run(randomUUID(), (/* @__PURE__ */ new Date()).toISOString(), this.encode(old));
        if (candidate.replaceRecords) {
          this.db.exec("DELETE FROM records; DELETE FROM changes;");
          for (const record of snapshot.records) this.insertRecord(record);
          this.resetReturnState();
        }
        this.set("snapshot", snapshot);
        this.set("spec", spec);
        this.set("reconciliation", candidate.reconciliation);
      }
      this.set("generation", { ...generation, approved: true });
      this.set("candidate", null);
      this.set("lastError", null);
    });
  }
  insertRecord(record) {
    this.db.prepare("INSERT INTO records(entity,id,value) VALUES(?,?,?) ON CONFLICT(entity,id) DO UPDATE SET value=excluded.value").run(record.entity, record.id, this.encode(record));
  }
  records(entity) {
    const rows = entity ? this.db.prepare("SELECT value FROM records WHERE entity=? ORDER BY rowid").all(entity) : this.db.prepare("SELECT value FROM records ORDER BY rowid").all();
    return rows.map((r) => this.decode(r.value));
  }
  record(entity, id) {
    const row = this.db.prepare("SELECT value FROM records WHERE entity=? AND id=?").get(entity, id);
    return row ? this.decode(row.value) : null;
  }
  saveRecord(entity, values, id) {
    if (this.get("returnBusy", false)) throw new AppError(409, "Espera a que termine la devoluci\xF3n revisada.");
    const plan = this.get("recoveryPlan", null);
    if (plan && plan.status !== "complete" && plan.operations.some((o) => ["applied", "sending", "uncertain"].includes(o.status))) throw new AppError(409, "Resuelve la devoluci\xF3n parcial antes de seguir editando. Tus cambios actuales se conservan.");
    if (!this.ready || !this.spec) throw new AppError(409, "Revisa y activa primero la aplicaci\xF3n.");
    const previous = id ? this.record(entity, id) : null;
    if (id && !previous) throw new AppError(404, "No se encontr\xF3 el registro.");
    const record = RecordSchema.parse({ entity, id: id ?? "local-" + randomUUID(), values: previous ? { ...previous.values, ...values } : values });
    const errors = validateRecord(this.spec, record, previous);
    const definition = this.spec.entities.find((e) => e.id === entity);
    for (const field of definition.fields) {
      const value = record.values[field.key];
      if (field.type === "reference" && value && field.referenceEntity && !this.record(field.referenceEntity, String(value))) {
        errors[field.key] = "El registro relacionado no existe.";
      }
      if (!previous && field.readOnly && value !== void 0 && value !== null && value !== "") errors[field.key] = "Este campo no se puede crear manualmente.";
    }
    if (Object.keys(errors).length) throw new AppError(422, "Revisa los campos se\xF1alados.", errors);
    this.transaction(() => {
      this.insertRecord(record);
      this.db.prepare("INSERT INTO changes(at,entity,record_id,operation,before_json,after_json) VALUES(?,?,?,?,?,?)").run((/* @__PURE__ */ new Date()).toISOString(), entity, record.id, previous ? "update" : "create", previous ? this.encode(previous) : null, this.encode(record));
      this.set("returnComplete", false);
    });
    return record;
  }
  changes() {
    return this.db.prepare("SELECT * FROM changes ORDER BY id").all().map((r) => ({
      id: r.id,
      at: r.at,
      entity: r.entity,
      recordId: r.record_id,
      operation: r.operation,
      before: r.before_json ? this.decode(r.before_json) : null,
      after: this.decode(r.after_json)
    }));
  }
  bundleOrNull() {
    const snapshot = this.snapshot, spec = this.spec, generation = this.generation;
    if (!snapshot || !spec || !generation) return null;
    const plan = this.get("recoveryPlan", null);
    return {
      format: "planb-continuity-v2",
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      sessionId: this.get("sessionId", ""),
      returnState: { accountId: snapshot.source.accountId, watermark: this.get("returnWatermark:hubspot", 0), mapping: this.get("remoteMapping:hubspot", {}), plan: plan?.source === "hubspot" ? plan : null },
      snapshot,
      spec,
      generation,
      records: this.records(),
      changes: this.changes()
    };
  }
  bundle() {
    if (!this.ready) throw new AppError(409, "Activa una aplicaci\xF3n verificada antes de exportar.");
    return this.bundleOrNull();
  }
  restoreBundle(raw) {
    const parsed = BundleSchema.safeParse(raw);
    if (!parsed.success) throw new AppError(422, "El paquete de continuidad no es v\xE1lido.");
    const bundle = parsed.data;
    const report = reconcile(bundle.snapshot);
    const errors = validateSpec(bundle.spec, bundle.snapshot, bundle.generation.prompt);
    const ids = new Set(bundle.records.map((r) => r.entity + ":" + r.id));
    const replay = new Map(bundle.snapshot.records.map((r) => [r.entity + ":" + r.id, r]));
    let previousChangeId = 0;
    for (const change of bundle.changes) {
      const key = change.entity + ":" + change.recordId, prior = replay.get(key) ?? null;
      if (change.id <= previousChangeId || change.after.entity !== change.entity || change.after.id !== change.recordId || JSON.stringify(prior) !== JSON.stringify(change.before) || change.operation !== (prior ? "update" : "create")) errors.push("El historial no corresponde a la captura original.");
      previousChangeId = change.id;
      replay.set(key, change.after);
    }
    for (const record of bundle.records) if (JSON.stringify(replay.get(record.entity + ":" + record.id)) !== JSON.stringify(record)) errors.push("Hay registros activos sin una operaci\xF3n coherente.");
    if (replay.size !== bundle.records.length) errors.push("El paquete perdi\xF3 registros del historial.");
    const returned = bundle.returnState;
    if (returned) {
      if (returned.accountId !== bundle.snapshot.source.accountId || returned.watermark > previousChangeId) errors.push("Estado de devoluci\xF3n incompatible con el historial.");
      const created = new Set(bundle.changes.filter((c) => c.operation === "create").map((c) => c.entity + ":" + c.recordId));
      if (Object.keys(returned.mapping).some((key) => !created.has(key))) errors.push("Correspondencia de IDs sin alta local.");
      if (returned.plan) {
        if (returned.plan.source !== "hubspot" || returned.plan.accountId !== returned.accountId) errors.push("Plan de devoluci\xF3n de otro destino.");
        for (const op of returned.plan.operations) {
          const definition = bundle.spec.entities.find((e) => e.id === op.entity);
          if (!ids.has(op.entity + ":" + op.localId) || op.fields.some((f) => !definition?.fields.some((d) => d.key === f.field && !d.readOnly && d.type !== "reference")) || op.references.some((r) => !ids.has(r.entity + ":" + r.id) || !definition?.fields.some((f) => f.key === r.field && f.referenceEntity === r.entity))) errors.push("Operaci\xF3n de devoluci\xF3n incompatible con la copia.");
        }
      }
    }
    if (ids.size !== bundle.records.length) errors.push("Registros activos duplicados.");
    for (const baseline of bundle.snapshot.records) {
      if (!ids.has(baseline.entity + ":" + baseline.id)) errors.push("El paquete perdi\xF3 un registro de la captura.");
    }
    for (const record of bundle.records) {
      for (const [field, message] of Object.entries(validateRecord(bundle.spec, record))) errors.push(record.id + "/" + field + ": " + message);
      const entity = bundle.spec.entities.find((e) => e.id === record.entity);
      for (const field of entity?.fields ?? []) if (field.type === "reference" && record.values[field.key] && !ids.has(field.referenceEntity + ":" + String(record.values[field.key]))) errors.push("Referencia inv\xE1lida en el paquete.");
    }
    if (!report.complete || errors.length || !bundle.generation.approved) throw new AppError(422, "El paquete no super\xF3 la comprobaci\xF3n de integridad.", [...report.errors, ...errors]);
    this.transaction(() => {
      this.db.exec("DELETE FROM records; DELETE FROM changes;");
      for (const record of bundle.records) this.insertRecord(record);
      for (const change of bundle.changes) this.db.prepare("INSERT INTO changes(id,at,entity,record_id,operation,before_json,after_json) VALUES(?,?,?,?,?,?,?)").run(change.id, change.at, change.entity, change.recordId, change.operation, change.before ? this.encode(change.before) : null, this.encode(change.after));
      this.set("snapshot", bundle.snapshot);
      this.set("spec", bundle.spec);
      this.set("generation", bundle.generation);
      this.set("reconciliation", report);
      this.set("lastError", null);
      this.set("disconnected", true);
      this.set("candidate", null);
      this.set("sessionId", bundle.sessionId ?? randomUUID());
      this.resetReturnState();
      if (returned) {
        this.set("returnWatermark:hubspot", returned.watermark);
        this.set("remoteMapping:hubspot", returned.mapping);
        const plan = returned.plan;
        if (plan) {
          if (plan.status === "applying") {
            for (const op of plan.operations) if (op.status === "sending") {
              op.status = "uncertain";
              op.error = "La copia se export\xF3 durante un env\xEDo. Verifica el resultado remoto antes de repetir.";
            }
            plan.status = "partial";
          }
          if (plan.status === "approved") {
            plan.status = "review";
            plan.approvedAt = null;
          }
          this.set("recoveryPlan", plan);
        }
      }
    });
    this.addCapture(bundle.snapshot);
  }
  addCapture(snapshot) {
    const report = reconcile(snapshot);
    if (!report.complete) throw new AppError(422, "La captura no est\xE1 conciliada.", report.errors);
    const id = snapshot.id + ":" + snapshot.capturedAt, payload = this.encode(snapshot);
    if (this.db.prepare("SELECT id FROM captures WHERE id=?").get(id)) return id;
    this.pruneCaptures();
    const used = this.storageBytes();
    if (used + Buffer.byteLength(payload) > 2 * 1024 ** 3) throw new AppError(507, "Se alcanz\xF3 el l\xEDmite local de 2 GB. Conserva los cambios pendientes y revisa el historial.");
    this.db.prepare("INSERT OR IGNORE INTO captures(id,at,bytes,payload) VALUES(?,?,?,?)").run(id, snapshot.capturedAt, Buffer.byteLength(payload), payload);
    this.pruneCaptures();
    return id;
  }
  storageBytes() {
    let total = 0;
    for (const [table, columns] of Object.entries({ meta: ["value"], records: ["value"], changes: ["before_json", "after_json"], archives: ["bundle"], captures: ["payload"] })) {
      const expression = columns.map((c) => "COALESCE(length(CAST(" + c + " AS BLOB)),0)").join("+");
      total += Number(this.db.prepare("SELECT COALESCE(SUM(" + expression + "),0) AS n FROM " + table).get().n);
    }
    return total;
  }
  resetReturnState() {
    for (const key of ["recoveryPlan", "continuitySession", "simulatedRemote"]) this.set(key, null);
    for (const kind of ["simulation", "hubspot"]) {
      this.set("returnWatermark:" + kind, 0);
      this.set("remoteMapping:" + kind, {});
    }
    this.set("returnComplete", false);
    this.set("sessionCapture", "");
  }
  captures() {
    return this.db.prepare("SELECT id,at,bytes FROM captures ORDER BY at DESC,rowid DESC").all();
  }
  capture(id) {
    const row = this.db.prepare("SELECT payload FROM captures WHERE id=?").get(id);
    if (!row) throw new AppError(404, "No se encontr\xF3 la captura.");
    return this.decode(row.payload);
  }
  pruneCaptures(now = Date.now()) {
    const all = this.captures(), protectedId = this.snapshot ? this.snapshot.id + ":" + this.snapshot.capturedAt : "";
    const days = /* @__PURE__ */ new Set();
    let hours = 0;
    for (const item of all) {
      const recent = now - Date.parse(item.at) < 24 * 36e5 && hours++ < 24;
      const day = item.at.slice(0, 10);
      const daily = !days.has(day) && days.size < 30;
      if (daily) days.add(day);
      if (!recent && !daily && item.id !== protectedId && item.id !== this.get("sessionCapture", "")) this.db.prepare("DELETE FROM captures WHERE id=?").run(item.id);
    }
  }
  page(entity, query = "", offset = 0, limit = 50, pipeline = "") {
    const normalize = (v) => v.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
    const all = this.records(), names = new Map(all.map((r) => [r.entity + ":" + r.id, Object.values(r.values).join(" ")]));
    const fields = this.spec?.entities.find((e) => e.id === entity)?.fields ?? [];
    const needle = normalize(query);
    const matching = all.filter((r) => r.entity === entity && (!pipeline || r.values.pipeline === pipeline) && (!needle || normalize(Object.values(r.values).join(" ") + " " + fields.filter((f) => f.type === "reference").map((f) => names.get(f.referenceEntity + ":" + r.values[f.key]) ?? "").join(" ")).includes(needle)));
    const records = matching.slice(offset, offset + limit), related = /* @__PURE__ */ new Map();
    for (const record of records) for (const field of fields) if (field.type === "reference" && record.values[field.key]) {
      const item = all.find((r) => r.entity === field.referenceEntity && r.id === record.values[field.key]);
      if (item) related.set(item.entity + ":" + item.id, item);
    }
    return { records, related: [...related.values()], total: matching.length, offset, limit };
  }
  usage() {
    const month = (/* @__PURE__ */ new Date()).toISOString().slice(0, 7);
    const row = this.db.prepare("SELECT COALESCE(SUM(used_usd),0) AS used,COALESCE(SUM(CASE WHEN status IN ('pending','interrupted') THEN reserved_usd ELSE 0 END),0) AS reserved,COUNT(*) AS requests FROM usage WHERE month=?").get(month);
    return { usedUsd: row.used, reservedUsd: row.reserved, limitUsd: 25, requests: row.requests };
  }
  reserveUsage(worstCaseUsd) {
    if (!Number.isFinite(worstCaseUsd) || worstCaseUsd < 0) throw new AppError(422, "La reserva de presupuesto no es v\xE1lida.");
    const id = randomUUID(), month = (/* @__PURE__ */ new Date()).toISOString().slice(0, 7);
    this.transaction(() => {
      const used = this.usage();
      if (used.usedUsd + used.reservedUsd + worstCaseUsd > used.limitUsd) throw new AppError(429, "Se alcanz\xF3 el l\xEDmite local de 25 USD para pruebas de IA.");
      this.db.prepare("INSERT INTO usage(id,month,reserved_usd,used_usd,status) VALUES(?,?,?,0,'pending')").run(id, month, worstCaseUsd);
    });
    return id;
  }
  settleUsage(id, usd) {
    if (!Number.isFinite(usd) || usd < 0) throw new AppError(422, "El coste comunicado por el proveedor no es v\xE1lido.");
    this.db.prepare("UPDATE usage SET used_usd=?,reserved_usd=0,status='complete' WHERE id=?").run(usd, id);
  }
};

// server/exporter.ts
import archiver from "archiver";
import { existsSync as existsSync2, readFileSync as readFileSync2 } from "node:fs";
import { join as join2 } from "node:path";
async function runtimeZip(bundle, root2, password) {
  const runtimeFile = existsSync2(join2(root2, "runtime.mjs")) ? join2(root2, "runtime.mjs") : join2(root2, "build", "runtime.mjs");
  const frontend = join2(root2, "dist");
  if (!existsSync2(runtimeFile) || !existsSync2(join2(frontend, "index.html"))) throw new AppError(503, "El paquete necesita una compilaci\xF3n completa de la aplicaci\xF3n.");
  const archive = archiver("zip", { zlib: { level: 3 } });
  const chunks = [];
  const finished = new Promise((resolve2, reject) => {
    archive.on("data", (data) => chunks.push(Buffer.from(data)));
    archive.on("end", () => resolve2(Buffer.concat(chunks)));
    archive.on("error", reject);
  });
  archive.append(readFileSync2(runtimeFile), { name: "runtime.mjs" });
  archive.append(password ? encodePortable(bundle, password) : JSON.stringify(bundle, null, 2), { name: password ? "continuity.encrypted.json" : "continuity.seed.json" });
  const worker = existsSync2(join2(root2, "drill.mjs")) ? join2(root2, "drill.mjs") : join2(root2, "build", "drill.mjs");
  if (existsSync2(worker)) archive.file(worker, { name: "drill.mjs" });
  const guard = existsSync2(join2(root2, "block-external.cjs")) ? join2(root2, "block-external.cjs") : join2(root2, "scripts", "block-external.cjs");
  if (existsSync2(guard)) archive.file(guard, { name: "block-external.cjs" });
  archive.directory(frontend, "dist");
  const moduleRoot = join2(root2, "runtime-assets", "node_modules");
  const runtimeModules = existsSync2(moduleRoot) ? moduleRoot : join2(root2, "node_modules");
  archive.directory(runtimeModules, "node_modules", (entry) => {
    const name = entry.name.replace(/^node_modules\//, "");
    return !name.split("/").some((part) => [".cache", ".bin", "lucide-react", "react", "react-dom", "scheduler"].includes(part)) && !name.endsWith(".log") ? entry : false;
  });
  archive.file(process.execPath, { name: process.platform === "win32" ? "node.exe" : "node" });
  const license = join2(root2, "NODE-LICENSE.txt");
  if (existsSync2(license)) archive.file(license, { name: "NODE-LICENSE.txt" });
  const frontendLicense = join2(root2, "THIRD-PARTY-LICENSES.txt");
  if (existsSync2(frontendLicense)) archive.file(frontendLicense, { name: "THIRD-PARTY-LICENSES.txt" });
  archive.append('@echo off\r\ncd /d "%~dp0"\r\n"%~dp0node.exe" runtime.mjs\r\npause\r\n', { name: "ABRIR PLAN B.cmd" });
  archive.append("# Plan B v2 \xB7 Aplicaci\xF3n independiente\n\n1. Extrae todo el ZIP en una carpeta de Windows.\n2. Abre ABRIR PLAN B.cmd y entra en la direcci\xF3n local que aparece.\n" + (password ? "3. Pulsa Restaurar archivo, selecciona continuity.encrypted.json e introduce la contrase\xF1a de recuperaci\xF3n que elegiste al exportar. La contrase\xF1a no est\xE1 incluida en el ZIP.\n" : "3. Los datos ficticios de continuity.seed.json se cargan en el primer inicio.\n") + "\nNode, dependencias y recursos visuales est\xE1n incluidos. No se necesita HubSpot ni un proveedor IA. Los conectores y sus credenciales no est\xE1n en este paquete.\n\nLos cambios se conservan en data/planb.sqlite, con valores cifrados y una clave data/.planb-key protegida por DPAPI para tu usuario de Windows. Conserva la carpeta completa y det\xE9n el servidor antes de moverla. Para cambiar de usuario o equipo, exporta una copia con contrase\xF1a desde la app y rest\xE1urala en el destino; copiar solo la base no transfiere DPAPI.\n\nLa base activa prevalece sobre el archivo inicial despu\xE9s de restaurar. Puedes trabajar, exportar cambios JSON/CSV, crear copias cifradas y ejecutar el simulacro aislado. La devoluci\xF3n revisada se prepara en el generador; el runtime no contiene esa ruta.\n\nEsta entrega admite un operador y datos de ensayo. Conserva la contrase\xF1a de recuperaci\xF3n por separado: no existe un servicio para recuperarla.\n", { name: "LEEME.md" });
  await archive.finalize();
  return finished;
}

// server/security.ts
import { randomBytes as randomBytes2, scryptSync as scryptSync2, timingSafeEqual } from "node:crypto";
import { z as z2 } from "zod";
function registerSecurity(app2, store2) {
  const sessions = /* @__PURE__ */ new Map(), attempts = /* @__PURE__ */ new Map();
  const credential = () => store2.get("password", null);
  const cookie = (header) => /(?:^|;\s*)planb_session=([a-f0-9]+)/.exec(header ?? "")?.[1] ?? "";
  const authenticated = (header, extend = false) => {
    const id = cookie(header), expiry = sessions.get(id);
    if (!expiry || expiry < Date.now()) {
      sessions.delete(id);
      return false;
    }
    if (extend) sessions.set(id, Date.now() + 30 * 6e4);
    return true;
  };
  app2.addHook("onRequest", async (request, reply) => {
    const path = request.url.split("?")[0];
    if (!path.startsWith("/api/") || path.startsWith("/api/v2/auth/") || path === "/api/health") return;
    const extend = request.method !== "GET" || path.startsWith("/api/v2/records/");
    if (credential() && !authenticated(request.headers.cookie, extend)) return reply.code(401).send({ error: "Desbloquea tu copia local para continuar." });
    if (credential() && extend) reply.header("Set-Cookie", "planb_session=" + cookie(request.headers.cookie) + "; HttpOnly; SameSite=Strict; Path=/; Max-Age=1800");
  });
  app2.get("/api/health", async () => ({ ok: true, version: "0.2.0" }));
  app2.get("/api/v2/auth/status", async (request) => ({ configured: !!credential(), authenticated: !credential() || authenticated(request.headers.cookie) }));
  app2.post("/api/v2/auth/setup", async (request, reply) => {
    if (credential()) throw new AppError(409, "La protecci\xF3n local ya est\xE1 configurada.");
    const { password } = z2.object({ password: z2.string().min(12).max(200) }).strict().parse(request.body);
    const salt = randomBytes2(16);
    store2.set("password", { salt: salt.toString("base64"), hash: scryptSync2(password, salt, 32).toString("base64") });
    const id = randomBytes2(32).toString("hex");
    sessions.set(id, Date.now() + 30 * 6e4);
    reply.header("Set-Cookie", "planb_session=" + id + "; HttpOnly; SameSite=Strict; Path=/; Max-Age=1800");
    return { configured: true };
  });
  app2.post("/api/v2/auth/login", async (request, reply) => {
    const { password } = z2.object({ password: z2.string().max(200) }).strict().parse(request.body);
    const key = request.ip, previous = attempts.get(key), now = Date.now();
    const attempt = previous && now - previous.at < 6e4 ? previous : { at: now, count: 0 };
    if (++attempt.count > 5) throw new AppError(429, "Demasiados intentos. Espera un minuto.");
    attempts.set(key, attempt);
    const saved = credential();
    if (!saved || !timingSafeEqual(scryptSync2(password, Buffer.from(saved.salt, "base64"), 32), Buffer.from(saved.hash, "base64"))) throw new AppError(401, "Contrase\xF1a incorrecta.");
    attempts.delete(key);
    const id = randomBytes2(32).toString("hex");
    sessions.set(id, now + 30 * 6e4);
    reply.header("Set-Cookie", "planb_session=" + id + "; HttpOnly; SameSite=Strict; Path=/; Max-Age=1800");
    return { authenticated: true };
  });
  app2.post("/api/v2/auth/lock", async (request, reply) => {
    sessions.delete(cookie(request.headers.cookie));
    reply.header("Set-Cookie", "planb_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0");
    return { locked: true };
  });
}

// server/v2.ts
import { z as z3 } from "zod";

// server/continuity.ts
import { spawn } from "node:child_process";
import { existsSync as existsSync3 } from "node:fs";
import { dirname as dirname3, join as join3 } from "node:path";
import { randomUUID as randomUUID3 } from "node:crypto";

// server/jobs.ts
import { randomUUID as randomUUID2 } from "node:crypto";
var Jobs = class {
  constructor(store2) {
    this.store = store2;
    for (const job of this.list()) if (["running", "queued"].includes(job.status)) this.write({ ...job, status: "interrupted", message: "El proceso se cerr\xF3. Los datos activos se conservaron.", updatedAt: (/* @__PURE__ */ new Date()).toISOString() });
  }
  controllers = /* @__PURE__ */ new Map();
  list() {
    return this.store.get("jobs", []);
  }
  write(job) {
    this.store.set("jobs", [job, ...this.list().filter((j) => j.id !== job.id)].slice(0, 100));
  }
  start(kind, run) {
    if (this.controllers.size) throw new AppError(409, "Espera a que termine el trabajo actual.");
    const now = (/* @__PURE__ */ new Date()).toISOString(), job = { id: randomUUID2(), kind, status: "queued", createdAt: now, updatedAt: now, message: "En cola", progress: 0 };
    const controller = new AbortController();
    this.controllers.set(job.id, controller);
    this.write(job);
    const update = (message, progress) => {
      job.message = message;
      job.progress = progress;
      job.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      this.write(job);
    };
    setImmediate(async () => {
      try {
        job.status = "running";
        update("Preparando\u2026", 1);
        job.result = await run(update, controller.signal);
        job.status = controller.signal.aborted ? "cancelled" : "succeeded";
        update(job.status === "cancelled" ? "Cancelado" : "Completado", 100);
      } catch (error) {
        job.status = controller.signal.aborted ? "cancelled" : "failed";
        update(error instanceof AppError ? error.message : "No se complet\xF3 el trabajo. La copia activa se conserva.", job.progress);
      } finally {
        this.controllers.delete(job.id);
      }
    });
    return job;
  }
  cancel(id) {
    const controller = this.controllers.get(id);
    if (!controller) throw new AppError(409, "Este trabajo ya termin\xF3.");
    controller.abort();
    return { cancelled: true };
  }
  async stop() {
    for (const c of this.controllers.values()) c.abort();
    while (this.controllers.size) await new Promise((resolve2) => setTimeout(resolve2, 10));
  }
};

// shared/fixtures.ts
function makeDemoSpec(snapshot) {
  return {
    version: snapshot.version,
    title: snapshot.name,
    description: "Tu equipo sigue trabajando con su copia local.",
    ...snapshot.version === 2 ? { roles: { stage: "dealstage", amount: "amount", pipeline: snapshot.pipelines?.length ? "pipeline" : null, dueDate: snapshot.source.kind === "hubspot" ? "hs_timestamp" : "due_date", taskStatus: snapshot.source.kind === "hubspot" ? "hs_task_status" : "status" } } : {},
    entities: structuredClone(snapshot.entities),
    stages: structuredClone(snapshot.stages),
    rules: structuredClone(snapshot.rules),
    coverage: {
      supported: ["Consultar y editar clientes", "Gestionar empresas y sus relaciones", "Avanzar oportunidades entre etapas", "Crear y completar tareas", "Conservar y exportar cambios locales"],
      unsupported: [...snapshot.unsupported]
    }
  };
}

// server/continuity.ts
var Continuity = class {
  constructor(store2, root2, runtime = false, importer) {
    this.store = store2;
    this.root = root2;
    this.runtime = runtime;
    this.importer = importer;
    this.jobs = new Jobs(store2);
  }
  jobs;
  status() {
    const captures = this.store.captures(), at = captures[0]?.at ?? null, age = at ? Math.max(0, (Date.now() - Date.parse(at)) / 6e4) : null;
    return {
      captures,
      jobs: this.jobs.list(),
      reports: this.store.get("drills", []),
      latestCaptureAt: at,
      ageMinutes: age,
      stale: age === null || age > 75,
      session: this.store.get("continuitySession", null),
      schedule: this.store.get("schedule", { enabled: false, intervalMinutes: 60, lastAttempt: null }),
      connected: !this.store.disconnected,
      protected: !!this.store.get("password", null),
      accountId: this.store.snapshot?.source.accountId ?? null,
      changes: this.store.changesCount,
      pendingChanges: this.store.pendingChangesCount,
      runtime: this.runtime,
      realDataEnabled: false
    };
  }
  secretKey() {
    return localKey(dirname3(this.store.filename));
  }
  connection() {
    const text = this.store.get("hubspotConnection", null);
    return text ? JSON.parse(open(text, this.secretKey())) : null;
  }
  saveConnection(token, accountId) {
    if (this.runtime) throw new AppError(403, "El paquete independiente no contiene conectores.");
    if (!/^\d+$/.test(accountId) || token.length < 10) throw new AppError(422, "Revisa el ID de cuenta y la credencial.");
    if (this.store.snapshot?.source.kind === "hubspot" && this.store.snapshot.source.accountId !== accountId) throw new AppError(409, "Esta instalaci\xF3n ya pertenece a otro portal. Usa una carpeta nueva por empresa.");
    this.store.set("hubspotConnection", seal(JSON.stringify({ token, accountId }), this.secretKey()));
  }
  capture() {
    if (this.runtime || this.store.disconnected || this.status().session) throw new AppError(409, "Habilita los servicios fuera de una sesi\xF3n de continuidad.");
    const connection = this.connection();
    if (!connection) throw new AppError(422, "Configura una cuenta de prueba de HubSpot.");
    return this.jobs.start("capture", async (progress, signal) => {
      if (!this.importer) throw new AppError(503, "El importador no est\xE1 incluido en este paquete.");
      const snapshot = await this.importer({ ...connection, confirmedTestAccount: true, progress, signal });
      signal.throwIfAborted();
      if (snapshot.records.length > 1e4) throw new AppError(413, "El piloto admite hasta 10.000 registros totales.");
      if (snapshot.source.accountId !== connection.accountId) throw new AppError(422, "La captura pertenece a otro portal.");
      const id = this.store.addCapture(snapshot);
      return { captureId: id, records: snapshot.records.length, links: snapshot.links.length };
    });
  }
  begin(captureId) {
    if (this.status().session) throw new AppError(409, "Ya hay una sesi\xF3n de continuidad abierta. Contin\xFAa trabajando o ci\xE9rrala antes de abrir otra copia.");
    if (this.jobs.list().some((j) => ["queued", "running"].includes(j.status))) throw new AppError(409, "Espera a que termine el trabajo actual.");
    if (this.store.pendingChangesCount) throw new AppError(409, "Conserva y cierra los cambios pendientes antes de abrir otra captura.");
    const snapshot = this.store.capture(captureId);
    this.store.importSnapshot(snapshot, true);
    this.store.saveGeneration(makeDemoSpec(snapshot), { provider: "demo", model: null, generatedAt: (/* @__PURE__ */ new Date()).toISOString(), prompt: "", approved: false });
    this.store.activate();
    const session = { id: randomUUID3(), captureId, startedAt: (/* @__PURE__ */ new Date()).toISOString() };
    this.store.set("sessionId", session.id);
    this.store.set("sessionCapture", captureId);
    this.store.set("continuitySession", session);
    this.store.set("disconnected", true);
    return session;
  }
  end() {
    if (this.store.pendingChangesCount) throw new AppError(409, "Devuelve los cambios o conserva la sesi\xF3n. Exportar no los marca como devueltos.");
    this.store.set("continuitySession", null);
    this.store.set("sessionCapture", "");
    this.store.set("returnComplete", false);
    return { ended: true };
  }
  drill(captureId) {
    const id = captureId ?? this.store.captures()[0]?.id;
    if (!id) throw new AppError(409, "Necesitas una captura verificada.");
    const snapshot = this.store.capture(id);
    const bundle = {
      format: "planb-continuity-v2",
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      snapshot,
      spec: makeDemoSpec(snapshot),
      generation: { provider: "demo", model: null, generatedAt: (/* @__PURE__ */ new Date()).toISOString(), prompt: "", approved: true },
      records: snapshot.records,
      changes: []
    };
    return this.jobs.start("drill", async (progress, signal) => {
      progress("Probando una copia aislada con red bloqueada", 15);
      const built = existsSync3(join3(this.root, "drill.mjs")) ? join3(this.root, "drill.mjs") : join3(this.root, "build", "drill.mjs");
      const worker = existsSync3(built) ? [built] : ["--import", "tsx", join3(this.root, "server", "drill-worker.ts")];
      const guard = existsSync3(join3(this.root, "block-external.cjs")) ? join3(this.root, "block-external.cjs") : join3(this.root, "scripts", "block-external.cjs");
      const report = await new Promise((resolve2, reject) => {
        const env = Object.fromEntries(Object.entries(process.env).filter(([key]) => !/KEY|TOKEN|SECRET|NODE_OPTIONS|PLANB_/i.test(key)));
        const child = spawn(process.execPath, ["--require", guard, ...worker], { cwd: this.root, windowsHide: true, stdio: ["pipe", "pipe", "pipe"], signal, env });
        let stdout = "", stderr = "";
        const timeout = setTimeout(() => child.kill(), 9e4);
        child.stdout.on("data", (data) => {
          stdout += data;
          if (stdout.length > 1e6) child.kill();
        });
        child.stderr.on("data", (data) => {
          stderr += data;
        });
        child.on("error", reject);
        child.on("close", (code) => {
          clearTimeout(timeout);
          if (code !== 0) return reject(new AppError(500, "No se complet\xF3 el proceso aislado. Revisa la instalaci\xF3n de Node."));
          try {
            resolve2(JSON.parse(stdout));
          } catch {
            reject(new AppError(500, "El simulacro no devolvi\xF3 un informe v\xE1lido."));
          }
        });
        child.stdin.on("error", () => {
        });
        child.stdin.end(JSON.stringify({ bundle, captureId: id, scratch: join3(dirname3(this.store.filename), "scratch") }));
      });
      signal.throwIfAborted();
      this.store.set("drills", [report, ...this.store.get("drills", [])].slice(0, 36));
      return report;
    });
  }
  configureSchedule(enabled) {
    this.store.set("schedule", { ...this.status().schedule, enabled, intervalMinutes: 60 });
    return this.status().schedule;
  }
  tick() {
    const status = this.status();
    if (this.runtime || !status.schedule.enabled || !status.connected || status.session || this.jobs.list().some((j) => ["running", "queued"].includes(j.status))) return;
    const now = (/* @__PURE__ */ new Date()).toISOString();
    if (!status.schedule.lastAttempt || Date.now() - Date.parse(status.schedule.lastAttempt) >= 36e5) {
      this.store.set("schedule", { ...status.schedule, lastAttempt: now });
      try {
        this.capture();
      } catch (error) {
        this.store.set("scheduleError", error instanceof Error ? error.message : "No se pudo iniciar la captura.");
      }
      return;
    }
    const last = status.reports[0];
    if (status.captures.length && (!last || Date.now() - Date.parse(last.completedAt) > 30 * 864e5)) {
      try {
        this.drill();
      } catch {
      }
    }
  }
};

// server/recovery.ts
import { createHash, randomUUID as randomUUID4 } from "node:crypto";
var equal = (a, b) => JSON.stringify(a ?? null) === JSON.stringify(b ?? null);
var hash = (value) => createHash("sha256").update(JSON.stringify(value)).digest("hex");
var Recovery = class {
  constructor(store2) {
    this.store = store2;
    store2.set("returnBusy", false);
    const plan = this.plan();
    if (plan?.status === "applying") {
      for (const op of plan.operations) if (op.status === "sending") {
        op.status = "uncertain";
        op.error = "La petici\xF3n pudo llegar a HubSpot. Verifica el resultado antes de repetir.";
      }
      plan.status = "partial";
      this.save(plan);
    }
  }
  plan() {
    return this.store.get("recoveryPlan", null);
  }
  save(plan) {
    this.store.set("recoveryPlan", plan);
  }
  revision() {
    return hash({ session: this.store.get("sessionId", ""), changes: this.store.changes(), spec: this.store.spec });
  }
  async preview(remote) {
    if (!this.store.ready || !this.store.snapshot) throw new AppError(409, "Necesitas una copia activa.");
    if (this.plan()?.operations.some((o) => ["sending", "uncertain", "applied"].includes(o.status)) && this.plan()?.status !== "complete") throw new AppError(409, "Resuelve o termina el env\xEDo actual antes de crear otro plan.");
    const localRevision = this.revision();
    await remote.verify();
    if (remote.accountId !== this.store.snapshot.source.accountId) throw new AppError(422, "El portal remoto no coincide con la captura.");
    const changed = /* @__PURE__ */ new Map();
    const watermark = this.store.get("returnWatermark:" + remote.source, 0);
    const mapping = this.store.get("remoteMapping:" + remote.source, {});
    for (const c of this.store.changes().filter((c2) => c2.id > watermark)) {
      const key = c.entity + ":" + c.recordId, old = changed.get(key);
      changed.set(key, { before: old ? old.before : c.before, after: c.after });
    }
    const operations = [];
    for (const change of changed.values()) {
      const record = change.after, definition = this.store.spec.entities.find((e) => e.id === record.entity);
      const mappedId = mapping[record.entity + ":" + record.id] ?? record.id;
      const current = change.before ? await remote.read(record.entity, mappedId) : null;
      if (change.before && !current) throw new AppError(409, "El registro " + record.id + " est\xE1 ausente o archivado en HubSpot. No se recrear\xE1 autom\xE1ticamente.");
      const fields = definition.fields.filter((f) => !f.readOnly && f.type !== "reference" && (!change.before || !equal(change.before.values[f.key], record.values[f.key]))).map((f) => {
        const base = change.before?.values[f.key] ?? null, local = record.values[f.key] ?? null, actual = current?.values[f.key] ?? null;
        const conflict = !!change.before && !equal(base, actual) && !equal(local, actual);
        return { field: f.key, label: f.label, base, local, remote: actual, conflict, decision: conflict ? null : equal(local, actual) ? "remote" : "local" };
      });
      const references = definition.fields.filter((f) => f.type === "reference" && (change.before ? !equal(change.before.values[f.key], record.values[f.key]) : record.values[f.key] !== void 0 && record.values[f.key] !== null && record.values[f.key] !== "")).map((f) => ({ field: f.key, entity: f.referenceEntity, id: record.values[f.key] ? String(record.values[f.key]) : null }));
      if (references.some((r) => !r.id || change.before?.values[r.field])) throw new AppError(422, "Cambiar o quitar una relaci\xF3n principal requiere revisi\xF3n manual en HubSpot. Exporta esos cambios; esta versi\xF3n solo a\xF1ade relaciones.");
      if (!fields.length && !references.length) continue;
      operations.push({
        id: randomUUID4(),
        entity: record.entity,
        localId: record.id,
        remoteId: change.before ? mappedId : null,
        kind: change.before ? "update" : "create",
        label: String(record.values[definition.displayField] ?? record.id),
        fields,
        references,
        remoteVersion: current ? this.remoteHash(current, fields.map((f) => f.field)) : null,
        status: "pending",
        error: null
      });
    }
    if (localRevision !== this.revision()) throw new AppError(409, "Los datos locales cambiaron durante la revisi\xF3n. Vuelve a prepararla.");
    const plan = {
      id: randomUUID4(),
      accountId: remote.accountId,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      revision: localRevision,
      status: "review",
      operations,
      source: remote.source,
      approvedAt: null,
      warning: "Revisa workflows y coordina una ventana sin ediciones. Se aplica el estado final; no se reproducen estados intermedios ni se desactivan automatizaciones."
    };
    this.save(plan);
    return plan;
  }
  remoteHash(record, fields) {
    return hash(fields.map((key) => [key, record.values[key] ?? null]));
  }
  decide(planId, decisions) {
    const plan = this.require(planId);
    if (!["review", "approved"].includes(plan.status)) throw new AppError(409, "El env\xEDo ya se ha iniciado.");
    for (const choice of decisions) {
      const op = plan.operations.find((o) => o.id === choice.operationId), field = op?.fields.find((f) => f.field === choice.field);
      if (!field) throw new AppError(422, "La decisi\xF3n no pertenece al plan.");
      field.decision = choice.decision;
    }
    plan.status = "review";
    plan.approvedAt = null;
    this.save(plan);
    return plan;
  }
  approve(planId) {
    const plan = this.require(planId);
    if (plan.revision !== this.revision()) throw new AppError(409, "Hay cambios locales nuevos. Prepara otra revisi\xF3n.");
    if (plan.operations.some((op) => op.fields.some((f) => f.decision === null) || op.status === "uncertain")) throw new AppError(409, "Resuelve todos los conflictos y resultados inciertos.");
    if (!["review", "partial", "approved"].includes(plan.status)) throw new AppError(409, "El plan no admite otra aprobaci\xF3n.");
    for (const op of plan.operations.filter((o) => !["applied", "skipped"].includes(o.status))) {
      const local = this.store.record(op.entity, op.localId);
      const values = { ...local.values, ...Object.fromEntries(op.fields.map((f) => [f.field, f.decision === "local" ? f.local : f.remote])) };
      if (Object.keys(validateRecord(this.store.spec, { ...local, values })).length) throw new AppError(422, "Las decisiones dejan un registro inv\xE1lido: " + op.label + ". Revisa campos obligatorios y reglas.");
    }
    plan.status = "approved";
    plan.approvedAt = (/* @__PURE__ */ new Date()).toISOString();
    this.save(plan);
    return plan;
  }
  require(id) {
    const plan = this.plan();
    if (!plan || plan.id !== id) throw new AppError(404, "El plan no existe.");
    return plan;
  }
  async refresh(planId, remote) {
    const plan = this.require(planId);
    if (plan.status === "applying" || plan.source !== remote.source || plan.accountId !== remote.accountId || plan.revision !== this.revision()) throw new AppError(409, "El plan no admite esta revisi\xF3n.");
    if (plan.operations.some((o) => ["sending", "uncertain"].includes(o.status))) throw new AppError(409, "Verifica primero los resultados inciertos.");
    await remote.verify();
    for (const op of plan.operations.filter((o) => o.kind === "update" && o.status !== "applied")) {
      const current = await remote.read(op.entity, op.remoteId);
      if (!current) throw new AppError(409, "Registro remoto ausente. Revisi\xF3n manual necesaria.");
      for (const f of op.fields) {
        f.remote = current.values[f.field] ?? null;
        f.conflict = !equal(f.base, f.remote) && !equal(f.local, f.remote);
        f.decision = f.conflict ? null : equal(f.local, f.remote) ? "remote" : "local";
      }
      op.remoteVersion = this.remoteHash(current, op.fields.map((f) => f.field));
      op.status = "pending";
      op.error = null;
    }
    plan.status = "review";
    plan.approvedAt = null;
    this.save(plan);
    return plan;
  }
  async apply(planId, remote, signal, progress) {
    const plan = this.require(planId);
    if (plan.status !== "approved" || plan.source !== remote.source || plan.accountId !== remote.accountId || plan.revision !== this.revision()) throw new AppError(409, "Revisa y aprueba un plan vigente antes de aplicarlo.");
    await remote.verify();
    const order = ["companies", "contacts", "deals", "tasks"];
    plan.operations.sort((a, b) => order.indexOf(a.entity) - order.indexOf(b.entity));
    const mapping = this.store.get("remoteMapping:" + remote.source, {});
    plan.status = "applying";
    this.save(plan);
    for (const [index, op] of plan.operations.entries()) {
      if (["applied", "skipped"].includes(op.status)) continue;
      if (signal?.aborted) break;
      if (op.status === "uncertain") break;
      try {
        let current = null;
        if (op.kind === "update") {
          current = await remote.read(op.entity, op.remoteId);
          if (!current || this.remoteHash(current, op.fields.map((f) => f.field)) !== op.remoteVersion) {
            plan.status = "review";
            plan.approvedAt = null;
            op.error = "HubSpot cambi\xF3 desde la revisi\xF3n. Prepara otro plan.";
            this.save(plan);
            throw new AppError(409, op.error);
          }
        }
        const values = Object.fromEntries(op.fields.filter((f) => f.decision === "local").map((f) => [f.field, f.local]));
        const local = this.store.record(op.entity, op.localId);
        const selected = Object.fromEntries(op.fields.map((f) => [f.field, f.decision === "local" ? f.local : f.remote]));
        const combined = { ...local, values: { ...local.values, ...current?.values, ...op.kind === "create" ? selected : values } };
        const issues = validateRecord(this.store.spec, combined, current ? { ...combined, values: { ...local.values, ...current.values } } : null);
        if (Object.keys(issues).length) throw new AppError(422, "El estado final incumple una regla. Revisa " + op.label + " antes de enviar.");
        op.status = "sending";
        op.error = null;
        this.save(plan);
        if (op.kind === "create" && !op.remoteId) {
          op.remoteId = await remote.create(op.entity, values, op.id);
          mapping[op.entity + ":" + op.localId] = op.remoteId;
          this.store.set("remoteMapping:" + remote.source, mapping);
          this.save(plan);
        } else if (op.kind === "update" && Object.keys(values).length) await remote.update(op.entity, op.remoteId, values);
        for (const ref of op.references) {
          const target = mapping[ref.entity + ":" + ref.id] ?? ref.id;
          if (target.startsWith("local-")) throw new AppError(422, "Falta devolver primero el registro relacionado.");
          await remote.relate(op.entity, op.remoteId, ref.entity, target);
        }
        const verified = await remote.read(op.entity, op.remoteId);
        if (!verified || Object.entries(values).some(([k, v]) => !equal(verified.values[k], v))) throw new AppError(502, "HubSpot no confirm\xF3 los valores enviados.");
        op.status = "applied";
      } catch (error) {
        if (op.status === "sending") {
          op.status = "uncertain";
          op.error = "El env\xEDo puede haberse aplicado parcial o totalmente. Comprueba el ID remoto antes de continuar.";
        } else if (plan.status !== "review") {
          op.status = "failed";
          op.error = error instanceof AppError ? error.message : "No se pudo consultar el destino.";
        }
        this.save(plan);
        break;
      }
      this.save(plan);
      progress?.("Verificado: " + op.label, Math.round((index + 1) / Math.max(1, plan.operations.length) * 100));
    }
    plan.status = plan.operations.every((o) => ["applied", "skipped"].includes(o.status)) ? "complete" : plan.status === "review" ? "review" : "partial";
    this.save(plan);
    if (plan.status === "complete") {
      this.store.set("returnWatermark:" + remote.source, Math.max(0, ...this.store.changes().map((c) => c.id)));
      if (remote.source === "hubspot") this.store.set("returnComplete", true);
    }
    return plan;
  }
  async resolveUncertain(planId, operationId, remoteId, remote) {
    const plan = this.require(planId), op = plan.operations.find((o) => o.id === operationId);
    if (!op || op.status !== "uncertain" || plan.source !== remote.source || plan.accountId !== remote.accountId) throw new AppError(409, "No hay una operaci\xF3n incierta compatible.");
    await remote.verify();
    const record = await remote.read(op.entity, remoteId);
    if (!record || op.fields.filter((f) => f.decision === "local").some((f) => !equal(record.values[f.field], f.local))) throw new AppError(409, "El registro remoto no confirma los valores. Revisi\xF3n manual necesaria.");
    if (op.references.length) throw new AppError(409, "Hay relaciones pendientes: verifica la devoluci\xF3n con la agencia antes de continuar.");
    op.remoteId = remoteId;
    op.status = "applied";
    op.error = null;
    const mapping = this.store.get("remoteMapping:" + remote.source, {});
    mapping[op.entity + ":" + op.localId] = remoteId;
    this.store.set("remoteMapping:" + remote.source, mapping);
    plan.status = "partial";
    this.save(plan);
    return plan;
  }
};
function simulatedRemote(store2) {
  const snapshot = store2.snapshot;
  const records = () => store2.get("simulatedRemote", null) ?? snapshot.records;
  return {
    source: "simulation",
    accountId: snapshot.source.accountId,
    async verify() {
    },
    async read(entity, id) {
      return records().find((r) => r.entity === entity && r.id === id) ?? null;
    },
    async create(entity, values) {
      const id = "sim-" + randomUUID4();
      store2.set("simulatedRemote", [...records(), { entity, id, values }]);
      return id;
    },
    async update(entity, id, values) {
      store2.set("simulatedRemote", records().map((r) => r.entity === entity && r.id === id ? { ...r, values: { ...r.values, ...values } } : r));
    },
    async relate() {
    }
  };
}

// server/v2.ts
function registerV2(app2, store2, root2, runtime = false, external) {
  const continuity = new Continuity(store2, root2, runtime, external?.capture), recovery = new Recovery(store2);
  const remoteSchema = z3.object({ simulation: z3.boolean().default(false), token: z3.string().max(4096).optional() });
  function remote(raw) {
    if (runtime) throw new AppError(403, "La devoluci\xF3n se prepara en el generador, no en el paquete independiente.");
    const options = remoteSchema.parse(raw);
    if (options.simulation) return simulatedRemote(store2);
    const connection = continuity.connection();
    if (!connection || !store2.spec) throw new AppError(422, "Configura el portal de prueba antes de devolver cambios.");
    if (!external) throw new AppError(503, "El conector no est\xE1 disponible en este paquete.");
    return external.remote(options.token || connection.token, connection.accountId, store2.spec);
  }
  app2.get("/api/v2/continuity", async () => continuity.status());
  app2.get("/api/v2/candidate", async () => ({ candidate: store2.candidate }));
  app2.post("/api/v2/candidate/discard", async () => {
    store2.set("candidate", null);
    return { discarded: true };
  });
  app2.get("/api/v2/records/:entity", async (request) => {
    const params = z3.object({ entity: EntityNameSchema }).parse(request.params);
    const query = z3.object({ q: z3.string().max(200).default(""), offset: z3.coerce.number().int().min(0).default(0), limit: z3.coerce.number().int().min(1).max(100).default(50), pipeline: z3.string().default("") }).parse(request.query);
    return store2.page(params.entity, query.q, query.offset, query.limit, query.pipeline);
  });
  app2.get("/api/v2/records/:entity/:id", async (request) => {
    const { entity, id } = z3.object({ entity: EntityNameSchema, id: z3.string() }).parse(request.params);
    const record = store2.record(entity, id);
    if (!record) throw new AppError(404, "Registro no encontrado.");
    return { record };
  });
  if (!runtime) app2.post("/api/v2/connection", async (request) => {
    const body = z3.object({ token: z3.string().max(4096), accountId: z3.string(), confirmedTestAccount: z3.literal(true) }).strict().parse(request.body);
    if (!store2.get("password", null)) throw new AppError(409, "Configura la contrase\xF1a local antes de guardar credenciales.");
    continuity.saveConnection(body.token, body.accountId);
    return { saved: true, accountId: body.accountId };
  });
  if (!runtime) app2.post("/api/v2/captures", async () => continuity.capture());
  if (!runtime) app2.post("/api/v2/schedule", async (request) => {
    const { enabled } = z3.object({ enabled: z3.boolean() }).strict().parse(request.body);
    return continuity.configureSchedule(enabled);
  });
  app2.post("/api/v2/jobs/:id/cancel", async (request) => continuity.jobs.cancel(z3.object({ id: z3.string() }).parse(request.params).id));
  app2.post("/api/v2/drills", async (request) => {
    const { captureId } = z3.object({ captureId: z3.string().optional() }).strict().parse(request.body ?? {});
    return continuity.drill(captureId);
  });
  app2.get("/api/v2/drills/:id/report", async (request, reply) => {
    const { id } = z3.object({ id: z3.string() }).parse(request.params);
    const report = continuity.status().reports.find((r) => r.id === id);
    if (!report) throw new AppError(404, "Informe no encontrado.");
    return reply.header("Content-Disposition", 'attachment; filename="plan-b-simulacro.json"').send(report);
  });
  app2.post("/api/v2/session/begin", async (request) => {
    const { captureId } = z3.object({ captureId: z3.string() }).strict().parse(request.body);
    return continuity.begin(captureId);
  });
  app2.post("/api/v2/session/end", async () => continuity.end());
  app2.post("/api/v2/services", async (request) => {
    const { enabled } = z3.object({ enabled: z3.boolean() }).strict().parse(request.body);
    if (runtime && enabled) throw new AppError(403, "Este paquete es independiente.");
    if (continuity.status().session && enabled) throw new AppError(409, "Cierra la sesi\xF3n de continuidad para habilitar importaci\xF3n e IA. La devoluci\xF3n usa su propio recorrido revisado.");
    store2.set("disconnected", !enabled);
    return { connected: enabled };
  });
  app2.get("/api/v2/changes", async () => ({ changes: store2.changes(), plan: recovery.plan() }));
  if (!runtime) {
    app2.post("/api/v2/return/preview", async (request) => recovery.preview(remote(request.body)));
    app2.post("/api/v2/return/refresh", async (request) => {
      const body = z3.object({ planId: z3.string(), simulation: z3.boolean().default(false), token: z3.string().max(4096).optional() }).strict().parse(request.body);
      return recovery.refresh(body.planId, remote(body));
    });
    app2.post("/api/v2/return/decisions", async (request) => {
      const { planId, decisions } = z3.object({ planId: z3.string(), decisions: z3.array(z3.object({ operationId: z3.string(), field: z3.string(), decision: z3.enum(["local", "remote"]) })).max(1e3) }).strict().parse(request.body);
      return recovery.decide(planId, decisions);
    });
    app2.post("/api/v2/return/approve", async (request) => {
      const { planId, reviewedWorkflows } = z3.object({ planId: z3.string(), reviewedWorkflows: z3.literal(true) }).strict().parse(request.body);
      return recovery.approve(planId);
    });
    app2.post("/api/v2/return/apply", async (request) => {
      const body = z3.object({ planId: z3.string(), simulation: z3.boolean().default(false), token: z3.string().max(4096).optional(), approved: z3.literal(true) }).strict().parse(request.body);
      const target = remote(body);
      return continuity.jobs.start("return", async (progress, signal) => {
        store2.set("returnBusy", true);
        try {
          return await recovery.apply(body.planId, target, signal, progress);
        } finally {
          store2.set("returnBusy", false);
        }
      });
    });
    app2.post("/api/v2/return/verify-uncertain", async (request) => {
      const body = z3.object({ planId: z3.string(), operationId: z3.string(), remoteId: z3.string().min(1), simulation: z3.boolean().default(false), token: z3.string().max(4096).optional() }).strict().parse(request.body);
      return recovery.resolveUncertain(body.planId, body.operationId, body.remoteId, remote(body));
    });
  }
  app2.post("/api/v2/export/encrypted", async (request, reply) => {
    const { password } = z3.object({ password: z3.string().min(12).max(200) }).strict().parse(request.body);
    return reply.type("application/json").header("Content-Disposition", 'attachment; filename="plan-b-copia-cifrada.json"').send(encodePortable(store2.bundle(), password));
  });
  app2.post("/api/v2/export/package", async (request, reply) => {
    const { password } = z3.object({ password: z3.string().min(12).max(200) }).strict().parse(request.body);
    return reply.type("application/zip").header("Content-Disposition", 'attachment; filename="Plan-B-independiente-v2.zip"').send(await runtimeZip(store2.bundle(), root2, password));
  });
  app2.post("/api/v2/restore", async (request) => {
    if (continuity.jobs.list().some((j) => ["running", "queued"].includes(j.status))) throw new AppError(409, "Espera a que termine o cancela el trabajo actual antes de restaurar.");
    const { file, password, replace } = z3.object({ file: z3.string().max(4e7), password: z3.string().max(200).default(""), replace: z3.boolean().default(false) }).strict().parse(request.body);
    if (store2.changesCount && !replace) throw new AppError(409, "Exporta tus cambios y confirma la sustituci\xF3n antes de restaurar.");
    let bundle;
    try {
      const raw = JSON.parse(file);
      bundle = raw.format === "planb-encrypted-v2" ? decodePortable(file, password) : raw;
    } catch (error) {
      throw new AppError(422, error instanceof Error ? error.message : "Archivo inv\xE1lido.");
    }
    const probe = new Store(":memory:");
    try {
      probe.restoreBundle(bundle);
    } finally {
      probe.close();
    }
    const old = store2.bundleOrNull();
    if (old) store2.set("lastRestoreArchive", old);
    store2.restoreBundle(bundle);
    return { restored: true };
  });
  app2.post("/api/v2/history/prepare", async (request) => {
    const { captureId } = z3.object({ captureId: z3.string() }).strict().parse(request.body);
    const snapshot = store2.capture(captureId);
    store2.importSnapshot(snapshot, false);
    store2.saveGeneration(makeDemoSpec(snapshot), { provider: "demo", model: null, generatedAt: (/* @__PURE__ */ new Date()).toISOString(), prompt: "", approved: false });
    return { prepared: true };
  });
  const timer = setInterval(() => continuity.tick(), 6e4);
  timer.unref();
  app2.addHook("onClose", async () => {
    clearInterval(timer);
    await continuity.jobs.stop();
  });
  let closed = false;
  app2.addHook("onClose", async () => {
    closed = true;
  });
  setImmediate(() => {
    if (!closed) continuity.tick();
  });
  return { continuity, recovery };
}

// server/app.ts
async function createBaseApp(options) {
  const store2 = new Store(options.dbPath);
  if (options.runtime) store2.set("disconnected", true);
  const app2 = Fastify({ logger: false, bodyLimit: 20 * 1024 * 1024, requestTimeout: 18e4 });
  registerSecurity(app2, store2);
  app2.addHook("onClose", async () => {
    store2.close();
  });
  app2.addHook("onRequest", async (request, reply) => {
    const host = request.headers.host ?? "";
    if (!/^(127\.0\.0\.1|localhost|\[::1\])(?::\d+)?$/i.test(host)) return reply.code(403).send({ error: "Esta aplicaci\xF3n solo acepta acceso local." });
    const origin = request.headers.origin;
    if (origin) {
      let allowed = false;
      try {
        const value = new URL(origin);
        allowed = value.protocol === "http:" && (value.host === host || ["127.0.0.1:5187", "localhost:5187"].includes(value.host) && !options.runtime);
      } catch {
      }
      if (!allowed) return reply.code(403).send({ error: "Origen no permitido." });
    }
    reply.header("X-Content-Type-Options", "nosniff");
    reply.header("Referrer-Policy", "no-referrer");
    reply.header("Cache-Control", "no-store");
    reply.header("Content-Security-Policy", "default-src 'self'; connect-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; font-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
  });
  app2.setErrorHandler((error, _request, reply) => {
    if (error instanceof AppError) return reply.code(error.status).send({ error: error.message, details: error.details ?? null });
    if (error instanceof z4.ZodError) return reply.code(422).send({ error: "Revisa los datos enviados.", details: error.flatten() });
    const status = error && typeof error === "object" && "statusCode" in error ? Number(error.statusCode) : 500;
    return reply.code(status >= 400 && status < 500 ? status : 500).send({ error: status === 413 ? "El archivo es demasiado grande." : "No se pudo completar la operaci\xF3n. La \xFAltima copia v\xE1lida sigue guardada." });
  });
  const readState = async () => ({
    snapshot: store2.snapshot,
    spec: store2.spec,
    generation: store2.generation,
    reconciliation: store2.reconciliation,
    disconnected: store2.disconnected,
    runtime: !!options.runtime,
    ready: store2.ready,
    changes: store2.changesCount,
    usage: store2.usage(),
    aiConfigured: !options.runtime && (options.aiConfigured?.() ?? false),
    hubspotConfigured: !options.runtime && (options.hubspotConfigured?.() ?? false),
    lastError: store2.get("lastError", null),
    aiSettings: options.runtime ? null : options.aiPublic?.() ?? null,
    candidate: store2.candidate
  });
  app2.get("/api/state", readState);
  app2.get("/api/v2/state", async () => {
    const state = await readState();
    const compact = (snapshot) => ({ ...snapshot, records: [], links: [] });
    return { ...state, snapshot: state.snapshot ? compact(state.snapshot) : null, candidate: state.candidate ? { ...state.candidate, snapshot: compact(state.candidate.snapshot) } : null };
  });
  app2.get("/api/records", async () => ({ records: store2.records() }));
  app2.get("/api/records/:entity", async (request) => {
    const entity = EntityNameSchema.parse(request.params.entity);
    return { records: store2.records(entity) };
  });
  app2.post("/api/records/:entity", async (request) => {
    const entity = EntityNameSchema.parse(request.params.entity);
    const body = z4.object({ values: z4.record(z4.union([z4.string(), z4.number().finite(), z4.boolean(), z4.null()])) }).strict().parse(request.body);
    return { record: store2.saveRecord(entity, body.values) };
  });
  app2.patch("/api/records/:entity/:id", async (request) => {
    const entity = EntityNameSchema.parse(request.params.entity);
    const body = z4.object({ values: z4.record(z4.union([z4.string(), z4.number().finite(), z4.boolean(), z4.null()])) }).strict().parse(request.body);
    return { record: store2.saveRecord(entity, body.values, request.params.id) };
  });
  app2.post("/api/activate", async (request) => {
    z4.object({ reviewed: z4.literal(true) }).strict().parse(request.body);
    store2.activate();
    return { ready: true };
  });
  app2.post("/api/disconnect", async (request) => {
    const { disconnected } = z4.object({ disconnected: z4.boolean() }).strict().parse(request.body);
    if (options.runtime && !disconnected) throw new AppError(403, "El paquete independiente no contiene conectores externos.");
    if (store2.get("continuitySession", null) && !disconnected) throw new AppError(409, "Cierra la sesi\xF3n de continuidad antes de habilitar los servicios.");
    if (disconnected && !store2.ready) throw new AppError(409, "Activa una aplicaci\xF3n verificada antes de desconectar.");
    store2.set("disconnected", disconnected);
    return { disconnected };
  });
  app2.get("/api/changes", async () => ({ changes: store2.changes() }));
  app2.post("/api/probe", async () => {
    const spec = store2.spec, snapshot = store2.snapshot, generation = store2.generation;
    const records = store2.records();
    const ruleErrors = spec && snapshot && generation ? validateSpec(spec, snapshot, generation.prompt) : ["Falta una aplicaci\xF3n generada."];
    const dataErrors = spec ? records.flatMap((record) => Object.values(validateRecord(spec, record))) : ["Falta una especificaci\xF3n."];
    const probeValue = (/* @__PURE__ */ new Date()).toISOString();
    store2.transaction(() => store2.set("lastProbe", probeValue));
    const checks = [
      { id: "snapshot", label: "Captura completa y relaciones conciliadas", passed: !!store2.reconciliation?.complete },
      { id: "schema", label: "Especificaci\xF3n y reglas verificadas", passed: !!spec && ruleErrors.length === 0 },
      { id: "data", label: "Registros compatibles con la aplicaci\xF3n", passed: !!spec && dataErrors.length === 0 },
      { id: "persistence", label: "Lectura y escritura en SQLite local", passed: store2.get("lastProbe", "") === probeValue },
      { id: "disconnected", label: "Servicios externos desconectados", passed: store2.disconnected },
      { id: "approved", label: "Reglas revisadas y aplicaci\xF3n activada", passed: store2.ready }
    ];
    return {
      passed: checks.every((c) => c.passed),
      checks,
      at: probeValue,
      note: "Esta comprobaci\xF3n local no sustituye las pruebas automatizadas de reinicio y bloqueo de red incluidas en la entrega."
    };
  });
  app2.get("/api/export/bundle", async (_request, reply) => {
    if (store2.snapshot?.source.isTestData !== true) throw new AppError(403, "Usa una exportaci\xF3n cifrada para datos reales.");
    return reply.header("Content-Disposition", 'attachment; filename="plan-b-continuidad.json"').send(store2.bundle());
  });
  app2.get("/api/export/changes", async (request, reply) => {
    const changes = store2.changes();
    if (request.query.format === "csv") {
      const quote = (value) => '"' + String(value ?? "").replace(/"/g, '""') + '"';
      const rows = [
        ["fecha", "entidad", "id", "operacion", "antes_json", "despues_json"],
        ...changes.map((c) => [c.at, c.entity, c.recordId, c.operation, JSON.stringify(c.before), JSON.stringify(c.after)])
      ];
      return reply.type("text/csv; charset=utf-8").header("Content-Disposition", 'attachment; filename="plan-b-cambios.csv"').send("\uFEFF" + rows.map((row) => row.map(quote).join(",")).join("\r\n"));
    }
    return reply.header("Content-Disposition", 'attachment; filename="plan-b-cambios.json"').send({ exportedAt: (/* @__PURE__ */ new Date()).toISOString(), changes });
  });
  app2.get("/api/export/package", async (_request, reply) => {
    const zip = await runtimeZip(store2.bundle(), options.root);
    return reply.type("application/zip").header("Content-Disposition", 'attachment; filename="Plan-B-independiente.zip"').send(zip);
  });
  registerV2(app2, store2, options.root, !!options.runtime, options.external);
  if (existsSync4(options.staticDir)) {
    await app2.register(staticPlugin, { root: options.staticDir, prefix: "/", decorateReply: true });
    app2.setNotFoundHandler((request, reply) => {
      if (request.url.startsWith("/api/")) return reply.code(404).send({ error: "Operaci\xF3n no disponible en esta aplicaci\xF3n." });
      return reply.sendFile("index.html");
    });
  }
  return { app: app2, store: store2 };
}

// server/instance.ts
import { existsSync as existsSync5, readFileSync as readFileSync3, writeFileSync as writeFileSync2, unlinkSync, mkdirSync as mkdirSync3 } from "node:fs";
import { join as join4 } from "node:path";
function lockInstance(folder) {
  mkdirSync3(folder, { recursive: true });
  const path = join4(folder, ".instance");
  if (existsSync5(path)) {
    const pid = Number(readFileSync3(path, "utf8"));
    try {
      process.kill(pid, 0);
      throw new Error("Plan B ya est\xE1 abierto para esta carpeta. Usa la ventana existente.");
    } catch (error) {
      if (error.code !== "ESRCH") throw error;
      unlinkSync(path);
    }
  }
  writeFileSync2(path, String(process.pid), { flag: "wx" });
  const release = () => {
    try {
      if (readFileSync3(path, "utf8") === String(process.pid)) unlinkSync(path);
    } catch {
    }
  };
  process.on("exit", release);
  return release;
}

// server/runtime.ts
var root = process.cwd();
var releaseLock = lockInstance(resolve(process.env.PLANB_DATA_DIR || join5(root, "data")));
var { app, store } = await createBaseApp({
  dbPath: resolve(process.env.PLANB_DATA_DIR || join5(root, "data"), "planb.sqlite"),
  root,
  staticDir: join5(root, "dist"),
  runtime: true
});
if (!store.snapshot) {
  const encrypted = join5(root, "continuity.encrypted.json");
  const seed = join5(root, "continuity.seed.json");
  if (!existsSync6(seed) && !existsSync6(encrypted)) throw new Error("Falta el archivo de inicio. Extrae el paquete completo antes de iniciar.");
  if (existsSync6(seed)) store.restoreBundle(JSON.parse(readFileSync4(seed, "utf8")));
  else console.log("Copia cifrada: abre la p\xE1gina local e importa continuity.encrypted.json con tu contrase\xF1a de recuperaci\xF3n.");
}
var port = Number(process.env.PLANB_PORT || 4318);
for (; ; ) {
  try {
    await app.listen({ host: "127.0.0.1", port });
    break;
  } catch (error) {
    if (error.code === "EADDRINUSE" && !process.env.PLANB_PORT && port < 4328) {
      port++;
      continue;
    }
    throw error;
  }
}
console.log("\nPlan B \xB7 Aplicaci\xF3n independiente\nAbre http://127.0.0.1:" + port + "\nNo se utilizan servicios externos. Conserva la carpeta data con tus cambios.\n");
for (const signal of ["SIGINT", "SIGTERM"]) process.on(signal, () => {
  void app.close().then(() => {
    releaseLock();
    process.exit(0);
  });
});
