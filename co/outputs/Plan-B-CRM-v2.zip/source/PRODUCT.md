# Product
<!-- impeccable:product-schema 1 -->
## Platform
web
## Users
Un responsable local de una pyme usuaria de HubSpot. Agencias de HubSpot preparan, prueban y supervisan la continuidad.
## Product Purpose
Conservar una copia utilizable, demostrar sus procesos mediante un simulacro y devolver cambios revisados cuando el CRM vuelva a estar disponible.
## Operating Context
Windows, una instalación y un portal por carpeta. Copias actualizadas mientras el ordenador está encendido. Trabajo desconectado sin HubSpot ni IA. La preparación, las credenciales y la devolución requieren red explícitamente habilitada.
## Capabilities and Constraints
Mantener React, Vite, Fastify, Node 24 y SQLite. Cuatro objetos: clientes, empresas, oportunidades, tareas. Un operador. 10000 registros totales en piloto. Versiones candidatas nunca inutilizan la activa. Sin campañas, borrados remotos automáticos ni multiusuario.
## Brand Commitments
Nombre Plan B, español, blanco, texto oscuro, acento azul. Conservar tablas legibles y edición lateral de la demo.
## Evidence on Hand
Demo v1 y pruebas locales incluidas. No hay testimonios, pilotos vendidos ni pruebas de cuentas reales de HubSpot o IA. Mostrar esa ausencia con claridad.
## Product Principles
Continuidad comprobable. Independencia del proveedor. Procedencia explícita. Configuración progresiva. No inventar evidencia comercial.
