import { randomUUID } from 'node:crypto';
import { mkdirSync, mkdtempSync, rmSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { Store } from './store.js';
import type { ContinuityBundle, FieldValue } from '../shared/model.js';
import type { DrillReport } from '../shared/operations.js';
const chunks:Buffer[]=[];for await(const chunk of process.stdin)chunks.push(Buffer.from(chunk));
const input=JSON.parse(Buffer.concat(chunks).toString('utf8')) as {bundle:ContinuityBundle;captureId:string;scratch:string};
const started=Date.now(), checks:DrillReport['checks']=[];
const scratch=resolve(input.scratch);mkdirSync(scratch,{recursive:true});
const folder=mkdtempSync(join(scratch,'drill-'));
let store:Store|null=null;
function check(label:string,fn:()=>void){try{fn();checks.push({label,passed:true,detail:'Comprobado en una copia aislada.'});}catch(error){checks.push({label,passed:false,detail:error instanceof Error?error.message:'No superado.'});}}
try {
  let blocked=false;
  try{await fetch('https://example.com');}catch(error){blocked=String(error).includes('EXTERNAL_');}
  check('Red externa bloqueada',()=>{if(!blocked)throw new Error('El arnés no confirmó el bloqueo de red.');});
  if(!blocked)throw new Error('No se ejecutará un simulacro sin aislamiento.');
  store=new Store(join(folder,'drill.sqlite'));store.restoreBundle(input.bundle);
  let contactId='',taskId='',phoneKey='',newPhone='Prueba de continuidad';
  check('Buscar y editar un cliente',()=>{
    const found=store!.page('contacts','',0,1).records[0];if(!found)throw new Error('No hay clientes para probar.');
    contactId=found.id;
    const field=store!.spec!.entities.find(e=>e.id==='contacts')!.fields.find(f=>!f.readOnly && f.type==='text' && /phone|tel/i.test(f.key+f.label));
    if(!field)throw new Error('No hay un teléfono editable cubierto.');
    phoneKey=field.key;newPhone='600 123 456';store!.saveRecord('contacts',{[phoneKey]:newPhone},found.id);
  });
  check('Avanzar una oportunidad',()=>{
    const found=store!.records('deals')[0];if(!found)throw new Error('No hay oportunidades para probar.');
    const stages=store!.spec!.stages.filter(s=>!s.pipelineId || s.pipelineId===found.values.pipeline);
    const stage=stages.find(s=>s.id!==found.values.dealstage);if(!stage)throw new Error('No hay una segunda etapa.');
    store!.saveRecord('deals',{dealstage:stage.id},found.id);
  });
  check('Crear y completar una tarea',()=>{
    const entity=store!.spec!.entities.find(e=>e.id==='tasks')!, template=store!.records('tasks')[0];
    const values:Record<string,FieldValue>=Object.fromEntries(entity.fields.filter(f=>!f.readOnly).map(f=>[f.key,template?.values[f.key]??null]));
    const title=entity.displayField, due=store!.spec!.roles?.dueDate??'due_date', status=store!.spec!.roles?.taskStatus??'status';
    values[title]='Simulacro · tarea temporal';values[due]=entity.fields.find(f=>f.key===due)?.type==='datetime'?'2026-11-12T10:00:00.000Z':'2026-11-12';
    const statusField=entity.fields.find(f=>f.key===status);
    const done=statusField?.options.find(o=>/complet|termin|done/i.test(o.id+' '+o.label));
    if(!done)throw new Error('No hay un estado de tarea completada compatible.');
    const task=store!.saveRecord('tasks',values);taskId=task.id;store!.saveRecord('tasks',{[status]:done.id},task.id);
  });
  store.close();store=new Store(join(folder,'drill.sqlite'));
  check('Persistencia después de reiniciar',()=>{
    if(!contactId || !taskId || store!.record('contacts',contactId)?.values[phoneKey]!==newPhone || !store!.record('tasks',taskId))throw new Error('No se conservaron todas las operaciones.');
  });
}catch(error){checks.push({label:'Preparación del simulacro',passed:false,detail:error instanceof Error?error.message:'Error del entorno.'});}
finally{store?.close();const absolute=resolve(folder);if(!absolute.startsWith(scratch+requireSeparator()))throw new Error('Ruta de limpieza no válida.');rmSync(absolute,{recursive:true,force:true,maxRetries:3,retryDelay:100});}
function requireSeparator(){return process.platform==='win32'?'\\':'/';}
const report:DrillReport={id:randomUUID(),captureId:input.captureId,startedAt:new Date(started).toISOString(),completedAt:new Date().toISOString(),
  passed:checks.length===5 && checks.every(c=>c.passed),isolated:true,checks,durationMs:Date.now()-started,
  dataSource:input.bundle.snapshot.source.kind==='fixture'?'Conjunto ficticio incluido':'Cuenta HubSpot de prueba',
  limitations:['Simulacro técnico, no certificación ni SLA.','No acredita devolución real a HubSpot.','No modifica los datos operativos.']};
process.stdout.write(JSON.stringify(report));
