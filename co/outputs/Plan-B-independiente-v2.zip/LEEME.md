# Plan B v2 · Aplicación independiente

1. Extrae todo el ZIP en una carpeta de Windows.
2. Abre ABRIR PLAN B.cmd y entra en la dirección local que aparece.
3. Los datos ficticios de continuity.seed.json se cargan en el primer inicio.

Node, dependencias y recursos visuales están incluidos. No se necesita HubSpot ni un proveedor IA. Los conectores y sus credenciales no están en este paquete.

Los cambios se conservan en data/planb.sqlite, con valores cifrados y una clave data/.planb-key protegida por DPAPI para tu usuario de Windows. Conserva la carpeta completa y detén el servidor antes de moverla. Para cambiar de usuario o equipo, exporta una copia con contraseña desde la app y restáurala en el destino; copiar solo la base no transfiere DPAPI.

La base activa prevalece sobre el archivo inicial después de restaurar. Puedes trabajar, exportar cambios JSON/CSV, crear copias cifradas y ejecutar el simulacro aislado. La devolución revisada se prepara en el generador; el runtime no contiene esa ruta.

Esta entrega admite un operador y datos de ensayo. Conserva la contraseña de recuperación por separado: no existe un servicio para recuperarla.
