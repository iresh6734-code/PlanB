@echo off
cd /d "%~dp0"
"%~dp0node.exe" runtime.mjs
pause
