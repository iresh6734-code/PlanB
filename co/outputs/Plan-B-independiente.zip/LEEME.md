# Plan B · Aplicación independiente

1. Extrae todo el ZIP en una carpeta.
2. En Windows, abre ABRIR PLAN B.cmd.
3. Abre en tu navegador la dirección local que aparece en la ventana.

La aplicación incluye su copia de datos y no necesita HubSpot ni una clave de IA. Los cambios se guardan en data/planb.sqlite. Conserva esa carpeta al mover la aplicación. Cierra la ventana del servidor antes de trasladarla.

Esta versión es una demostración para un operador y datos de ensayo. La información no se devuelve automáticamente al CRM. Puedes exportar un JSON completo o un informe de cambios CSV.

La captura original y el historial de cambios están en continuity.seed.json. La base SQLite activa prevalece sobre ese archivo después del primer inicio.

No se incluyen credenciales ni configuración del generador.
